const fs = require('fs')
const chalk = require('chalk')

//======== Social Media ==========//

global.gcm = 'https://chat.whatsapp.com/EIPyNzrxmCr86ll7pA49mD'
global.gr = 'https://chat.whatsapp.com/EIPyNzrxmCr86ll7pA49mD'
global.ig = 'https://instagram/@' // ubah aja
global.newslttr = '120363310531380313@newsletter'
global.gh = 'https://github.com/chataofc'
global.yt = 'https://youtube.com/@dichcreator?si=BI-lgg1nIlg20A0Q'
global.saluran = 'https://whatsapp.com/channel/0029VaclEQBGehEMNAfSU61j' //errReply
global.email = '-@gmail.com' //serah
global.region = 'indonesia' // serah
global.dana = '087826292008'
global.gopay = '087826292008'
global.pulsa = '087826292008'

//======== Owner Name ==========//

global.ownername = '𝘿𝙞𝙘𝙝𝘾𝙧𝙚𝙖𝙩𝙤𝙧' /*ubah jadi namamu!*/

//============= Number ===============//

global.owner = ['6287826292008'] // ubah jadi nomormu
global.premium = []
global.settings = {
	lang: 'id',
	anticall: false,
	autobio: false,
	autoread: false,
	autotype: false,
	readsw: false,
	template: 'textMessage',
	multiprefix: false,
}
//============= Apikey =================//

global.apikey = 'GataDios'
global.apikeys = '9174374619a0353273a70311'
global.skizo = 'woxxzAsia' //Buat apikey sendiri di https://skizo.tech/pricing, gratis kok
const api = {
    xterm: {
        url: "https://ai.xterm.codes",
        key: "YoriChan"
    }
}; 

//============== Name ===============//

global.botname = 'ᴄʏʏxᴇʀᴏ ᴀɪ' //ubah jadi nama bot mu, tanpa mengubah tanda `
global.botname2 = `ʙʏ ᴄʏʏxᴇʀᴏ ᴀɪ | 6285224079032`
global.packname = 'sticker by ' // ubah aja ini nama packname sticker
global.ta = '•'
global.author = 'ᴄʏʏxᴇʀᴏ ᴀɪ' // ubah aja ini nama author sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'session' //Saran gua gausah
global.sp = '⭔' 
global.wlcm = []
global.wlcmm = []
global.anticall = true

//=============== Media ===============//

global.add =  fs.readFileSync("./database/base/image/add.jpg")

//=========== Quick Message ===========//

global.mess = {
    done: '*Done Kak*',
    admin: '*Fitur ini cuman buat Admin group*',
    botAdmin: '*Command bisa digunakan ketika bot menjadi Admin*',
    owner: '*Fitur ini hanya bisa digunakan oleh owner Bot*',
    group: '*Fitur ini hanya dapat digunakan dalam group*',
    private: '*Fitur ini cuman buat Admin grup*',
    wait: '*❏ Harap Tunggu Sebentar!!⏳*',
    endLimit: '*Limitmu sudah habis, reset limit dimulai pukul 12 malam*',
    doned: 'successfully sent bug to target🗿🚬',
    bugrespon: 'wait a minute, bug is being sent to target!!🗿🚬',
    error: '*Fitur sedang Error!!!*',
    premium: 'khusus premium',
    prem : '*Fitur ini hanya untuk member premium*'
}
//============= Limit ================//

global.limitawal = {
    premium: "infinity",
    free: 25
}

//============= RPG ================//

global.buruan = {
   ikan: 5,
   ayam: 5,
   kelinci: 5,
   domba: 5,
   sapi: 5,
   gajah: 5
}
global.rpg = {
   darahawal: 100,
   besiawal: 5,
   goldawal: 1,
   emeraldawal: 1,
   umpanawal: 1,
   potionawal: 1
}

//========== Change Detect ===========//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})